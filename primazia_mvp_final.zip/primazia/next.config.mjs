/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '*.supabase.co',
        port: '',
        pathname: '/storage/v1/object/public/**',
      },
    ],
  },
  // jspdf runs only server-side; mark it external to avoid bundling issues
  serverExternalPackages: ['jspdf'],
}

export default nextConfig
