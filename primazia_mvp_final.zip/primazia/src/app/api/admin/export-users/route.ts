import { createClient } from '@/lib/supabase/server'
import { NextResponse } from 'next/server'
import { generateCSV, csvResponse } from '@/lib/utils/csv'

export async function GET() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { data: profile } = await supabase
    .from('profiles').select('role').eq('id', user.id).single()
  if (!profile || !['super_admin', 'admin'].includes(profile.role)) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  const { data: users } = await supabase
    .from('profiles')
    .select('full_name, email, role, is_active, created_at, last_login_at')
    .order('created_at', { ascending: false })

  if (!users) return NextResponse.json({ error: 'Server error' }, { status: 500 })

  const rows = users.map(u => ({
    Nome: u.full_name,
    'E-mail': u.email,
    Perfil: u.role,
    Ativo: u.is_active ? 'Sim' : 'Não',
    'Criado em': new Date(u.created_at).toLocaleDateString('pt-BR'),
    'Último login': u.last_login_at
      ? new Date(u.last_login_at).toLocaleDateString('pt-BR')
      : '—',
  }))

  await supabase.from('audit_logs').insert({
    user_id: user.id, action: 'export_users_csv', module: 'admin',
  })

  const filename = `usuarios_${new Date().toISOString().slice(0, 10)}.csv`
  return csvResponse(generateCSV(rows), filename) as unknown as NextResponse
}
