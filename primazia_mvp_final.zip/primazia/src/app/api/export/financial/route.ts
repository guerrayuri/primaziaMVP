import { createClient } from '@/lib/supabase/server'
import { NextRequest, NextResponse } from 'next/server'
import { generateCSV, csvResponse } from '@/lib/utils/csv'

export async function GET(request: NextRequest) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { data: profile } = await supabase
    .from('profiles').select('role').eq('id', user.id).single()
  if (!profile || !['super_admin', 'financial_admin'].includes(profile.role)) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  const { searchParams } = new URL(request.url)
  const start = searchParams.get('start')
  const end = searchParams.get('end')

  let query = supabase
    .from('financial_transactions')
    .select('transaction_date,type,description,amount,payment_method,reference_num,notes,status,financial_categories(name),profiles!created_by(full_name)')
    .eq('status', 'active')
    .order('transaction_date', { ascending: false })

  if (start) query = query.gte('transaction_date', start)
  if (end) query = query.lte('transaction_date', end)

  const { data } = await query
  if (!data) return NextResponse.json({ error: 'Server error' }, { status: 500 })

  const rows = data.map((t: Record<string, unknown>) => {
    const cat = t.financial_categories as { name: string } | null
    const creator = t.profiles as { full_name: string } | null
    return {
      Data: t.transaction_date,
      Tipo: t.type === 'income' ? 'Entrada' : 'Saída',
      Categoria: cat?.name ?? '',
      Descrição: t.description,
      Valor: `R$ ${Number(t.amount).toFixed(2).replace('.', ',')}`,
      'Forma de pagamento': t.payment_method ?? '',
      'Nº Comprovante': t.reference_num ?? '',
      Observações: t.notes ?? '',
      'Lançado por': creator?.full_name ?? '',
    }
  })

  await supabase.from('audit_logs').insert({
    user_id: user.id, action: 'export_financial_csv', module: 'financeiro',
  })

  const filename = `financeiro_${new Date().toISOString().slice(0, 10)}.csv`
  return csvResponse(generateCSV(rows), filename) as unknown as NextResponse
}
