import { createClient } from '@/lib/supabase/server'
import { NextResponse } from 'next/server'
import { generateCSV, csvResponse } from '@/lib/utils/csv'

export async function GET() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { data: profile } = await supabase
    .from('profiles').select('role').eq('id', user.id).single()
  if (!profile || !['super_admin', 'admin', 'pastor'].includes(profile.role)) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  const { data } = await supabase
    .from('members')
    .select('full_name,email,phone,birth_date,gender,ministry,status')
    .is('deleted_at', null)
    .order('full_name')

  if (!data) return NextResponse.json({ error: 'Server error' }, { status: 500 })

  const STATUS_MAP: Record<string, string> = {
    active: 'Ativo', inactive: 'Inativo',
    transferred: 'Transferido', deceased: 'Falecido',
  }

  const rows = data.map(m => ({
    Nome: m.full_name,
    'E-mail': m.email ?? '',
    Telefone: m.phone ?? '',
    Nascimento: m.birth_date ?? '',
    Gênero: m.gender === 'M' ? 'Masculino' : m.gender === 'F' ? 'Feminino' : '',
    Ministério: m.ministry ?? '',
    Status: STATUS_MAP[m.status] ?? m.status,
  }))

  await supabase.from('audit_logs').insert({
    user_id: user.id, action: 'export_members_csv', module: 'membros',
  })

  const filename = `membros_${new Date().toISOString().slice(0, 10)}.csv`
  return csvResponse(generateCSV(rows), filename) as unknown as NextResponse
}
