import { createClient } from '@/lib/supabase/server'
import { NextRequest, NextResponse } from 'next/server'
import { generateCSV, csvResponse } from '@/lib/utils/csv'

export async function GET(request: NextRequest) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { data: profile } = await supabase
    .from('profiles').select('role').eq('id', user.id).single()
  if (!profile || !['super_admin', 'admin', 'pastor'].includes(profile.role)) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  const { searchParams } = new URL(request.url)
  const start = searchParams.get('start')
  const end = searchParams.get('end')

  let query = supabase
    .from('visitors')
    .select('full_name,visit_date,service_type,gender,age,neighborhood,city,phone,how_found,wants_contact,is_recurring')
    .eq('status', 'active')
    .order('visit_date', { ascending: false })

  if (start) query = query.gte('visit_date', start)
  if (end) query = query.lte('visit_date', end)

  const { data } = await query
  if (!data) return NextResponse.json({ error: 'Server error' }, { status: 500 })

  const rows = data.map(v => ({
    Nome: v.full_name,
    'Data da visita': v.visit_date,
    Culto: v.service_type,
    Gênero: v.gender === 'M' ? 'Masculino' : v.gender === 'F' ? 'Feminino' : 'Não informado',
    Idade: v.age ?? '',
    Bairro: v.neighborhood ?? '',
    Cidade: v.city ?? '',
    Telefone: v.phone ?? '',
    'Como conheceu': v.how_found ?? '',
    'Deseja contato': v.wants_contact ? 'Sim' : 'Não',
    Recorrente: v.is_recurring ? 'Sim' : 'Não',
  }))

  await supabase.from('audit_logs').insert({
    user_id: user.id, action: 'export_visitors_csv', module: 'visitantes',
  })

  const filename = `visitantes_${new Date().toISOString().slice(0, 10)}.csv`
  return csvResponse(generateCSV(rows), filename) as unknown as NextResponse
}
