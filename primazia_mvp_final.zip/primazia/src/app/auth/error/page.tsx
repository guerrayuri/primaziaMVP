import Link from 'next/link'

export default function AuthErrorPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-navy-800 via-navy-700 to-navy-600 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl p-8 max-w-sm w-full text-center shadow-2xl">
        <div className="text-4xl mb-4">⚠️</div>
        <h2 className="font-serif text-xl text-navy-700 mb-2">Erro de autenticação</h2>
        <p className="text-sm text-stone-500 mb-6">
          Ocorreu um problema durante a autenticação. O link pode ter expirado ou já foi utilizado.
        </p>
        <Link href="/auth/login" className="btn btn-primary w-full justify-center">
          Tentar novamente
        </Link>
      </div>
    </div>
  )
}
