'use client'

export const dynamic = 'force-dynamic'

import { useState } from 'react'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/client'

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [sent, setSent] = useState(false)
  const [error, setError] = useState('')
  const supabase = createClient()

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    setLoading(true)
    const { error: err } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/auth/reset-password`,
    })
    if (err) { setError('Erro ao enviar. Verifique o e-mail e tente novamente.'); setLoading(false); return }
    setSent(true)
    setLoading(false)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-navy-800 via-navy-700 to-navy-600 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl p-7 max-w-sm w-full shadow-2xl">
        {sent ? (
          <div className="text-center">
            <div className="text-4xl mb-3">📧</div>
            <h2 className="font-serif text-xl text-navy-700 mb-2">E-mail enviado!</h2>
            <p className="text-sm text-stone-500 mb-4">Verifique sua caixa de entrada e clique no link para redefinir sua senha.</p>
            <Link href="/auth/login" className="btn btn-primary w-full justify-center">Voltar ao login</Link>
          </div>
        ) : (
          <>
            <h2 className="font-serif text-xl text-navy-700 mb-2">Recuperar senha</h2>
            <p className="text-xs text-stone-500 mb-5">Informe seu e-mail e enviaremos um link para redefinir sua senha.</p>
            {error && <div className="alert-error">{error}</div>}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="label">E-mail</label>
                <input className="input" type="email" placeholder="seu@email.com"
                  value={email} onChange={e => setEmail(e.target.value)} required />
              </div>
              <button type="submit" disabled={loading} className="btn btn-primary w-full justify-center py-2.5">
                {loading ? 'Enviando...' : 'Enviar link'}
              </button>
            </form>
            <div className="mt-4 text-center">
              <Link href="/auth/login" className="text-xs text-stone-400 hover:text-stone-600">← Voltar ao login</Link>
            </div>
          </>
        )}
      </div>
    </div>
  )
}
