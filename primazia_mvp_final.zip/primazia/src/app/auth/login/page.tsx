'use client'

import { Suspense } from 'react'
import { useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/client'

function LoginForm() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const next = searchParams.get('next') || '/protected/dashboard'
  const errorParam = searchParams.get('error')

  const ERROR_MESSAGES: Record<string, string> = {
    account_disabled: 'Sua conta foi desativada. Entre em contato com o administrador.',
    pending_approval: 'Sua conta está aguardando aprovação do administrador. Você receberá acesso em breve.',
    unauthorized: 'Você não tem permissão para acessar esta página.',
  }

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(errorParam ? (ERROR_MESSAGES[errorParam] ?? '') : '')

  const supabase = createClient()

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    setLoading(true)

    const { error: authError } = await supabase.auth.signInWithPassword({ email, password })

    if (authError) {
      setError('E-mail ou senha incorretos.')
      setLoading(false)
      return
    }

    const { data: { user } } = await supabase.auth.getUser()
    if (user) {
      await supabase.from('profiles').update({ last_login_at: new Date().toISOString() }).eq('id', user.id)
      await supabase.from('audit_logs').insert({ user_id: user.id, action: 'login', module: 'auth' })
    }

    router.push(next)
    router.refresh()
  }

  return (
    <div className="w-full max-w-sm">
      <div className="text-center mb-8">
        <div className="w-14 h-14 bg-gradient-to-br from-gold-400 to-gold-500 rounded-2xl flex items-center justify-center font-serif font-bold text-navy-700 text-3xl mx-auto mb-3 shadow-lg">P</div>
        <h1 className="font-serif text-2xl font-semibold text-white">PrimazIA</h1>
        <p className="text-white/50 text-xs mt-1">Gestão Ministerial</p>
      </div>
      <div className="bg-white rounded-2xl p-7 shadow-2xl">
        <h2 className="font-serif text-xl text-navy-700 mb-6">Entrar na plataforma</h2>
        {error && <div className="alert-error mb-4"><span>⚠️</span> {error}</div>}
        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="label">E-mail</label>
            <input className="input" type="email" placeholder="seu@email.com" value={email}
              onChange={e => setEmail(e.target.value)} required autoComplete="email" />
          </div>
          <div>
            <label className="label">Senha</label>
            <input className="input" type="password" placeholder="••••••••" value={password}
              onChange={e => setPassword(e.target.value)} required autoComplete="current-password" />
          </div>
          <div className="flex justify-end">
            <Link href="/auth/forgot-password" className="text-xs text-gold-500 hover:text-gold-600">Esqueci minha senha</Link>
          </div>
          <button type="submit" disabled={loading} className="btn btn-primary w-full justify-center py-2.5 text-sm">
            {loading ? 'Entrando...' : 'Entrar'}
          </button>
        </form>
        <div className="mt-5 pt-5 border-t border-stone-100 text-center">
          <p className="text-xs text-stone-500">
            Não tem conta?{' '}
            <Link href="/auth/register" className="text-gold-500 font-medium hover:text-gold-600">Criar conta</Link>
          </p>
          <p className="text-xs text-stone-400 mt-2">
            <Link href="/" className="hover:text-stone-600">← Área pública da igreja</Link>
          </p>
        </div>
      </div>
    </div>
  )
}

export default function LoginPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-navy-800 via-navy-700 to-navy-600 flex items-center justify-center p-4">
      <Suspense fallback={
        <div className="w-full max-w-sm bg-white rounded-2xl p-7 shadow-2xl animate-pulse">
          <div className="space-y-4">
            <div className="h-8 bg-stone-200 rounded w-48 mx-auto" />
            <div className="h-10 bg-stone-200 rounded" />
            <div className="h-10 bg-stone-200 rounded" />
            <div className="h-10 bg-stone-300 rounded" />
          </div>
        </div>
      }>
        <LoginForm />
      </Suspense>
    </div>
  )
}
