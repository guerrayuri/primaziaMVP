'use client'

export const dynamic = 'force-dynamic'

import { useState } from 'react'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/client'

export default function RegisterPage() {
  const [form, setForm] = useState({ name: '', email: '', password: '', confirm: '' })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)

  const supabase = createClient()

  function set(field: string, value: string) {
    setForm(prev => ({ ...prev, [field]: value }))
  }

  async function handleRegister(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    if (form.password.length < 6) { setError('A senha deve ter no mínimo 6 caracteres.'); return }
    if (form.password !== form.confirm) { setError('As senhas não coincidem.'); return }

    setLoading(true)
    const { error: authError } = await supabase.auth.signUp({
      email: form.email,
      password: form.password,
      options: {
        data: { full_name: form.name },
        emailRedirectTo: `${window.location.origin}/auth/callback`,
      },
    })

    if (authError) {
      setError(authError.message === 'User already registered' ? 'Este e-mail já está cadastrado.' : authError.message)
      setLoading(false)
      return
    }

    setSuccess(true)
    setLoading(false)
  }

  if (success) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-navy-800 via-navy-700 to-navy-600 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl p-8 max-w-sm w-full text-center shadow-2xl">
          <div className="text-4xl mb-4">✅</div>
          <h2 className="font-serif text-xl text-navy-700 mb-2">Verifique seu e-mail</h2>
          <p className="text-sm text-stone-500 mb-6">
            Enviamos um link de confirmação para <strong>{form.email}</strong>. Clique nele para ativar sua conta.
          </p>
          <p className="text-xs text-stone-400">
            Ao confirmar, seu perfil será criado como <strong>Membro</strong>. Você pode solicitar elevação de perfil ao administrador depois.
          </p>
          <Link href="/auth/login" className="btn btn-primary mt-6 w-full justify-center">
            Ir para login
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-navy-800 via-navy-700 to-navy-600 flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <div className="w-14 h-14 bg-gradient-to-br from-gold-400 to-gold-500 rounded-2xl flex items-center justify-center font-serif font-bold text-navy-700 text-3xl mx-auto mb-3 shadow-lg">P</div>
          <h1 className="font-serif text-2xl font-semibold text-white">PrimazIA</h1>
          <p className="text-white/50 text-xs mt-1">Criar conta</p>
        </div>

        <div className="bg-white rounded-2xl p-7 shadow-2xl">
          <h2 className="font-serif text-xl text-navy-700 mb-2">Cadastre-se</h2>
          <p className="text-xs text-stone-500 mb-5">
            Você será cadastrado como <strong>Membro</strong>. Solicite ao administrador para alterar seu perfil de acesso.
          </p>

          {error && <div className="alert-error">{error}</div>}

          <form onSubmit={handleRegister} className="space-y-4">
            <div>
              <label className="label">Nome completo</label>
              <input className="input" type="text" placeholder="Seu nome completo" value={form.name}
                onChange={e => set('name', e.target.value)} required />
            </div>
            <div>
              <label className="label">E-mail</label>
              <input className="input" type="email" placeholder="seu@email.com" value={form.email}
                onChange={e => set('email', e.target.value)} required autoComplete="email" />
            </div>
            <div>
              <label className="label">Senha (mín. 6 caracteres)</label>
              <input className="input" type="password" placeholder="••••••••" value={form.password}
                onChange={e => set('password', e.target.value)} required autoComplete="new-password" />
            </div>
            <div>
              <label className="label">Confirmar senha</label>
              <input className="input" type="password" placeholder="••••••••" value={form.confirm}
                onChange={e => set('confirm', e.target.value)} required autoComplete="new-password" />
            </div>
            <button type="submit" disabled={loading} className="btn btn-primary w-full justify-center py-2.5 text-sm">
              {loading ? 'Criando conta...' : 'Criar conta'}
            </button>
          </form>

          <div className="mt-5 pt-5 border-t border-stone-100 text-center">
            <p className="text-xs text-stone-500">
              Já tem conta?{' '}
              <Link href="/auth/login" className="text-gold-500 font-medium hover:text-gold-600">Entrar</Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
