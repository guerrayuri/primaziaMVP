'use client'

export const dynamic = 'force-dynamic'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'

export default function ResetPasswordPage() {
  const router = useRouter()
  const supabase = createClient()
  const [pass, setPass] = useState('')
  const [confirm, setConfirm] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [done, setDone] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (pass.length < 6) { setError('Mínimo 6 caracteres.'); return }
    if (pass !== confirm) { setError('Senhas não coincidem.'); return }
    setLoading(true)
    const { error: err } = await supabase.auth.updateUser({ password: pass })
    if (err) { setError(err.message); setLoading(false); return }
    setDone(true)
    setTimeout(() => router.push('/auth/login'), 2000)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-navy-800 via-navy-700 to-navy-600 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl p-7 max-w-sm w-full shadow-2xl">
        {done ? (
          <div className="text-center">
            <div className="text-4xl mb-3">✅</div>
            <h2 className="font-serif text-xl text-navy-700">Senha redefinida!</h2>
            <p className="text-sm text-stone-500 mt-2">Redirecionando para o login...</p>
          </div>
        ) : (
          <>
            <h2 className="font-serif text-xl text-navy-700 mb-5">Redefinir senha</h2>
            {error && <div className="alert-error mb-3">{error}</div>}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="label">Nova senha *</label>
                <input className="input" type="password" required value={pass} onChange={e => setPass(e.target.value)} placeholder="Mínimo 6 caracteres" />
              </div>
              <div>
                <label className="label">Confirmar senha *</label>
                <input className="input" type="password" required value={confirm} onChange={e => setConfirm(e.target.value)} />
              </div>
              <button type="submit" disabled={loading} className="btn btn-primary w-full justify-center py-2.5">
                {loading ? 'Salvando...' : 'Redefinir senha'}
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  )
}
