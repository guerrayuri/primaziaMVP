import { ImageResponse } from 'next/og'

export const size = { width: 32, height: 32 }
export const contentType = 'image/png'

export default function Icon() {
  return new ImageResponse(
    (
      <div
        style={{
          width: 32,
          height: 32,
          background: 'linear-gradient(135deg, #C9A84C, #B8922A)',
          borderRadius: 8,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: '#1B2B4B',
          fontWeight: 700,
          fontSize: 18,
          fontFamily: 'serif',
        }}
      >
        P
      </div>
    ),
    { ...size }
  )
}
