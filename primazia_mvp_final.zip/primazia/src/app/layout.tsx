import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'PrimazIA — Gestão Ministerial',
  description: 'Plataforma de gestão ministerial para igrejas',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body className="font-sans bg-stone-50 text-navy-700 antialiased">
        {children}
      </body>
    </html>
  )
}
