import { redirect } from 'next/navigation'
export default function R() { redirect('/protected/ministerios') }
