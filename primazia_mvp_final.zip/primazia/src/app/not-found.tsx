import Link from 'next/link'

export default function NotFound() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-navy-800 via-navy-700 to-navy-600 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl p-8 max-w-sm w-full text-center shadow-2xl">
        <div className="font-serif text-6xl font-bold text-navy-100 mb-4">404</div>
        <h2 className="font-serif text-xl text-navy-700 mb-2">Página não encontrada</h2>
        <p className="text-sm text-stone-500 mb-6">A página que você procura não existe ou foi movida.</p>
        <Link href="/protected/dashboard" className="btn btn-primary w-full justify-center">
          Voltar ao dashboard
        </Link>
      </div>
    </div>
  )
}
