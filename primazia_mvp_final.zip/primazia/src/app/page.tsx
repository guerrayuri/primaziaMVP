import { createClient } from '@/lib/supabase/server'
import Link from 'next/link'
import type { ChurchInfo, ServiceSchedule } from '@/lib/types/database'

export const revalidate = 60 // revalidate every minute

async function getPublicData() {
  const supabase = await createClient()
  const { data: settings } = await supabase
    .from('church_settings')
    .select('key, value')
    .in('key', ['church_info', 'service_schedule'])

  const churchInfo: ChurchInfo = settings?.find(s => s.key === 'church_info')?.value ?? {}
  const serviceSchedule: ServiceSchedule[] = settings?.find(s => s.key === 'service_schedule')?.value ?? []

  const { data: events } = await supabase
    .from('events')
    .select('id, title, event_date, location, is_free, price, status')
    .eq('status', 'published')
    .eq('is_public', true)
    .gte('event_date', new Date().toISOString().slice(0, 10))
    .order('event_date')
    .limit(4)

  const { data: notices } = await supabase
    .from('notices')
    .select('id, title, body, type')
    .eq('is_active', true)
    .eq('is_public', true)
    .order('created_at', { ascending: false })
    .limit(3)

  return { churchInfo, serviceSchedule, events: events ?? [], notices: notices ?? [] }
}

export default async function PublicPage() {
  const { churchInfo, serviceSchedule, events, notices } = await getPublicData()

  return (
    <div className="min-h-screen bg-stone-50">
      {/* HEADER */}
      <header className="bg-navy-700 text-white">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-gold-400 to-gold-500 rounded-xl flex items-center justify-center font-serif font-bold text-navy-700 text-xl">P</div>
            <div>
              <div className="font-serif text-lg font-semibold">{churchInfo.name || 'PrimazIA'}</div>
              <div className="text-[10px] text-white/50 uppercase tracking-widest">Gestão Ministerial</div>
            </div>
          </div>
          <div className="flex gap-2">
            <Link href="/auth/login" className="btn btn-sm text-white border-white/30 bg-white/10 hover:bg-white/20">
              Entrar
            </Link>
            <Link href="/auth/register" className="btn btn-sm btn-gold">
              Criar conta
            </Link>
          </div>
        </div>
      </header>

      {/* NOTICES */}
      {notices.length > 0 && (
        <div className="bg-gradient-to-r from-navy-700 to-navy-600 text-white">
          <div className="max-w-6xl mx-auto px-4 py-5">
            <div className="text-[10px] uppercase tracking-widest text-gold-300 font-semibold mb-3 flex items-center gap-2">
              <span>📢</span> Avisos
            </div>
            <div className="grid gap-3 md:grid-cols-3">
              {notices.map(n => (
                <div key={n.id} className="bg-white/10 rounded-lg p-3">
                  <div className="font-semibold text-sm mb-1">{n.title}</div>
                  <div className="text-xs text-white/70 line-clamp-3">{n.body}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      <div className="max-w-6xl mx-auto px-4 py-10">
        <div className="grid gap-8 lg:grid-cols-3">

          {/* MAIN */}
          <div className="lg:col-span-2 space-y-8">
            {/* Church info */}
            <section>
              <h1 className="font-serif text-3xl font-semibold text-navy-700 mb-2">
                {churchInfo.name || 'Nossa Igreja'}
              </h1>
              {churchInfo.vision && (
                <p className="text-stone-600 italic text-base leading-relaxed">"{churchInfo.vision}"</p>
              )}
            </section>

            {/* Events */}
            {events.length > 0 && (
              <section>
                <h2 className="font-serif text-xl text-navy-700 mb-4">Próximos Eventos</h2>
                <div className="grid gap-3 sm:grid-cols-2">
                  {events.map(ev => (
                    <div key={ev.id} className="card hover:shadow-md transition-shadow">
                      <div className="font-semibold text-sm text-navy-700 mb-1">{ev.title}</div>
                      <div className="text-xs text-stone-500 mb-2">
                        {new Date(ev.event_date + 'T12:00').toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' })}
                        {ev.location && ` · ${ev.location}`}
                      </div>
                      <div className="flex items-center justify-between">
                        <span className={`badge ${ev.is_free ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
                          {ev.is_free ? 'Gratuito' : `R$ ${Number(ev.price).toFixed(2)}`}
                        </span>
                        <Link href="/auth/login" className="btn btn-sm btn-primary text-[10px]">
                          Inscrever-se
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}
          </div>

          {/* SIDEBAR */}
          <aside className="space-y-6">
            {/* Church info card */}
            <div className="card">
              <h3 className="section-title">📍 Informações</h3>
              <div className="space-y-2 text-sm text-stone-600">
                {churchInfo.address && <div>📍 {churchInfo.address}</div>}
                {churchInfo.whatsapp && (
                  <div>
                    <a href={`https://wa.me/55${churchInfo.whatsapp.replace(/\D/g,'')}`}
                       target="_blank" rel="noopener noreferrer"
                       className="text-green-600 hover:underline">
                      💬 {churchInfo.whatsapp}
                    </a>
                  </div>
                )}
                {churchInfo.email && <div>✉️ {churchInfo.email}</div>}
              </div>
            </div>

            {/* Service schedule */}
            {serviceSchedule.length > 0 && (
              <div className="card">
                <h3 className="section-title">🗓️ Horários dos Cultos</h3>
                <div className="space-y-2">
                  {serviceSchedule.map((s, i) => (
                    <div key={i} className="border-b border-stone-100 pb-2 last:border-0 last:pb-0">
                      <div className="font-medium text-xs text-navy-700">{s.name}</div>
                      <div className="text-[11px] text-stone-500">{s.day} · {s.time}</div>
                      {s.location && <div className="text-[11px] text-stone-400">{s.location}</div>}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* CTA */}
            <div className="card bg-gradient-to-br from-navy-700 to-navy-600 text-white border-0">
              <div className="font-serif text-lg mb-2">Faça parte</div>
              <p className="text-xs text-white/70 mb-4">Crie sua conta e acesse eventos, cursos e toda a plataforma.</p>
              <Link href="/auth/register" className="btn btn-gold w-full justify-center text-xs">
                Criar conta gratuita
              </Link>
            </div>
          </aside>
        </div>
      </div>

      <footer className="border-t border-stone-200 mt-16 py-6 text-center text-xs text-stone-400">
        PrimazIA — Gestão Ministerial · {new Date().getFullYear()}
      </footer>
    </div>
  )
}
