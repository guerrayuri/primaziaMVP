'use client'

import { useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import type { Profile, RoleRequest, AuditLog, Notice, UserRole } from '@/lib/types/database'
import { ROLE_LABELS, ROLE_COLORS } from '@/lib/utils/permissions'
import { logAudit } from '@/lib/utils/audit'
import Modal from '@/components/ui/Modal'
import { ShieldCheck, Users, Bell, Activity, Database, UserCheck, UserX, Pencil, Plus, Check, X, Trash2, Eye } from 'lucide-react'

type TabId = 'users' | 'requests' | 'notices' | 'logs' | 'data'

interface Props {
  users: Profile[]
  requests: (RoleRequest & { profiles?: { full_name: string; email: string } })[]
  logs: (AuditLog & { profiles?: { full_name: string; email: string } | null })[]
  notices: (Notice & { profiles?: { full_name: string } | null })[]
  currentUserId: string
  currentUserRole: UserRole
}

export default function AdminClient({ users, requests, logs, notices, currentUserId, currentUserRole }: Props) {
  const supabase = createClient()
  const [tab, setTab] = useState<TabId>('users')
  const [localUsers, setLocalUsers] = useState(users)
  const [localRequests, setLocalRequests] = useState(requests)
  const [localNotices, setLocalNotices] = useState(notices)
  const [loading, setLoading] = useState(false)

  // User modal
  const [showUserModal, setShowUserModal] = useState(false)
  const [editUser, setEditUser] = useState<Profile | null>(null)
  const [userForm, setUserForm] = useState({ full_name: '', email: '', phone: '', role: 'member' as UserRole, is_active: true })

  // Notice modal
  const [showNoticeModal, setShowNoticeModal] = useState(false)
  const [editNotice, setEditNotice] = useState<Notice | null>(null)
  const [noticeForm, setNoticeForm] = useState({ title: '', body: '', type: 'general' as Notice['type'], is_active: true, is_public: false })

  const pendingRequests = localRequests.filter(r => r.status === 'pending')

  // ── USERS ────────────────────────────────────
  function openCreateUser() {
    setEditUser(null)
    setUserForm({ full_name: '', email: '', phone: '', role: 'member', is_active: true })
    setShowUserModal(true)
  }

  function openEditUser(u: Profile) {
    setEditUser(u)
    setUserForm({ full_name: u.full_name, email: u.email, phone: u.phone ?? '', role: u.role, is_active: u.is_active })
    setShowUserModal(true)
  }

  async function handleSaveUser(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)

    if (editUser) {
      // Update existing profile
      const { data, error } = await supabase
        .from('profiles')
        .update({
          full_name: userForm.full_name,
          phone: userForm.phone || null,
          role: userForm.role,
          is_active: userForm.is_active,
        })
        .eq('id', editUser.id)
        .select()
        .single()

      if (!error && data) {
        setLocalUsers(prev => prev.map(u => u.id === data.id ? data as Profile : u))
        await logAudit({
          action: 'edit_user_profile',
          module: 'admin',
          recordId: data.id,
          recordType: 'profile',
          oldData: { role: editUser.role, is_active: editUser.is_active },
          newData: { role: userForm.role, is_active: userForm.is_active },
        })
        setShowUserModal(false)
      }
    }
    setLoading(false)
  }

  async function handleToggleActive(userId: string, currentActive: boolean) {
    if (userId === currentUserId) { alert('Você não pode desativar sua própria conta.'); return }
    const newActive = !currentActive
    await supabase.from('profiles').update({ is_active: newActive }).eq('id', userId)
    setLocalUsers(prev => prev.map(u => u.id === userId ? { ...u, is_active: newActive } : u))
    await logAudit({
      action: newActive ? 'activate_user' : 'deactivate_user',
      module: 'admin',
      recordId: userId,
      recordType: 'profile',
    })
  }

  // ── ROLE REQUESTS ────────────────────────────
  async function handleApprove(req: RoleRequest) {
    setLoading(true)
    // Transactional RPC: validates permission + updates both tables + writes audit log atomically
    const { error } = await supabase.rpc('approve_role_request', {
      p_request_id: req.id,
      p_reviewer_id: currentUserId,
    })
    if (error) {
      alert('Erro ao aprovar: ' + error.message)
      setLoading(false)
      return
    }
    setLocalRequests(prev => prev.map(r => r.id === req.id ? { ...r, status: 'approved' as const } : r))
    setLocalUsers(prev => prev.map(u => u.id === req.user_id ? { ...u, role: req.requested_role, is_active: true } : u))
    setLoading(false)
  }

  async function handleReject(reqId: string) {
    await supabase.from('role_requests').update({
      status: 'rejected',
      reviewed_by: currentUserId,
      reviewed_at: new Date().toISOString(),
    }).eq('id', reqId)
    setLocalRequests(prev => prev.map(r => r.id === reqId ? { ...r, status: 'rejected' as const } : r))
    await logAudit({ action: 'reject_role_request', module: 'admin', recordId: reqId })
  }

  // ── NOTICES ──────────────────────────────────
  function openCreateNotice() {
    setEditNotice(null)
    setNoticeForm({ title: '', body: '', type: 'general', is_active: true, is_public: false })
    setShowNoticeModal(true)
  }

  function openEditNotice(n: Notice) {
    setEditNotice(n)
    setNoticeForm({ title: n.title, body: n.body, type: n.type, is_active: n.is_active, is_public: n.is_public })
    setShowNoticeModal(true)
  }

  async function handleSaveNotice(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    if (editNotice) {
      const { data, error } = await supabase.from('notices')
        .update({ ...noticeForm, updated_by: currentUserId })
        .eq('id', editNotice.id).select('*, profiles!created_by(full_name)').single()
      if (!error && data) {
        setLocalNotices(prev => prev.map(n => n.id === data.id ? data as Notice & { profiles: { full_name: string } | null } : n))
        setShowNoticeModal(false)
      }
    } else {
      const { data, error } = await supabase.from('notices')
        .insert({ ...noticeForm, created_by: currentUserId }).select('*, profiles!created_by(full_name)').single()
      if (!error && data) {
        setLocalNotices(prev => [data as Notice & { profiles: { full_name: string } | null }, ...prev])
        setShowNoticeModal(false)
      }
    }
    setLoading(false)
  }

  async function handleDeleteNotice(id: string) {
    if (!confirm('Remover este aviso?')) return
    await supabase.from('notices').update({ is_active: false }).eq('id', id)
    setLocalNotices(prev => prev.filter(n => n.id !== id))
  }

  async function handleToggleNotice(id: string, current: boolean) {
    await supabase.from('notices').update({ is_active: !current }).eq('id', id)
    setLocalNotices(prev => prev.map(n => n.id === id ? { ...n, is_active: !current } : n))
  }

  // ── DATA ─────────────────────────────────────
  function exportUsers() {
    window.open('/api/admin/export-users', '_blank')
  }

  const TABS: { id: TabId; label: string; icon: React.ReactNode; badge?: number }[] = [
    { id: 'users', label: 'Usuários', icon: <Users size={14} /> },
    { id: 'requests', label: 'Solicitações', icon: <UserCheck size={14} />, badge: pendingRequests.length },
    { id: 'notices', label: 'Avisos', icon: <Bell size={14} /> },
    { id: 'logs', label: 'Log de Ações', icon: <Activity size={14} /> },
    { id: 'data', label: 'Dados', icon: <Database size={14} /> },
  ]

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-2">
        <ShieldCheck size={22} className="text-gold-400" />
        <h1 className="font-serif text-2xl text-navy-700">Administração</h1>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-stone-100 rounded-lg p-1 w-full overflow-x-auto scrollbar-thin">
        {TABS.map(t => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap flex-shrink-0 ${tab === t.id ? 'bg-white text-navy-700 shadow-sm' : 'text-stone-500 hover:text-stone-700'}`}
          >
            {t.icon}
            {t.label}
            {t.badge != null && t.badge > 0 && (
              <span className="bg-red-500 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full">{t.badge}</span>
            )}
          </button>
        ))}
      </div>

      {/* ── USERS TAB ── */}
      {tab === 'users' && (
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <div className="section-title" style={{ margin: 0 }}><Users size={15} /> Usuários do sistema</div>
            <span className="text-xs text-stone-400">{localUsers.length} usuário(s)</span>
          </div>
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Nome</th><th>E-mail</th><th>Perfil</th><th>Último acesso</th><th>Status</th><th></th>
                </tr>
              </thead>
              <tbody>
                {localUsers.map(u => (
                  <tr key={u.id}>
                    <td>
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-full bg-gradient-to-br from-gold-300 to-gold-400 flex items-center justify-center text-[10px] font-bold text-navy-700 flex-shrink-0">
                          {u.full_name.charAt(0)}
                        </div>
                        <span className="font-medium">{u.full_name}</span>
                        {u.id === currentUserId && <span className="badge bg-gold-100 text-gold-600 text-[9px]">você</span>}
                      </div>
                    </td>
                    <td className="text-stone-500 text-[11px]">{u.email}</td>
                    <td>
                      <span className={`badge ${ROLE_COLORS[u.role]}`}>{ROLE_LABELS[u.role]}</span>
                    </td>
                    <td className="text-stone-400 text-[11px]">
                      {u.last_login_at ? new Date(u.last_login_at).toLocaleDateString('pt-BR') : '—'}
                    </td>
                    <td>
                      {u.is_active ? (
                        <span className="badge bg-green-100 text-green-700">Ativo</span>
                      ) : u.approved_at ? (
                        <span className="badge bg-red-100 text-red-700">Desativado</span>
                      ) : (
                        <span className="badge bg-amber-100 text-amber-700">⏳ Aguardando aprovação</span>
                      )}
                    </td>
                    <td>
                      <div className="flex gap-1">
                        <button className="btn btn-icon btn-sm" title="Editar" onClick={() => openEditUser(u)}>
                          <Pencil size={11} />
                        </button>
                        {u.id !== currentUserId && (
                          <button
                            className={`btn btn-icon btn-sm ${u.is_active ? 'btn-danger' : 'btn-success'}`}
                            title={u.is_active ? 'Desativar' : 'Ativar'}
                            onClick={() => handleToggleActive(u.id, u.is_active)}
                          >
                            {u.is_active ? <UserX size={11} /> : <UserCheck size={11} />}
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ── REQUESTS TAB ── */}
      {tab === 'requests' && (
        <div className="space-y-3">
          {localRequests.length === 0 && (
            <div className="card empty-state"><UserCheck size={32} className="mx-auto mb-2 text-stone-300" /><p>Nenhuma solicitação.</p></div>
          )}
          {localRequests.map(req => (
            <div key={req.id} className="card">
              <div className="flex flex-wrap items-start gap-3 justify-between">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="w-7 h-7 rounded-full bg-navy-100 flex items-center justify-center text-[10px] font-bold text-navy-700 flex-shrink-0">
                      {(req.profiles as { full_name: string } | undefined)?.full_name?.charAt(0) ?? '?'}
                    </div>
                    <div>
                      <span className="font-medium text-sm">{(req.profiles as { full_name: string } | undefined)?.full_name ?? '—'}</span>
                      <span className="text-stone-400 text-xs ml-2">{(req.profiles as { email: string } | undefined)?.email}</span>
                    </div>
                  </div>
                  <div className="text-xs text-stone-500 mb-2 flex flex-wrap gap-2">
                    <span>Atual: <span className={`badge ${ROLE_COLORS[req.current_role]}`}>{ROLE_LABELS[req.current_role]}</span></span>
                    <span>→ Solicita: <span className={`badge ${ROLE_COLORS[req.requested_role]}`}>{ROLE_LABELS[req.requested_role]}</span></span>
                  </div>
                  <div className="text-xs bg-stone-50 rounded-lg p-2 italic text-stone-600">
                    "{req.justification}"
                  </div>
                  <div className="text-[10px] text-stone-400 mt-1">
                    {new Date(req.created_at).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' })}
                  </div>
                </div>
                <div className="flex flex-col gap-2 items-end">
                  {req.status === 'pending' ? (
                    <>
                      <button
                        className="btn btn-success btn-sm"
                        disabled={loading}
                        onClick={() => handleApprove(req)}
                      >
                        <Check size={12} /> Aprovar
                      </button>
                      <button
                        className="btn btn-danger btn-sm"
                        onClick={() => handleReject(req.id)}
                      >
                        <X size={12} /> Rejeitar
                      </button>
                    </>
                  ) : (
                    <span className={`badge ${req.status === 'approved' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                      {req.status === 'approved' ? '✓ Aprovado' : '✕ Rejeitado'}
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ── NOTICES TAB ── */}
      {tab === 'notices' && (
        <div className="space-y-3">
          <div className="flex justify-end">
            <button className="btn btn-gold" onClick={openCreateNotice}><Plus size={14} /> Novo aviso</button>
          </div>
          {localNotices.length === 0 && (
            <div className="card empty-state"><Bell size={32} className="mx-auto mb-2 text-stone-300" /><p>Nenhum aviso criado.</p></div>
          )}
          {localNotices.map(n => (
            <div key={n.id} className="card">
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <span className="font-semibold text-sm">{n.title}</span>
                    <span className={`badge ${n.is_active ? 'bg-green-100 text-green-700' : 'bg-stone-100 text-stone-500'}`}>
                      {n.is_active ? 'Ativo' : 'Inativo'}
                    </span>
                    {n.is_public && <span className="badge bg-blue-100 text-blue-700">Público</span>}
                    <span className="badge bg-stone-100 text-stone-500">{n.type}</span>
                  </div>
                  <p className="text-xs text-stone-500 line-clamp-2">{n.body}</p>
                  <div className="text-[10px] text-stone-400 mt-1">
                    {(n.profiles as { full_name: string } | null)?.full_name ?? '—'} · {new Date(n.created_at).toLocaleDateString('pt-BR')}
                  </div>
                </div>
                <div className="flex gap-1 flex-shrink-0">
                  <button className="btn btn-icon btn-sm" title={n.is_active ? 'Desativar' : 'Ativar'} onClick={() => handleToggleNotice(n.id, n.is_active)}>
                    {n.is_active ? <Eye size={11} /> : <Eye size={11} className="opacity-40" />}
                  </button>
                  <button className="btn btn-icon btn-sm" title="Editar" onClick={() => openEditNotice(n as Notice)}>
                    <Pencil size={11} />
                  </button>
                  <button className="btn btn-icon btn-sm btn-danger" title="Remover" onClick={() => handleDeleteNotice(n.id)}>
                    <Trash2 size={11} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ── LOGS TAB ── */}
      {tab === 'logs' && (
        <div className="card">
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr><th>Data/Hora</th><th>Usuário</th><th>Ação</th><th>Módulo</th></tr>
              </thead>
              <tbody>
                {logs.length === 0 && (
                  <tr><td colSpan={4} className="text-center py-8 text-stone-400">Nenhuma ação registrada.</td></tr>
                )}
                {logs.map(l => (
                  <tr key={l.id}>
                    <td className="text-stone-400 text-[10.5px] whitespace-nowrap">
                      {new Date(l.created_at).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}
                    </td>
                    <td className="text-[11px]">{(l.profiles as { full_name: string } | null)?.full_name ?? '—'}</td>
                    <td className="text-[11px] font-mono text-stone-600">{l.action}</td>
                    <td><span className="badge bg-stone-100 text-stone-500">{l.module}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ── DATA TAB ── */}
      {tab === 'data' && (
        <div className="card">
          <div className="section-title"><Database size={15} /> Configurações do sistema</div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
            {[
              { label: 'Usuários', value: localUsers.length },
              { label: 'Solicitações', value: localRequests.length },
              { label: 'Avisos', value: localNotices.length },
              { label: 'Logs', value: logs.length },
            ].map(m => (
              <div key={m.label} className="metric-card">
                <div className="text-[10px] font-semibold uppercase tracking-wide text-stone-500 mb-1">{m.label}</div>
                <div className="font-serif text-xl text-navy-700">{m.value}</div>
              </div>
            ))}
          </div>

          <div className="alert-info mb-4">
            <span>ℹ️</span>
            <div>
              <strong>Banco de dados real (Supabase)</strong>
              <p className="mt-1">Todos os dados são armazenados com segurança no Supabase PostgreSQL com Row Level Security habilitado. Os dados persistem entre dispositivos e sessões.</p>
            </div>
          </div>

          <div className="space-y-2">
            <h3 className="text-xs font-semibold text-stone-500 uppercase tracking-wide">Ações</h3>
            <div className="flex gap-2 flex-wrap">
              <button className="btn btn-sm" onClick={exportUsers}>
                📥 Exportar usuários CSV
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── EDIT USER MODAL ── */}
      {showUserModal && (
        <Modal title={editUser ? 'Editar usuário' : 'Novo usuário'} onClose={() => setShowUserModal(false)}>
          <form onSubmit={handleSaveUser} className="space-y-3">
            <div>
              <label className="label">Nome completo</label>
              <input className="input" value={userForm.full_name} onChange={e => setUserForm(p => ({ ...p, full_name: e.target.value }))} />
            </div>
            <div>
              <label className="label">E-mail</label>
              <input className="input" type="email" value={userForm.email} disabled={!!editUser} onChange={e => setUserForm(p => ({ ...p, email: e.target.value }))} />
              {editUser && <p className="text-[10px] text-stone-400 mt-1">O e-mail não pode ser alterado aqui. Use as configurações do Supabase.</p>}
            </div>
            <div>
              <label className="label">Telefone</label>
              <input className="input" value={userForm.phone} onChange={e => setUserForm(p => ({ ...p, phone: e.target.value }))} />
            </div>
            <div>
              <label className="label">Perfil de acesso</label>
              <select
                className="input"
                value={userForm.role}
                onChange={e => setUserForm(p => ({ ...p, role: e.target.value as UserRole }))}
                disabled={editUser?.id === currentUserId}
              >
                {Object.entries(ROLE_LABELS).map(([k, v]) => (
                  <option key={k} value={k}>{v}</option>
                ))}
              </select>
              {editUser?.id === currentUserId && (
                <p className="text-[10px] text-stone-400 mt-1">Você não pode alterar seu próprio perfil.</p>
              )}
            </div>
            <div className="flex items-center gap-2">
              <label className="flex items-center gap-2 text-xs cursor-pointer">
                <input
                  type="checkbox"
                  checked={userForm.is_active}
                  disabled={editUser?.id === currentUserId}
                  onChange={e => setUserForm(p => ({ ...p, is_active: e.target.checked }))}
                />
                Conta ativa
              </label>
            </div>
            <div className="flex gap-2 justify-end pt-2 border-t border-stone-100">
              <button type="button" className="btn" onClick={() => setShowUserModal(false)}>Cancelar</button>
              <button type="submit" disabled={loading} className="btn btn-gold">
                {loading ? 'Salvando...' : '✓ Salvar'}
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* ── NOTICE MODAL ── */}
      {showNoticeModal && (
        <Modal title={editNotice ? 'Editar aviso' : 'Novo aviso'} onClose={() => setShowNoticeModal(false)}>
          <form onSubmit={handleSaveNotice} className="space-y-3">
            <div>
              <label className="label">Título *</label>
              <input className="input" required value={noticeForm.title} onChange={e => setNoticeForm(p => ({ ...p, title: e.target.value }))} placeholder="Título do aviso" />
            </div>
            <div>
              <label className="label">Conteúdo *</label>
              <textarea className="input" rows={5} required value={noticeForm.body} onChange={e => setNoticeForm(p => ({ ...p, body: e.target.value }))} placeholder="Texto do aviso..." />
            </div>
            <div>
              <label className="label">Tipo</label>
              <select className="input" value={noticeForm.type} onChange={e => setNoticeForm(p => ({ ...p, type: e.target.value as Notice['type'] }))}>
                <option value="general">Geral</option>
                <option value="urgent">Urgente</option>
                <option value="pastoral">Pastoral</option>
                <option value="event">Evento</option>
              </select>
            </div>
            <div className="flex gap-4">
              <label className="flex items-center gap-2 text-xs cursor-pointer">
                <input type="checkbox" checked={noticeForm.is_active} onChange={e => setNoticeForm(p => ({ ...p, is_active: e.target.checked }))} />
                Ativo
              </label>
              <label className="flex items-center gap-2 text-xs cursor-pointer">
                <input type="checkbox" checked={noticeForm.is_public} onChange={e => setNoticeForm(p => ({ ...p, is_public: e.target.checked }))} />
                Exibir na área pública
              </label>
            </div>
            <div className="flex gap-2 justify-end pt-2 border-t border-stone-100">
              <button type="button" className="btn" onClick={() => setShowNoticeModal(false)}>Cancelar</button>
              <button type="submit" disabled={loading} className="btn btn-gold">
                {loading ? 'Salvando...' : '✓ Publicar aviso'}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  )
}
