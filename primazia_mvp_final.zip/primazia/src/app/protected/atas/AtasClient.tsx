'use client'

import { useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import type { MeetingMinutes, UserRole } from '@/lib/types/database'
import { exportMeetingMinutesToPDF } from '@/lib/utils/export'
import { logAudit } from '@/lib/utils/audit'
import Modal from '@/components/ui/Modal'
import { Lock, FileText, Plus, Eye, Pencil, Trash2, Download } from 'lucide-react'

interface Props {
  atas: MeetingMinutes[]
  userId: string
  userRole: UserRole
}

export default function AtasClient({ atas, userId, userRole }: Props) {
  const [local, setLocal] = useState(atas)
  const [showCreate, setShowCreate] = useState(false)
  const [showView, setShowView] = useState<MeetingMinutes | null>(null)
  const [showEdit, setShowEdit] = useState<MeetingMinutes | null>(null)
  const [loading, setLoading] = useState(false)
  const [search, setSearch] = useState('')
  const [form, setForm] = useState({
    title: '', meeting_date: new Date().toISOString().slice(0, 10),
    participants: '', agenda: '', content: '', decisions: '',
    is_confidential: false,
  })

  const supabase = createClient()
  const canManage = ['super_admin', 'admin', 'pastor'].includes(userRole)

  const filtered = local.filter(a =>
    !search || a.title.toLowerCase().includes(search.toLowerCase()) || (a.participants ?? '').toLowerCase().includes(search.toLowerCase())
  )

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    const { data, error } = await supabase
      .from('meeting_minutes')
      .insert({ ...form, created_by: userId })
      .select('*, author:profiles!created_by(full_name), meeting_tasks(id,status)')
      .single()

    if (!error && data) {
      setLocal(prev => [data as MeetingMinutes, ...prev])
      await logAudit({ action: 'create_minutes', module: 'atas', recordId: data.id, recordType: 'meeting_minutes', newData: { title: form.title, confidential: form.is_confidential } })
      setShowCreate(false)
      resetForm()
    }
    setLoading(false)
  }

  async function handleEdit(e: React.FormEvent) {
    e.preventDefault()
    if (!showEdit) return
    setLoading(true)
    const { data, error } = await supabase
      .from('meeting_minutes')
      .update({ ...form, updated_by: userId })
      .eq('id', showEdit.id)
      .select('*, author:profiles!created_by(full_name), meeting_tasks(id,status)')
      .single()

    if (!error && data) {
      setLocal(prev => prev.map(a => a.id === data.id ? data as MeetingMinutes : a))
      await logAudit({ action: 'edit_minutes', module: 'atas', recordId: data.id, recordType: 'meeting_minutes' })
      setShowEdit(null)
    }
    setLoading(false)
  }

  async function handleDelete(id: string) {
    if (!confirm('Arquivar esta ata? Ela não será excluída permanentemente.')) return
    await supabase.from('meeting_minutes').update({ deleted_at: new Date().toISOString() }).eq('id', id)
    setLocal(prev => prev.filter(a => a.id !== id))
    await logAudit({ action: 'archive_minutes', module: 'atas', recordId: id })
  }

  function resetForm() {
    setForm({ title: '', meeting_date: new Date().toISOString().slice(0, 10), participants: '', agenda: '', content: '', decisions: '', is_confidential: false })
  }

  function openEdit(ata: MeetingMinutes) {
    setForm({
      title: ata.title,
      meeting_date: ata.meeting_date,
      participants: ata.participants ?? '',
      agenda: ata.agenda ?? '',
      content: ata.content ?? '',
      decisions: ata.decisions ?? '',
      is_confidential: ata.is_confidential,
    })
    setShowEdit(ata)
  }

  const FormFields = () => (
    <div className="space-y-3">
      <div>
        <label className="label">Título / Pauta *</label>
        <input className="input" required value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} placeholder="Ex: Planejamento semestral" />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="label">Data *</label>
          <input className="input" type="date" required value={form.meeting_date} onChange={e => setForm(p => ({ ...p, meeting_date: e.target.value }))} />
        </div>
        <div className="flex items-end pb-1">
          <label className="flex items-center gap-2 text-xs cursor-pointer">
            <input type="checkbox" checked={form.is_confidential} onChange={e => setForm(p => ({ ...p, is_confidential: e.target.checked }))} />
            <Lock size={12} className="text-red-500" /> Ata confidencial
          </label>
        </div>
      </div>
      <div>
        <label className="label">Participantes</label>
        <input className="input" value={form.participants} onChange={e => setForm(p => ({ ...p, participants: e.target.value }))} placeholder="Ex: Pr. João, Pr. Paulo, Diác. Lucas" />
      </div>
      <div>
        <label className="label">Pauta / Agenda</label>
        <textarea className="input" rows={3} value={form.agenda} onChange={e => setForm(p => ({ ...p, agenda: e.target.value }))} placeholder="Pontos discutidos..." />
      </div>
      <div>
        <label className="label">Conteúdo / Registro</label>
        <textarea className="input" rows={5} value={form.content} onChange={e => setForm(p => ({ ...p, content: e.target.value }))} placeholder="Registre o conteúdo da reunião..." />
      </div>
      <div>
        <label className="label">Decisões / Encaminhamentos</label>
        <textarea className="input" rows={3} value={form.decisions} onChange={e => setForm(p => ({ ...p, decisions: e.target.value }))} placeholder="Ações definidas, responsáveis, prazos..." />
      </div>
    </div>
  )

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap gap-2 items-center justify-between">
        <h1 className="font-serif text-2xl text-navy-700">Atas Pastorais</h1>
        {canManage && (
          <button className="btn btn-gold" onClick={() => { resetForm(); setShowCreate(true) }}>
            <Plus size={14} /> Nova ata
          </button>
        )}
      </div>

      <div className="card">
        <div className="mb-4">
          <input className="input max-w-sm" placeholder="Buscar ata..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>

        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr><th>Data</th><th>Título</th><th>Participantes</th><th>Tarefas</th><th>Conf.</th><th>Autor</th><th></th></tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr><td colSpan={7} className="text-center py-8 text-stone-400">Nenhuma ata registrada.</td></tr>
              )}
              {filtered.map(ata => {
                const tasks = ata.meeting_tasks ?? []
                const pending = tasks.filter((t: { status: string }) => t.status === 'pending').length
                return (
                  <tr key={ata.id}>
                    <td>{new Date(ata.meeting_date + 'T12:00').toLocaleDateString('pt-BR')}</td>
                    <td className="font-medium">{ata.title}</td>
                    <td className="text-stone-500 text-[11px] max-w-[160px] truncate">{ata.participants ?? '—'}</td>
                    <td>
                      {pending > 0 && (
                        <span className="badge bg-amber-100 text-amber-700">{pending} pendente{pending > 1 ? 's' : ''}</span>
                      )}
                    </td>
                    <td>
                      {ata.is_confidential && <span className="badge bg-red-100 text-red-700"><Lock size={10} /> Sim</span>}
                    </td>
                    <td className="text-[11px] text-stone-400">{(ata.author as { full_name: string } | null)?.full_name ?? '—'}</td>
                    <td>
                      <div className="flex gap-1">
                        <button className="btn btn-icon btn-sm" title="Ver ata" onClick={async () => {
                          await logAudit({ action: 'view_minutes', module: 'atas', recordId: ata.id, recordType: 'meeting_minutes' })
                          setShowView(ata)
                        }}>
                          <Eye size={12} />
                        </button>
                        {canManage && (
                          <>
                            <button className="btn btn-icon btn-sm" title="Editar" onClick={() => openEdit(ata)}><Pencil size={12} /></button>
                            <button className="btn btn-icon btn-sm" title="Exportar PDF" onClick={() => exportMeetingMinutesToPDF(ata)}><Download size={12} /></button>
                            <button className="btn btn-icon btn-sm btn-danger" title="Arquivar" onClick={() => handleDelete(ata.id)}><Trash2 size={12} /></button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* View modal */}
      {showView && (
        <Modal title={showView.title} onClose={() => setShowView(null)} size="lg">
          <div className="space-y-4 text-sm">
            <div className="flex gap-3 text-xs text-stone-500">
              <span>📅 {new Date(showView.meeting_date + 'T12:00').toLocaleDateString('pt-BR', { dateStyle: 'full' })}</span>
              {showView.is_confidential && <span className="badge bg-red-100 text-red-700"><Lock size={10} /> Confidencial</span>}
            </div>
            {showView.participants && <div><div className="label">Participantes</div><div className="bg-stone-50 rounded p-3 text-xs">{showView.participants}</div></div>}
            {showView.agenda && <div><div className="label">Pauta</div><div className="bg-stone-50 rounded p-3 text-xs whitespace-pre-wrap">{showView.agenda}</div></div>}
            {showView.content && <div><div className="label">Conteúdo</div><div className="bg-stone-50 rounded p-3 text-xs whitespace-pre-wrap">{showView.content}</div></div>}
            {showView.decisions && <div><div className="label">Decisões / Encaminhamentos</div><div className="bg-stone-50 rounded p-3 text-xs whitespace-pre-wrap">{showView.decisions}</div></div>}
            <div className="flex justify-end gap-2 pt-2 border-t border-stone-100">
              <button className="btn" onClick={() => exportMeetingMinutesToPDF(showView)}><Download size={13} /> Exportar PDF</button>
              <button className="btn btn-primary" onClick={() => setShowView(null)}>Fechar</button>
            </div>
          </div>
        </Modal>
      )}

      {/* Create modal */}
      {showCreate && (
        <Modal title="Nova ata pastoral" onClose={() => setShowCreate(false)} size="lg">
          <form onSubmit={handleCreate}>
            <FormFields />
            <div className="flex gap-2 justify-end pt-3 mt-3 border-t border-stone-100">
              <button type="button" className="btn" onClick={() => setShowCreate(false)}>Cancelar</button>
              <button type="submit" disabled={loading} className="btn btn-gold">{loading ? 'Salvando...' : '✓ Registrar ata'}</button>
            </div>
          </form>
        </Modal>
      )}

      {/* Edit modal */}
      {showEdit && (
        <Modal title="Editar ata" onClose={() => setShowEdit(null)} size="lg">
          <form onSubmit={handleEdit}>
            <FormFields />
            <div className="flex gap-2 justify-end pt-3 mt-3 border-t border-stone-100">
              <button type="button" className="btn" onClick={() => setShowEdit(null)}>Cancelar</button>
              <button type="submit" disabled={loading} className="btn btn-gold">{loading ? 'Salvando...' : '✓ Salvar alterações'}</button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  )
}
