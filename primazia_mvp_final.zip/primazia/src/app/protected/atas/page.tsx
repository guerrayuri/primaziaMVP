import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import AtasClient from './AtasClient'

export default async function AtasPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  const { data: profile } = await supabase.from('profiles').select('role, id').eq('id', user.id).single()
  if (!profile || !['super_admin', 'admin', 'pastor'].includes(profile.role)) {
    redirect('/dashboard?error=unauthorized')
  }

  // Log access to this sensitive module
  await supabase.from('audit_logs').insert({ user_id: user.id, action: 'view_minutes_list', module: 'atas' })

  const { data: atas } = await supabase
    .from('meeting_minutes')
    .select('*, author:profiles!created_by(full_name), meeting_tasks(id, status)')
    .is('deleted_at', null)
    .order('meeting_date', { ascending: false })

  return <AtasClient atas={atas ?? []} userId={user.id} userRole={profile.role} />
}
