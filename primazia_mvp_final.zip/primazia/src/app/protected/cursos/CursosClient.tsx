'use client'

import { useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import type { Course, CourseModule, CourseLesson, UserRole } from '@/lib/types/database'
import { logAudit } from '@/lib/utils/audit'
import Modal from '@/components/ui/Modal'
import { Play, Plus, Lock, CheckCircle, ChevronDown, ChevronRight, Pencil, Trash2 } from 'lucide-react'

type CourseWithModules = Course & {
  course_modules: (CourseModule & { course_lessons: CourseLesson[] })[]
}

interface Props {
  courses: CourseWithModules[]
  myEnrollments: { course_id: string; status: string; progress_pct: number }[]
  userId: string
  userRole: UserRole
}

export default function CursosClient({ courses, myEnrollments, userId, userRole }: Props) {
  const supabase = createClient()
  const isAdmin = ['super_admin', 'admin', 'pastor'].includes(userRole)

  const [local, setLocal] = useState(courses)
  const [myEnrolls, setMyEnrolls] = useState(myEnrollments)
  const [showCreate, setShowCreate] = useState(false)
  const [showPlayer, setShowPlayer] = useState<CourseWithModules | null>(null)
  const [showAddLesson, setShowAddLesson] = useState<{ courseId: string; moduleId: string } | null>(null)
  const [showAddModule, setShowAddModule] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [expandedModule, setExpandedModule] = useState<string | null>(null)

  const [courseForm, setCourseForm] = useState({ title: '', description: '', instructor: '', workload: '', status: 'draft' as Course['status'], is_public: false })
  const [moduleForm, setModuleForm] = useState({ title: '', description: '' })
  const [lessonForm, setLessonForm] = useState({ title: '', description: '', video_url: '', duration: '', is_free: false })

  function getEnrollment(courseId: string) {
    return myEnrolls.find(e => e.course_id === courseId)
  }

  function isEnrolledActive(courseId: string) {
    const e = getEnrollment(courseId)
    return e && ['active', 'in_progress', 'completed'].includes(e.status)
  }

  async function handleEnroll(courseId: string) {
    const { data, error } = await supabase
      .from('course_enrollments')
      .insert({ course_id: courseId, user_id: userId, status: 'pending' })
      .select()
      .single()
    if (!error && data) {
      setMyEnrolls(prev => [...prev, { course_id: courseId, status: 'pending', progress_pct: 0 }])
      await logAudit({ action: 'enroll_course', module: 'cursos', recordId: courseId })
    }
  }

  async function handleCreateCourse(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    const { data, error } = await supabase
      .from('courses')
      .insert({ ...courseForm, created_by: userId })
      .select('*, course_modules(id, title, order_num, course_lessons(id, title, order_num, duration, is_free))')
      .single()
    if (!error && data) {
      setLocal(prev => [data as CourseWithModules, ...prev])
      await logAudit({ action: 'create_course', module: 'cursos', recordId: data.id, newData: { title: data.title } })
      setShowCreate(false)
      setCourseForm({ title: '', description: '', instructor: '', workload: '', status: 'draft', is_public: false })
    }
    setLoading(false)
  }

  async function handleAddModule(e: React.FormEvent) {
    e.preventDefault()
    if (!showAddModule) return
    setLoading(true)
    const course = local.find(c => c.id === showAddModule)
    const order = (course?.course_modules?.length ?? 0) + 1
    const { data, error } = await supabase
      .from('course_modules')
      .insert({ course_id: showAddModule, title: moduleForm.title, description: moduleForm.description || null, order_num: order })
      .select('id, title, order_num, course_lessons(id, title, order_num, duration, is_free)')
      .single()
    if (!error && data) {
      setLocal(prev => prev.map(c => c.id === showAddModule
        ? { ...c, course_modules: [...(c.course_modules ?? []), data as CourseModule & { course_lessons: CourseLesson[] }] }
        : c
      ))
      setShowAddModule(null)
      setModuleForm({ title: '', description: '' })
    }
    setLoading(false)
  }

  async function handleAddLesson(e: React.FormEvent) {
    e.preventDefault()
    if (!showAddLesson) return
    setLoading(true)
    const { courseId, moduleId } = showAddLesson
    const course = local.find(c => c.id === courseId)
    const mod = course?.course_modules?.find(m => m.id === moduleId)
    const order = (mod?.course_lessons?.length ?? 0) + 1
    const { data, error } = await supabase
      .from('course_lessons')
      .insert({ course_id: courseId, module_id: moduleId, title: lessonForm.title, description: lessonForm.description || null, video_url: lessonForm.video_url || null, duration: lessonForm.duration || null, is_free: lessonForm.is_free, order_num: order })
      .select()
      .single()
    if (!error && data) {
      setLocal(prev => prev.map(c => c.id === courseId
        ? {
            ...c, course_modules: c.course_modules.map(m => m.id === moduleId
              ? { ...m, course_lessons: [...(m.course_lessons ?? []), data as CourseLesson] }
              : m)
          }
        : c
      ))
      setShowAddLesson(null)
      setLessonForm({ title: '', description: '', video_url: '', duration: '', is_free: false })
    }
    setLoading(false)
  }

  async function handleDeleteCourse(id: string) {
    if (!confirm('Arquivar este curso?')) return
    await supabase.from('courses').update({ deleted_at: new Date().toISOString() }).eq('id', id)
    setLocal(prev => prev.filter(c => c.id !== id))
  }

  const STATUS_BADGE: Record<string, string> = {
    draft: 'bg-stone-100 text-stone-500',
    published: 'bg-green-100 text-green-700',
    archived: 'bg-blue-100 text-blue-700',
  }

  const myCourses = local.filter(c => isEnrolledActive(c.id))
  const available = local.filter(c => !isEnrolledActive(c.id) && (isAdmin || c.status === 'published'))

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap gap-2 items-center justify-between">
        <h1 className="font-serif text-2xl text-navy-700 flex items-center gap-2"><Play size={22} /> Cursos & Aulas</h1>
        {isAdmin && <button className="btn btn-gold" onClick={() => setShowCreate(true)}><Plus size={14} /> Novo curso</button>}
      </div>

      {/* Enrolled courses - Netflix row */}
      {myCourses.length > 0 && (
        <div>
          <div className="flex items-center gap-2 font-serif text-base font-medium text-navy-700 mb-3">
            <Play size={16} className="text-gold-400" /> Continuar assistindo
          </div>
          <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-thin">
            {myCourses.map(c => (
              <NfCard key={c.id} course={c} enrolled progress={getEnrollment(c.id)?.progress_pct ?? 0}
                onOpen={() => setShowPlayer(c)} isAdmin={isAdmin} onDelete={() => handleDeleteCourse(c.id)} />
            ))}
          </div>
        </div>
      )}

      {/* Available courses */}
      {available.length > 0 && (
        <div>
          <div className="flex items-center gap-2 font-serif text-base font-medium text-navy-700 mb-3">
            <Play size={16} className="text-gold-400" /> Cursos disponíveis
          </div>
          <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-thin">
            {available.map(c => (
              <NfCard key={c.id} course={c} enrolled={false} progress={0}
                onOpen={() => handleEnroll(c.id)} isAdmin={isAdmin}
                onDelete={() => handleDeleteCourse(c.id)} onOpenAdmin={() => setShowPlayer(c)} />
            ))}
          </div>
        </div>
      )}

      {local.length === 0 && (
        <div className="card empty-state py-16">
          <Play size={40} className="mx-auto mb-3 text-stone-300" />
          <p className="text-sm mb-1">Nenhum curso disponível ainda.</p>
          {isAdmin && <button className="btn btn-gold mt-3" onClick={() => setShowCreate(true)}><Plus size={13} /> Criar primeiro curso</button>}
        </div>
      )}

      {/* Player modal */}
      {showPlayer && (
        <Modal title={showPlayer.title} onClose={() => setShowPlayer(null)} size="xl">
          <div className="space-y-4">
            <div className="text-xs text-stone-500 flex gap-3">
              <span>{showPlayer.instructor}</span>
              {showPlayer.workload && <span>· {showPlayer.workload}</span>}
              <span className={`badge ${STATUS_BADGE[showPlayer.status]}`}>{showPlayer.status}</span>
            </div>
            {showPlayer.description && <p className="text-sm text-stone-600">{showPlayer.description}</p>}

            {isAdmin && (
              <div className="flex gap-2">
                <button className="btn btn-sm btn-primary" onClick={() => setShowAddModule(showPlayer.id)}><Plus size={12} /> Módulo</button>
              </div>
            )}

            {/* Modules & Lessons */}
            {(showPlayer.course_modules ?? []).sort((a, b) => a.order_num - b.order_num).map(mod => (
              <div key={mod.id} className="border border-stone-200 rounded-xl overflow-hidden">
                <button
                  className="w-full flex items-center justify-between px-4 py-3 bg-stone-50 hover:bg-stone-100 transition-colors"
                  onClick={() => setExpandedModule(expandedModule === mod.id ? null : mod.id)}>
                  <span className="font-medium text-sm">{mod.title}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-stone-400">{(mod.course_lessons ?? []).length} aula(s)</span>
                    {isAdmin && (
                      <button className="btn btn-icon btn-sm" onClick={e => { e.stopPropagation(); setShowAddLesson({ courseId: showPlayer.id, moduleId: mod.id }) }}><Plus size={11} /></button>
                    )}
                    {expandedModule === mod.id ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                  </div>
                </button>

                {expandedModule === mod.id && (
                  <div className="divide-y divide-stone-100">
                    {(mod.course_lessons ?? []).sort((a, b) => a.order_num - b.order_num).map(lesson => {
                      const canWatch = lesson.is_free || isEnrolledActive(showPlayer.id) || isAdmin
                      return (
                        <div key={lesson.id} className="px-4 py-3">
                          {canWatch && lesson.video_url ? (
                            <div className="mb-2">
                              <div className="font-medium text-sm mb-1">{lesson.order_num}. {lesson.title}</div>
                              {lesson.description && <div className="text-xs text-stone-500 mb-2">{lesson.description}</div>}
                              <div className="relative rounded-lg overflow-hidden bg-black" style={{ paddingTop: '56.25%' }}>
                                <iframe
                                  src={lesson.video_url}
                                  className="absolute inset-0 w-full h-full"
                                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                  allowFullScreen
                                />
                              </div>
                              {lesson.duration && <div className="text-xs text-stone-400 mt-1">Duração: {lesson.duration}</div>}
                            </div>
                          ) : (
                            <div className="flex items-center gap-3 text-stone-400">
                              <Lock size={14} />
                              <div>
                                <div className="font-medium text-sm text-stone-600">{lesson.order_num}. {lesson.title}</div>
                                <div className="text-xs">Disponível após inscrição</div>
                              </div>
                            </div>
                          )}
                        </div>
                      )
                    })}
                    {(mod.course_lessons ?? []).length === 0 && (
                      <div className="px-4 py-3 text-xs text-stone-400 italic">Nenhuma aula adicionada.</div>
                    )}
                  </div>
                )}
              </div>
            ))}

            {(showPlayer.course_modules ?? []).length === 0 && (
              <div className="alert-info">Nenhum módulo criado ainda.{isAdmin && ' Clique em "+ Módulo" para começar.'}</div>
            )}
          </div>
        </Modal>
      )}

      {/* Create course modal */}
      {showCreate && (
        <Modal title="Novo curso" onClose={() => setShowCreate(false)}>
          <form onSubmit={handleCreateCourse} className="space-y-3">
            <div><label className="label">Título *</label><input className="input" required value={courseForm.title} onChange={e => setCourseForm(p => ({ ...p, title: e.target.value }))} /></div>
            <div><label className="label">Descrição</label><textarea className="input" rows={2} value={courseForm.description} onChange={e => setCourseForm(p => ({ ...p, description: e.target.value }))} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="label">Instrutor</label><input className="input" value={courseForm.instructor} onChange={e => setCourseForm(p => ({ ...p, instructor: e.target.value }))} /></div>
              <div><label className="label">Carga horária</label><input className="input" value={courseForm.workload} onChange={e => setCourseForm(p => ({ ...p, workload: e.target.value }))} placeholder="Ex: 16h" /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="label">Status</label>
                <select className="input" value={courseForm.status} onChange={e => setCourseForm(p => ({ ...p, status: e.target.value as Course['status'] }))}>
                  <option value="draft">Rascunho</option><option value="published">Publicado</option>
                </select>
              </div>
              <div className="flex items-end pb-1">
                <label className="flex items-center gap-2 text-xs cursor-pointer">
                  <input type="checkbox" checked={courseForm.is_public} onChange={e => setCourseForm(p => ({ ...p, is_public: e.target.checked }))} /> Público
                </label>
              </div>
            </div>
            <div className="flex gap-2 justify-end pt-2 border-t border-stone-100">
              <button type="button" className="btn" onClick={() => setShowCreate(false)}>Cancelar</button>
              <button type="submit" disabled={loading} className="btn btn-gold">{loading ? 'Criando...' : '✓ Criar curso'}</button>
            </div>
          </form>
        </Modal>
      )}

      {/* Add module */}
      {showAddModule && (
        <Modal title="Novo módulo" onClose={() => setShowAddModule(null)}>
          <form onSubmit={handleAddModule} className="space-y-3">
            <div><label className="label">Título *</label><input className="input" required value={moduleForm.title} onChange={e => setModuleForm(p => ({ ...p, title: e.target.value }))} /></div>
            <div><label className="label">Descrição</label><textarea className="input" rows={2} value={moduleForm.description} onChange={e => setModuleForm(p => ({ ...p, description: e.target.value }))} /></div>
            <div className="flex gap-2 justify-end pt-2 border-t border-stone-100">
              <button type="button" className="btn" onClick={() => setShowAddModule(null)}>Cancelar</button>
              <button type="submit" disabled={loading} className="btn btn-gold">{loading ? 'Salvando...' : '✓ Adicionar módulo'}</button>
            </div>
          </form>
        </Modal>
      )}

      {/* Add lesson */}
      {showAddLesson && (
        <Modal title="Nova aula" onClose={() => setShowAddLesson(null)}>
          <form onSubmit={handleAddLesson} className="space-y-3">
            <div><label className="label">Título *</label><input className="input" required value={lessonForm.title} onChange={e => setLessonForm(p => ({ ...p, title: e.target.value }))} /></div>
            <div><label className="label">Descrição</label><input className="input" value={lessonForm.description} onChange={e => setLessonForm(p => ({ ...p, description: e.target.value }))} /></div>
            <div><label className="label">URL do vídeo (YouTube embed ou MP4)</label>
              <input className="input" value={lessonForm.video_url} onChange={e => setLessonForm(p => ({ ...p, video_url: e.target.value }))} placeholder="https://www.youtube.com/embed/..." />
              <p className="text-[10px] text-stone-400 mt-1">Use o link de incorporação do YouTube (botão Compartilhar → Incorporar → copie a URL do src)</p>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="label">Duração</label><input className="input" value={lessonForm.duration} onChange={e => setLessonForm(p => ({ ...p, duration: e.target.value }))} placeholder="Ex: 45min" /></div>
              <div className="flex items-end pb-1">
                <label className="flex items-center gap-2 text-xs cursor-pointer">
                  <input type="checkbox" checked={lessonForm.is_free} onChange={e => setLessonForm(p => ({ ...p, is_free: e.target.checked }))} /> Aula gratuita (prévia)
                </label>
              </div>
            </div>
            <div className="flex gap-2 justify-end pt-2 border-t border-stone-100">
              <button type="button" className="btn" onClick={() => setShowAddLesson(null)}>Cancelar</button>
              <button type="submit" disabled={loading} className="btn btn-gold">{loading ? 'Salvando...' : '✓ Adicionar aula'}</button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  )
}

function NfCard({ course, enrolled, progress, onOpen, onOpenAdmin, isAdmin, onDelete }: {
  course: CourseWithModules; enrolled: boolean; progress: number
  onOpen: () => void; onOpenAdmin?: () => void; isAdmin: boolean; onDelete: () => void
}) {
  const totalLessons = (course.course_modules ?? []).reduce((s, m) => s + (m.course_lessons?.length ?? 0), 0)
  return (
    <div className="nf-card flex-shrink-0 w-52 bg-navy-700 rounded-xl overflow-hidden cursor-pointer shadow-md"
      onClick={enrolled || isAdmin ? (onOpenAdmin ?? onOpen) : onOpen}>
      <div className="h-28 bg-gradient-to-br from-navy-600 to-navy-500 flex items-center justify-center relative">
        <Play size={36} className="text-white/20" />
        {enrolled && (
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-navy-400">
            <div className="h-full bg-gold-400 transition-all" style={{ width: `${progress}%` }} />
          </div>
        )}
        <div className="absolute top-2 right-2">
          <span className={`badge text-[10px] ${course.status === 'published' ? 'bg-green-500/80 text-white' : 'bg-stone-500/80 text-white'}`}>
            {course.status === 'published' ? 'Ativo' : 'Rascunho'}
          </span>
        </div>
      </div>
      <div className="p-3">
        <div className="font-semibold text-xs text-white truncate mb-1">{course.title}</div>
        <div className="text-[10.5px] text-white/50">{course.instructor} · {totalLessons} aula{totalLessons !== 1 ? 's' : ''}</div>
        <div className="flex items-center justify-between mt-2">
          {enrolled
            ? <span className="text-[10px] text-gold-300 flex items-center gap-1"><CheckCircle size={10} /> Inscrito</span>
            : <span className="text-[10px] text-white/40">+ Inscrever-se</span>}
          {isAdmin && (
            <button className="btn-icon btn-sm text-white/30 hover:text-red-400 transition-colors" onClick={e => { e.stopPropagation(); onDelete() }}>
              <Trash2 size={11} />
            </button>
          )}
        </div>
      </div>
    </div>
  )
}
