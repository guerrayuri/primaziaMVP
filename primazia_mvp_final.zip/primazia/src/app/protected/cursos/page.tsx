import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import CursosClient from './CursosClient'

export default async function CursosPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  const { data: profile } = await supabase.from('profiles').select('role, id').eq('id', user.id).single()
  if (!profile) redirect('/auth/login')

  const [{ data: courses }, { data: myEnrollments }] = await Promise.all([
    supabase.from('courses').select('*, course_modules(id, title, order_num, course_lessons(id, title, order_num, duration, is_free))').is('deleted_at', null).order('created_at', { ascending: false }),
    supabase.from('course_enrollments').select('course_id, status, progress_pct').eq('user_id', user.id),
  ])

  return (
    <CursosClient
      courses={courses ?? []}
      myEnrollments={myEnrollments ?? []}
      userId={user.id}
      userRole={profile.role}
    />
  )
}
