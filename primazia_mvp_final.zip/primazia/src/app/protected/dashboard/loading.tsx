export default function Loading() {
  return (
    <div className="space-y-5 animate-pulse">
      <div className="h-7 bg-stone-200 rounded w-64" />
      <div className="grid grid-cols-4 gap-3">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="h-20 bg-stone-200 rounded-xl" />
        ))}
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="h-48 bg-stone-200 rounded-xl" />
        <div className="h-48 bg-stone-200 rounded-xl" />
      </div>
    </div>
  )
}
