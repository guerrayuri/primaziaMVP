import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import Link from 'next/link'
import { hasRole } from '@/lib/utils/permissions'

export default async function DashboardPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  const { data: profile } = await supabase.from('profiles').select('*').eq('id', user.id).single()
  if (!profile) redirect('/auth/login')

  const role = profile.role

  // Fetch notices (always)
  const { data: notices } = await supabase
    .from('notices')
    .select('id, title, body, type, author:profiles(full_name), created_at')
    .eq('is_active', true)
    .order('created_at', { ascending: false })
    .limit(2)

  // Admin/Pastor metrics
  let metrics = { members: 0, visitorsMonth: 0, eventsActive: 0, incomeMonth: 0, expenseMonth: 0 }
  let recentActions: { action: string; user: string; dt: string }[] = []

  if (hasRole(role, 'pastor')) {
    const [mRes, vRes, eRes] = await Promise.all([
      supabase.from('members').select('id', { count: 'exact', head: true }).eq('status', 'active').is('deleted_at', null),
      supabase.from('visitors').select('id', { count: 'exact', head: true }).gte('visit_date', new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().slice(0, 10)),
      supabase.from('events').select('id', { count: 'exact', head: true }).in('status', ['published', 'full']),
    ])
    metrics.members = mRes.count ?? 0
    metrics.visitorsMonth = vRes.count ?? 0
    metrics.eventsActive = eRes.count ?? 0
  }

  if (hasRole(role, 'financial_admin')) {
    const startMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().slice(0, 10)
    const [iRes, eRes2] = await Promise.all([
      supabase.from('financial_transactions').select('amount').eq('type', 'income').eq('status', 'active').gte('transaction_date', startMonth),
      supabase.from('financial_transactions').select('amount').eq('type', 'expense').eq('status', 'active').gte('transaction_date', startMonth),
    ])
    metrics.incomeMonth = (iRes.data ?? []).reduce((s, t) => s + Number(t.amount), 0)
    metrics.expenseMonth = (eRes2.data ?? []).reduce((s, t) => s + Number(t.amount), 0)
  }

  if (hasRole(role, 'admin')) {
    const { data: logs } = await supabase
      .from('audit_logs')
      .select('action, module, created_at, profiles(full_name)')
      .order('created_at', { ascending: false })
      .limit(5)
    recentActions = (logs ?? []).map(l => ({
      action: l.action,
      user: (l.profiles as unknown as { full_name: string } | null)?.full_name ?? '—',
      dt: new Date(l.created_at).toLocaleString('pt-BR').slice(0, 14),
    }))
  }

  // Children teacher
  let myClasses: { id: string; name: string; age_range: string }[] = []
  if (role === 'teacher') {
    const { data } = await supabase.from('children_classes').select('id, name, age_range').eq('teacher_id', user.id).eq('is_active', true)
    myClasses = data ?? []
  }

  // Parent children
  let myChildren: { id: string; full_name: string; children_classes: { name: string } | null }[] = []
  if (role === 'guardian') {
    const { data } = await supabase
      .from('children_guardians')
      .select('children(id, full_name, children_classes(name))')
      .eq('profile_id', user.id)
    myChildren = (data ?? []).flatMap(d => (d.children as unknown[]) ?? []) as typeof myChildren
  }

  const brl = (v: number) => `R$ ${v.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`

  return (
    <div className="space-y-5">
      {/* Welcome */}
      <div>
        <h1 className="font-serif text-2xl text-navy-700">
          Olá, {profile.full_name.split(' ')[0]} 👋
        </h1>
        <p className="text-xs text-stone-500 mt-0.5">
          {new Date().toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' })}
        </p>
      </div>

      {/* Notices flyer */}
      {notices && notices.length > 0 && (
        <div className="bg-gradient-to-r from-navy-700 to-navy-600 rounded-xl p-4 text-white relative overflow-hidden">
          <div className="absolute right-0 bottom-0 w-32 h-32 bg-gold-400/10 rounded-full -mr-8 -mb-8" />
          <div className="text-[10px] uppercase tracking-widest text-gold-300 font-semibold mb-2 flex items-center gap-2">
            📢 Aviso da semana
          </div>
          <div className="font-serif text-lg mb-1">{notices[0].title}</div>
          <div className="text-xs text-white/70 leading-relaxed line-clamp-3">{notices[0].body}</div>
          {hasRole(role, 'admin') && (
            <Link href="/admin?tab=notices" className="mt-3 inline-flex items-center gap-1 text-[10px] text-gold-300 hover:text-gold-200">
              Gerenciar avisos →
            </Link>
          )}
        </div>
      )}

      {/* Admin/Pastor metrics */}
      {hasRole(role, 'pastor') && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <MetricCard label="Membros ativos" value={String(metrics.members)} sub="cadastrados" />
          <MetricCard label="Visitantes (mês)" value={String(metrics.visitorsMonth)} sub="este mês" />
          <MetricCard label="Eventos ativos" value={String(metrics.eventsActive)} sub="publicados" />
          {hasRole(role, 'financial_admin') && (
            <MetricCard label="Receitas (mês)" value={brl(metrics.incomeMonth)} valueColor="text-green-600" sub="este mês" />
          )}
        </div>
      )}

      {/* Financial metrics */}
      {hasRole(role, 'financial_admin') && (
        <div className="grid grid-cols-3 gap-3">
          <MetricCard label="Receitas (mês)" value={brl(metrics.incomeMonth)} valueColor="text-green-600" />
          <MetricCard label="Despesas (mês)" value={brl(metrics.expenseMonth)} valueColor="text-red-600" />
          <MetricCard label="Saldo" value={brl(metrics.incomeMonth - metrics.expenseMonth)} />
        </div>
      )}

      {/* Teacher view */}
      {role === 'teacher' && myClasses.length > 0 && (
        <div className="card">
          <div className="section-title">❤️ Minhas turmas</div>
          <div className="grid gap-2 sm:grid-cols-2">
            {myClasses.map(c => (
              <Link key={c.id} href="/infantil" className="border border-stone-200 rounded-lg p-3 hover:border-gold-400 transition-colors">
                <div className="font-semibold text-sm">{c.name}</div>
                <div className="text-xs text-stone-500">{c.age_range}</div>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Guardian view */}
      {role === 'guardian' && (
        <div className="card">
          <div className="section-title">👶 Minhas crianças</div>
          {myChildren.length === 0 ? (
            <p className="text-xs text-stone-400">Nenhuma criança vinculada ao seu perfil ainda.</p>
          ) : (
            myChildren.map((c) => (
              <Link key={c.id} href="/infantil" className="flex items-center gap-3 p-2 rounded-lg hover:bg-stone-50">
                <div className="w-8 h-8 rounded-full bg-gold-100 flex items-center justify-center text-xs font-bold text-gold-600">
                  {c.full_name[0]}
                </div>
                <div>
                  <div className="font-medium text-sm">{c.full_name}</div>
                  <div className="text-xs text-stone-500">{c.children_classes?.name ?? 'Turma não definida'}</div>
                </div>
              </Link>
            ))
          )}
        </div>
      )}

      {/* Recent audit log (admin+) */}
      {hasRole(role, 'admin') && recentActions.length > 0 && (
        <div className="card">
          <div className="section-title">⚡ Últimas ações</div>
          <div className="space-y-2">
            {recentActions.map((a, i) => (
              <div key={i} className="flex items-center gap-3 py-1.5 border-b border-stone-100 last:border-0">
                <div className="w-6 h-6 rounded-full bg-navy-100 flex items-center justify-center text-[9px] font-bold text-navy-700 flex-shrink-0">
                  {a.user[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-medium truncate">{a.action}</div>
                  <div className="text-[10px] text-stone-400">{a.user} · {a.dt}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick links */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: 'Eventos', href: '/eventos', icon: '📅' },
          { label: 'Cursos', href: '/cursos', icon: '🎓' },
          { label: 'Minha área', href: '/minha-area', icon: '👤' },
          { label: 'Área pública', href: '/publica', icon: '🌐' },
        ].map(link => (
          <Link key={link.href} href={link.href}
            className="card flex flex-col items-center gap-2 py-4 hover:shadow-md transition-shadow text-center">
            <span className="text-2xl">{link.icon}</span>
            <span className="text-xs font-medium text-stone-600">{link.label}</span>
          </Link>
        ))}
      </div>
    </div>
  )
}

function MetricCard({ label, value, sub, valueColor }: { label: string; value: string; sub?: string; valueColor?: string }) {
  return (
    <div className="metric-card">
      <div className="text-[10px] font-semibold uppercase tracking-wide text-stone-500 mb-1">{label}</div>
      <div className={`font-serif text-2xl font-medium ${valueColor ?? 'text-navy-700'}`}>{value}</div>
      {sub && <div className="text-[10px] text-stone-400 mt-0.5">{sub}</div>}
    </div>
  )
}
