'use client'

import { useEffect } from 'react'

export default function Error({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error('PrimazIA error:', error)
  }, [error])

  return (
    <div className="flex items-center justify-center min-h-[60vh]">
      <div className="card text-center max-w-md w-full">
        <div className="text-4xl mb-4">⚠️</div>
        <h2 className="font-serif text-xl text-navy-700 mb-2">Algo deu errado</h2>
        <p className="text-sm text-stone-500 mb-6">
          Ocorreu um erro inesperado. Tente novamente ou entre em contato com o suporte.
        </p>
        <div className="flex gap-3 justify-center">
          <button className="btn btn-primary" onClick={reset}>
            Tentar novamente
          </button>
          <a href="/protected/dashboard" className="btn">
            Ir ao dashboard
          </a>
        </div>
      </div>
    </div>
  )
}
