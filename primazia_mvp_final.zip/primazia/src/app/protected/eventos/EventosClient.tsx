'use client'

import { useState, useMemo } from 'react'
import { createClient } from '@/lib/supabase/client'
import type { Event, EventRegistration, UserRole } from '@/lib/types/database'
import { logAudit } from '@/lib/utils/audit'
import Modal from '@/components/ui/Modal'
import { CalendarDays, Plus, Users, Pencil, Trash2, CheckCircle } from 'lucide-react'
import { exportToCSV } from '@/lib/utils/export'

interface Props {
  events: Event[]
  myRegistrations: { event_id: string; status: string }[]
  userId: string
  userRole: UserRole
}

const STATUS_BADGE: Record<string, string> = {
  draft: 'bg-stone-100 text-stone-500',
  published: 'bg-green-100 text-green-700',
  full: 'bg-amber-100 text-amber-700',
  cancelled: 'bg-red-100 text-red-700',
  finished: 'bg-blue-100 text-blue-700',
}
const STATUS_LABEL: Record<string, string> = {
  draft: 'Rascunho', published: 'Publicado', full: 'Esgotado',
  cancelled: 'Cancelado', finished: 'Encerrado',
}

export default function EventosClient({ events, myRegistrations, userId, userRole }: Props) {
  const supabase = createClient()
  const isAdmin = ['super_admin', 'admin', 'pastor'].includes(userRole)

  const [local, setLocal] = useState(events)
  // Local count of registrations per event (to avoid adding field to Event type)
  const [regCount, setRegCount] = useState<Record<string, number>>(
    () => Object.fromEntries(events.map(e => [e.id, e.inscritos ?? 0]))
  )
  const [myRegs, setMyRegs] = useState(myRegistrations)
  const [showCreate, setShowCreate] = useState(false)
  const [showEdit, setShowEdit] = useState<Event | null>(null)
  const [showInscritos, setShowInscritos] = useState<string | null>(null)
  const [inscritos, setInscritos] = useState<EventRegistration[]>([])
  const [loading, setLoading] = useState(false)
  const [filterStatus, setFilterStatus] = useState('')

  const emptyForm = {
    title: '', description: '', event_date: '', start_time: '',
    end_time: '', location: '', max_spots: 0, price: 0, is_free: true,
    status: 'draft' as Event['status'], is_public: false,
  }
  const [form, setForm] = useState(emptyForm)

  const filtered = useMemo(() =>
    local.filter(e => !filterStatus || e.status === filterStatus),
    [local, filterStatus]
  )

  function isRegistered(eventId: string) {
    return myRegs.some(r => r.event_id === eventId)
  }

  async function handleRegister(eventId: string) {
    // Use transactional RPC to prevent race condition on seat limit
    const { error } = await supabase.rpc('register_for_event', {
      p_event_id: eventId,
      p_user_id: userId,
    })
    if (error) {
      const msg = error.message.includes('full') ? 'Vagas esgotadas!'
        : error.message.includes('already registered') ? 'Você já está inscrito.'
        : error.message.includes('not open') ? 'Inscrições encerradas.'
        : 'Erro ao inscrever: ' + error.message
      alert(msg)
      return
    }
    setMyRegs(prev => [...prev, { event_id: eventId, status: 'registered' }])
    setRegCount(prev => ({ ...prev, [eventId]: (prev[eventId] ?? 0) + 1 }))
  }

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    const { data, error } = await supabase
      .from('events')
      .insert({ ...form, created_by: userId, max_spots: Number(form.max_spots), price: form.is_free ? 0 : Number(form.price) })
      .select()
      .single()
    if (!error && data) {
      setLocal(prev => [data as Event, ...prev])
      await logAudit({ action: 'create_event', module: 'eventos', recordId: data.id, newData: { title: data.title } })
      setShowCreate(false)
      setForm(emptyForm)
    }
    setLoading(false)
  }

  async function handleEdit(e: React.FormEvent) {
    e.preventDefault()
    if (!showEdit) return
    setLoading(true)
    const { data, error } = await supabase
      .from('events')
      .update({ ...form, updated_by: userId })
      .eq('id', showEdit.id)
      .select()
      .single()
    if (!error && data) {
      setLocal(prev => prev.map(ev => ev.id === data.id ? data as Event : ev))
      setShowEdit(null)
    }
    setLoading(false)
  }

  async function handleDelete(id: string) {
    if (!confirm('Arquivar este evento?')) return
    await supabase.from('events').update({ deleted_at: new Date().toISOString() }).eq('id', id)
    setLocal(prev => prev.filter(e => e.id !== id))
  }

  async function loadInscritos(eventId: string) {
    setShowInscritos(eventId)
    const { data } = await supabase
      .from('event_registrations')
      .select('*, profiles(full_name, email, phone)')
      .eq('event_id', eventId)
    setInscritos((data ?? []) as unknown as EventRegistration[])
  }

  async function updateRegStatus(regId: string, status: string) {
    await supabase.from('event_registrations').update({ status }).eq('id', regId)
    setInscritos(prev => prev.map(r => r.id === regId ? { ...r, status: status as EventRegistration['status'] } : r))
  }

  function openEdit(ev: Event) {
    setForm({
      title: ev.title, description: ev.description ?? '',
      event_date: ev.event_date, start_time: ev.start_time ?? '',
      end_time: ev.end_time ?? '', location: ev.location ?? '',
      max_spots: ev.max_spots, price: ev.price, is_free: ev.is_free,
      status: ev.status, is_public: ev.is_public,
    })
    setShowEdit(ev)
  }

  const FormFields = () => (
    <div className="space-y-3">
      <div><label className="label">Título *</label><input className="input" required value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} /></div>
      <div><label className="label">Descrição</label><textarea className="input" rows={3} value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} /></div>
      <div className="grid grid-cols-3 gap-3">
        <div><label className="label">Data *</label><input className="input" type="date" required value={form.event_date} onChange={e => setForm(p => ({ ...p, event_date: e.target.value }))} /></div>
        <div><label className="label">Início</label><input className="input" type="time" value={form.start_time} onChange={e => setForm(p => ({ ...p, start_time: e.target.value }))} /></div>
        <div><label className="label">Término</label><input className="input" type="time" value={form.end_time} onChange={e => setForm(p => ({ ...p, end_time: e.target.value }))} /></div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div><label className="label">Local</label><input className="input" value={form.location} onChange={e => setForm(p => ({ ...p, location: e.target.value }))} /></div>
        <div><label className="label">Vagas (0 = ilimitado)</label><input className="input" type="number" min="0" value={form.max_spots} onChange={e => setForm(p => ({ ...p, max_spots: parseInt(e.target.value) || 0 }))} /></div>
      </div>
      <div className="flex items-center gap-4">
        <label className="flex items-center gap-2 text-xs cursor-pointer">
          <input type="checkbox" checked={form.is_free} onChange={e => setForm(p => ({ ...p, is_free: e.target.checked, price: e.target.checked ? 0 : p.price }))} /> Gratuito
        </label>
        {!form.is_free && <div className="flex-1"><label className="label">Valor (R$)</label><input className="input" type="number" min="0" step="0.01" value={form.price} onChange={e => setForm(p => ({ ...p, price: parseFloat(e.target.value) || 0 }))} /></div>}
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div><label className="label">Status</label>
          <select className="input" value={form.status} onChange={e => setForm(p => ({ ...p, status: e.target.value as Event['status'] }))}>
            {['draft','published','full','cancelled','finished'].map(s => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}
          </select>
        </div>
        <div className="flex items-end pb-1">
          <label className="flex items-center gap-2 text-xs cursor-pointer">
            <input type="checkbox" checked={form.is_public} onChange={e => setForm(p => ({ ...p, is_public: e.target.checked }))} /> Exibir na área pública
          </label>
        </div>
      </div>
    </div>
  )

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap gap-2 items-center justify-between">
        <h1 className="font-serif text-2xl text-navy-700 flex items-center gap-2"><CalendarDays size={22} /> Eventos</h1>
        {isAdmin && <button className="btn btn-gold" onClick={() => { setForm(emptyForm); setShowCreate(true) }}><Plus size={14} /> Novo evento</button>}
      </div>

      {/* Filter */}
      <div className="flex gap-2 flex-wrap">
        <select className="input w-44" value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
          <option value="">Todos os status</option>
          {Object.entries(STATUS_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </select>
      </div>

      {/* Events grid */}
      <div className="grid md:grid-cols-2 gap-4">
        {filtered.length === 0 && (
          <div className="col-span-2 card empty-state"><CalendarDays size={32} className="mx-auto mb-2 text-stone-300" /><p>Nenhum evento encontrado.</p></div>
        )}
        {filtered.map(ev => {
          const registered = isRegistered(ev.id)
          const registeredCount = regCount[ev.id] ?? 0
          const canRegister = ev.status === 'published' && !registered && (ev.max_spots === 0 || registeredCount < ev.max_spots)
          return (
            <div key={ev.id} className="card hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-2">
                <h3 className="font-serif text-base font-medium text-navy-700 flex-1 mr-2">{ev.title}</h3>
                <span className={`badge flex-shrink-0 ${STATUS_BADGE[ev.status]}`}>{STATUS_LABEL[ev.status]}</span>
              </div>
              {ev.description && <p className="text-xs text-stone-500 mb-3 line-clamp-2">{ev.description}</p>}
              <div className="flex flex-wrap gap-3 text-xs text-stone-500 mb-3">
                <span>📅 {new Date(ev.event_date + 'T12:00').toLocaleDateString('pt-BR')}</span>
                {ev.start_time && <span>🕐 {ev.start_time}</span>}
                {ev.location && <span>📍 {ev.location}</span>}
                <span>{ev.is_free ? '🆓 Gratuito' : `💰 R$ ${Number(ev.price).toFixed(2)}`}</span>
                {ev.max_spots > 0 && <span>🎫 {ev.max_spots} vagas</span>}
              </div>
              <div className="flex gap-2 flex-wrap">
                {!isAdmin && (
                  registered
                    ? <span className="badge bg-green-100 text-green-700"><CheckCircle size={11} /> Inscrito</span>
                    : canRegister
                      ? <button className="btn btn-gold btn-sm" onClick={() => handleRegister(ev.id)}>Inscrever-se</button>
                      : <span className="badge bg-stone-100 text-stone-500">Inscrições fechadas</span>
                )}
                {isAdmin && (
                  <>
                    <button className="btn btn-sm" onClick={() => loadInscritos(ev.id)}><Users size={12} /> Inscritos</button>
                    <button className="btn btn-sm" onClick={() => openEdit(ev)}><Pencil size={12} /> Editar</button>
                    <button className="btn btn-sm btn-danger" onClick={() => handleDelete(ev.id)}><Trash2 size={12} /></button>
                  </>
                )}
              </div>
            </div>
          )
        })}
      </div>

      {/* Create modal */}
      {showCreate && (
        <Modal title="Novo evento" onClose={() => setShowCreate(false)} size="lg">
          <form onSubmit={handleCreate}><FormFields />
            <div className="flex gap-2 justify-end pt-3 mt-3 border-t border-stone-100">
              <button type="button" className="btn" onClick={() => setShowCreate(false)}>Cancelar</button>
              <button type="submit" disabled={loading} className="btn btn-gold">{loading ? 'Salvando...' : '✓ Criar evento'}</button>
            </div>
          </form>
        </Modal>
      )}

      {/* Edit modal */}
      {showEdit && (
        <Modal title="Editar evento" onClose={() => setShowEdit(null)} size="lg">
          <form onSubmit={handleEdit}><FormFields />
            <div className="flex gap-2 justify-end pt-3 mt-3 border-t border-stone-100">
              <button type="button" className="btn" onClick={() => setShowEdit(null)}>Cancelar</button>
              <button type="submit" disabled={loading} className="btn btn-gold">{loading ? 'Salvando...' : '✓ Salvar alterações'}</button>
            </div>
          </form>
        </Modal>
      )}

      {/* Inscritos modal */}
      {showInscritos && (
        <Modal title="Inscritos no evento" onClose={() => setShowInscritos(null)} size="lg">
          <div className="mb-3">
            <button className="btn btn-sm" onClick={() => exportToCSV(inscritos.map(r => ({
              Nome: (r.profiles as { full_name: string } | null)?.full_name ?? '',
              Email: (r.profiles as { email: string } | null)?.email ?? '',
              Status: r.status,
            })), 'inscritos')}>
              📥 Exportar CSV
            </button>
          </div>
          <div className="table-wrap">
            <table className="data-table">
              <thead><tr><th>Nome</th><th>E-mail</th><th>Status</th><th>Check-in</th><th></th></tr></thead>
              <tbody>
                {inscritos.length === 0 && <tr><td colSpan={5} className="text-center py-6 text-stone-400">Nenhum inscrito.</td></tr>}
                {inscritos.map(r => (
                  <tr key={r.id}>
                    <td className="font-medium">{(r.profiles as { full_name: string } | null)?.full_name ?? '—'}</td>
                    <td className="text-stone-500 text-[11px]">{(r.profiles as { email: string } | null)?.email ?? '—'}</td>
                    <td>
                      <select className="input py-0.5 text-[11px] w-28" value={r.status}
                        onChange={e => updateRegStatus(r.id, e.target.value)}>
                        {['registered','confirmed','paid','present','absent','cancelled'].map(s => (
                          <option key={s} value={s}>{s}</option>
                        ))}
                      </select>
                    </td>
                    <td><span className={`badge ${r.checked_in ? 'bg-green-100 text-green-700' : 'bg-stone-100 text-stone-500'}`}>{r.checked_in ? 'Sim' : 'Não'}</span></td>
                    <td>
                      {!r.checked_in && (
                        <button className="btn btn-sm btn-success" onClick={async () => {
                          await supabase.from('event_registrations').update({ checked_in: true, checked_in_at: new Date().toISOString(), status: 'present' }).eq('id', r.id)
                          setInscritos(prev => prev.map(x => x.id === r.id ? { ...x, checked_in: true, status: 'present' as EventRegistration['status'] } : x))
                        }}>Check-in</button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="flex justify-end mt-3 pt-3 border-t border-stone-100">
            <button className="btn btn-primary" onClick={() => setShowInscritos(null)}>Fechar</button>
          </div>
        </Modal>
      )}
    </div>
  )
}
