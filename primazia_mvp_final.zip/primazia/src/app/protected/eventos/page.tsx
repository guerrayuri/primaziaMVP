import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import EventosClient from './EventosClient'

export default async function EventosPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  const { data: profile } = await supabase.from('profiles').select('role, id').eq('id', user.id).single()
  if (!profile) redirect('/auth/login')

  const { data: events } = await supabase
    .from('events')
    .select('*')
    .is('deleted_at', null)
    .order('event_date', { ascending: false })

  const { data: myRegs } = await supabase
    .from('event_registrations')
    .select('event_id, status')
    .eq('user_id', user.id)

  return (
    <EventosClient
      events={events ?? []}
      myRegistrations={myRegs ?? []}
      userId={user.id}
      userRole={profile.role}
    />
  )
}
