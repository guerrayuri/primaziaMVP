'use client'

import { useState, useMemo } from 'react'
import { createClient } from '@/lib/supabase/client'
import type { FinancialTransaction, FinancialCategory } from '@/lib/types/database'
import { exportToCSV, formatFinancialReport } from '@/lib/utils/export'
import { logAudit } from '@/lib/utils/audit'
import Modal from '@/components/ui/Modal'
import { TrendingUp, TrendingDown, DollarSign, Receipt, Download, Plus } from 'lucide-react'

interface Props {
  transactions: FinancialTransaction[]
  categories: FinancialCategory[]
}

const PAYMENT_METHODS = ['Dinheiro', 'PIX', 'Transferência', 'Cartão débito', 'Cartão crédito', 'Cheque', 'Outro']

export default function FinanceiroClient({ transactions, categories }: Props) {
  const [local, setLocal] = useState(transactions)
  const [showModal, setShowModal] = useState(false)
  const [loading, setLoading] = useState(false)
  const [filterType, setFilterType] = useState('')
  const [filterCat, setFilterCat] = useState('')
  const [filterStart, setFilterStart] = useState('')
  const [filterEnd, setFilterEnd] = useState('')
  const [form, setForm] = useState({
    type: 'income' as 'income' | 'expense',
    category_id: '',
    description: '',
    amount: '',
    transaction_date: new Date().toISOString().slice(0, 10),
    payment_method: '',
    reference_num: '',
    notes: '',
  })

  const supabase = createClient()

  const filtered = useMemo(() => local.filter(t => {
    if (filterType && t.type !== filterType) return false
    if (filterCat && t.category_id !== filterCat) return false
    if (filterStart && t.transaction_date < filterStart) return false
    if (filterEnd && t.transaction_date > filterEnd) return false
    return true
  }), [local, filterType, filterCat, filterStart, filterEnd])

  const totalIncome = filtered.filter(t => t.type === 'income').reduce((s, t) => s + Number(t.amount), 0)
  const totalExpense = filtered.filter(t => t.type === 'expense').reduce((s, t) => s + Number(t.amount), 0)
  const balance = totalIncome - totalExpense

  const brl = (v: number) => `R$ ${v.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!form.description || !form.amount || parseFloat(form.amount) <= 0) return
    setLoading(true)

    const { data: { user } } = await supabase.auth.getUser()
    const { data, error } = await supabase
      .from('financial_transactions')
      .insert({
        type: form.type,
        category_id: form.category_id || null,
        description: form.description,
        amount: parseFloat(form.amount),
        transaction_date: form.transaction_date,
        payment_method: form.payment_method || null,
        reference_num: form.reference_num || null,
        notes: form.notes || null,
        created_by: user?.id,
      })
      .select('*, category:financial_categories(name,type), creator:profiles!created_by(full_name)')
      .single()

    if (!error && data) {
      setLocal(prev => [data as FinancialTransaction, ...prev])
      await logAudit({
        action: `create_transaction_${form.type}`,
        module: 'financial',
        recordId: data.id,
        recordType: 'financial_transaction',
        newData: { description: form.description, amount: form.amount, type: form.type },
      })
      setShowModal(false)
      setForm({
        type: 'income', category_id: '', description: '', amount: '',
        transaction_date: new Date().toISOString().slice(0, 10),
        payment_method: '', reference_num: '', notes: '',
      })
    }
    setLoading(false)
  }

  async function handleCancel(id: string) {
    const reason = prompt('Motivo do cancelamento:')
    if (!reason) return
    const { data: { user } } = await supabase.auth.getUser()
    await supabase.from('financial_transactions').update({
      status: 'cancelled',
      cancelled_by: user?.id,
      cancelled_at: new Date().toISOString(),
      cancel_reason: reason,
    }).eq('id', id)
    setLocal(prev => prev.filter(t => t.id !== id))
    await logAudit({ action: 'cancel_transaction', module: 'financial', recordId: id, recordType: 'financial_transaction' })
  }

  const incomeCategories = categories.filter(c => c.type === 'income')
  const expenseCategories = categories.filter(c => c.type === 'expense')
  const visibleCategories = form.type === 'income' ? incomeCategories : expenseCategories

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-wrap gap-2 items-center justify-between">
        <h1 className="font-serif text-2xl text-navy-700">Financeiro</h1>
        <div className="flex gap-2">
          <button className="btn" onClick={() => exportToCSV(formatFinancialReport(filtered), `financeiro_${new Date().toISOString().slice(0,10)}`)}>
            <Download size={14} /> Exportar CSV
          </button>
          <button className="btn btn-gold" onClick={() => setShowModal(true)}>
            <Plus size={14} /> Novo lançamento
          </button>
        </div>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-3 gap-3">
        <div className="metric-card">
          <div className="flex items-center gap-2 text-[10px] font-semibold uppercase tracking-wide text-stone-500 mb-1">
            <TrendingUp size={12} className="text-green-500" /> Receitas
          </div>
          <div className="font-serif text-xl text-green-600">{brl(totalIncome)}</div>
        </div>
        <div className="metric-card">
          <div className="flex items-center gap-2 text-[10px] font-semibold uppercase tracking-wide text-stone-500 mb-1">
            <TrendingDown size={12} className="text-red-500" /> Despesas
          </div>
          <div className="font-serif text-xl text-red-600">{brl(totalExpense)}</div>
        </div>
        <div className="metric-card">
          <div className="flex items-center gap-2 text-[10px] font-semibold uppercase tracking-wide text-stone-500 mb-1">
            <DollarSign size={12} /> Saldo
          </div>
          <div className={`font-serif text-xl ${balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>{brl(balance)}</div>
        </div>
      </div>

      {/* Filters */}
      <div className="card">
        <div className="flex flex-wrap gap-2 mb-4">
          <select className="input w-36" value={filterType} onChange={e => setFilterType(e.target.value)}>
            <option value="">Tipo: todos</option>
            <option value="income">Entradas</option>
            <option value="expense">Saídas</option>
          </select>
          <select className="input w-44" value={filterCat} onChange={e => setFilterCat(e.target.value)}>
            <option value="">Categoria: todas</option>
            {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <input className="input w-36" type="date" value={filterStart} onChange={e => setFilterStart(e.target.value)} placeholder="De" />
          <input className="input w-36" type="date" value={filterEnd} onChange={e => setFilterEnd(e.target.value)} placeholder="Até" />
          {(filterType || filterCat || filterStart || filterEnd) && (
            <button className="btn btn-sm" onClick={() => { setFilterType(''); setFilterCat(''); setFilterStart(''); setFilterEnd('') }}>
              ✕ Limpar
            </button>
          )}
        </div>

        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Data</th><th>Descrição</th><th>Categoria</th>
                <th>Tipo</th><th>Valor</th><th>Comprovante</th><th>Por</th><th></th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr><td colSpan={8} className="text-center py-8 text-stone-400">Nenhum lançamento.</td></tr>
              )}
              {filtered.map(t => (
                <tr key={t.id}>
                  <td>{new Date(t.transaction_date + 'T12:00').toLocaleDateString('pt-BR')}</td>
                  <td className="font-medium max-w-[180px] truncate">{t.description}</td>
                  <td className="text-stone-500">{t.category?.name ?? '—'}</td>
                  <td>
                    <span className={`badge ${t.type === 'income' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                      {t.type === 'income' ? 'Entrada' : 'Saída'}
                    </span>
                  </td>
                  <td className={`font-semibold ${t.type === 'income' ? 'text-green-600' : 'text-red-600'}`}>
                    {brl(Number(t.amount))}
                  </td>
                  <td className="text-stone-400 text-[11px]">{t.reference_num || '—'}</td>
                  <td className="text-stone-400 text-[11px]">{t.creator?.full_name ?? '—'}</td>
                  <td>
                    <button className="btn btn-icon btn-danger btn-sm" title="Cancelar lançamento" onClick={() => handleCancel(t.id)}>
                      <Receipt size={12} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* New transaction modal */}
      {showModal && (
        <Modal title="Novo lançamento financeiro" onClose={() => setShowModal(false)}>
          <form onSubmit={handleSubmit} className="space-y-3">
            {/* Type toggle */}
            <div className="flex gap-2">
              {(['income', 'expense'] as const).map(t => (
                <button key={t} type="button"
                  className={`flex-1 py-2 rounded-lg text-xs font-semibold border transition-all ${form.type === t ? (t === 'income' ? 'bg-green-600 text-white border-green-600' : 'bg-red-600 text-white border-red-600') : 'border-stone-200 text-stone-500 hover:bg-stone-50'}`}
                  onClick={() => setForm(p => ({ ...p, type: t, category_id: '' }))}>
                  {t === 'income' ? '↑ Entrada' : '↓ Saída'}
                </button>
              ))}
            </div>

            <div>
              <label className="label">Descrição *</label>
              <input className="input" required value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} placeholder="Ex: Dízimos domingo 08/06" />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label">Valor (R$) *</label>
                <input className="input" type="number" step="0.01" min="0.01" required value={form.amount} onChange={e => setForm(p => ({ ...p, amount: e.target.value }))} placeholder="0,00" />
              </div>
              <div>
                <label className="label">Data *</label>
                <input className="input" type="date" required value={form.transaction_date} onChange={e => setForm(p => ({ ...p, transaction_date: e.target.value }))} />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label">Categoria</label>
                <select className="input" value={form.category_id} onChange={e => setForm(p => ({ ...p, category_id: e.target.value }))}>
                  <option value="">Selecione</option>
                  {visibleCategories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div>
                <label className="label">Forma de pagamento</label>
                <select className="input" value={form.payment_method} onChange={e => setForm(p => ({ ...p, payment_method: e.target.value }))}>
                  <option value="">Selecione</option>
                  {PAYMENT_METHODS.map(m => <option key={m}>{m}</option>)}
                </select>
              </div>
            </div>

            <div>
              <label className="label">Nº Comprovante / Recibo</label>
              <input className="input" value={form.reference_num} onChange={e => setForm(p => ({ ...p, reference_num: e.target.value }))} placeholder="Ex: NF-001, REC-42" />
            </div>

            <div>
              <label className="label">Observações</label>
              <textarea className="input" rows={2} value={form.notes} onChange={e => setForm(p => ({ ...p, notes: e.target.value }))} />
            </div>

            <div className="flex gap-2 justify-end pt-2 border-t border-stone-100">
              <button type="button" className="btn" onClick={() => setShowModal(false)}>Cancelar</button>
              <button type="submit" disabled={loading} className="btn btn-gold">
                {loading ? 'Salvando...' : '✓ Registrar lançamento'}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  )
}
