import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import FinanceiroClient from './FinanceiroClient'

export default async function FinanceiroPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  const { data: profile } = await supabase.from('profiles').select('role').eq('id', user.id).single()
  if (!profile || !['super_admin', 'financial_admin'].includes(profile.role)) {
    redirect('/dashboard?error=unauthorized')
  }

  const [{ data: transactions }, { data: categories }] = await Promise.all([
    supabase
      .from('financial_transactions')
      .select('*, category:financial_categories(name,type), creator:profiles!created_by(full_name)')
      .eq('status', 'active')
      .order('transaction_date', { ascending: false }),
    supabase
      .from('financial_categories')
      .select('*')
      .eq('is_active', true)
      .order('name'),
  ])

  return <FinanceiroClient transactions={transactions ?? []} categories={categories ?? []} />
}
