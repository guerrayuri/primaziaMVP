'use client'

import { useState, useMemo } from 'react'
import { createClient } from '@/lib/supabase/client'
import type { PastoralAvailability, PastoralAppointment, UserRole } from '@/lib/types/database'
import Modal from '@/components/ui/Modal'
import { logAudit } from '@/lib/utils/audit'
import { CalendarClock, Plus, Check, X, Clock } from 'lucide-react'

const TIME_SLOTS = ['08:00','09:00','10:00','11:00','14:00','15:00','16:00','17:00','18:00','19:00']
const REASONS = ['Aconselhamento', 'Reunião de liderança', 'Visita pastoral', 'Estudo bíblico', 'Casamento', 'Batismo', 'Outro']
const STATUS_COLORS: Record<string, string> = {
  requested: 'bg-amber-100 text-amber-700',
  confirmed: 'bg-green-100 text-green-700',
  done: 'bg-blue-100 text-blue-700',
  rescheduled: 'bg-purple-100 text-purple-700',
  cancelled: 'bg-red-100 text-red-700',
}
const STATUS_LABELS: Record<string, string> = {
  requested: 'Solicitado', confirmed: 'Confirmado', done: 'Realizado',
  rescheduled: 'Remarcado', cancelled: 'Cancelado',
}

interface Props {
  profile: { id: string; role: UserRole; full_name: string }
  pastors: { id: string; full_name: string }[]
  availability: PastoralAvailability[]
  appointments: PastoralAppointment[]
}

export default function GabineteClient({ profile, pastors, availability, appointments }: Props) {
  const supabase = createClient()
  const isPastor = profile.role === 'pastor'
  const isAdmin = ['super_admin', 'admin'].includes(profile.role)

  const [localAvail, setLocalAvail] = useState(availability)
  const [localAppts, setLocalAppts] = useState(appointments)
  const [showAvailModal, setShowAvailModal] = useState(false)
  const [showApptModal, setShowApptModal] = useState(false)
  const [loading, setLoading] = useState(false)

  const [availForm, setAvailForm] = useState({ date: '', slots: [] as string[] })
  const [apptForm, setApptForm] = useState({ pastor_id: pastors[0]?.id ?? '', date: '', time_slot: '', reason: 'Aconselhamento', notes: '' })

  // Available slots for selected pastor+date (for new appointment)
  const availableSlots = useMemo(() => {
    const disp = localAvail.find(a => a.pastor_id === apptForm.pastor_id && a.date === apptForm.date)
    if (!disp) return []
    const occupied = localAppts
      .filter(a => a.pastor_id === apptForm.pastor_id && a.date === apptForm.date && a.status !== 'cancelled')
      .map(a => a.time_slot)
    return disp.time_slots.filter(s => !occupied.includes(s))
  }, [localAvail, localAppts, apptForm.pastor_id, apptForm.date])

  async function handleSaveAvail(e: React.FormEvent) {
    e.preventDefault()
    if (!availForm.date || availForm.slots.length === 0) return
    setLoading(true)
    const { data, error } = await supabase
      .from('pastoral_availability')
      .upsert({ pastor_id: profile.id, date: availForm.date, time_slots: availForm.slots }, { onConflict: 'pastor_id,date' })
      .select('*, profiles(full_name)')
      .single()
    if (!error && data) {
      setLocalAvail(prev => {
        const existing = prev.findIndex(a => a.pastor_id === profile.id && a.date === availForm.date)
        if (existing >= 0) { const n = [...prev]; n[existing] = data as PastoralAvailability; return n }
        return [data as PastoralAvailability, ...prev]
      })
      setShowAvailModal(false)
      setAvailForm({ date: '', slots: [] })
    }
    setLoading(false)
  }

  async function handleNewAppt(e: React.FormEvent) {
    e.preventDefault()
    if (!apptForm.time_slot) { alert('Selecione um horário disponível.'); return }
    setLoading(true)
    const { data, error } = await supabase
      .from('pastoral_appointments')
      .insert({
        pastor_id: apptForm.pastor_id,
        requester_id: profile.id,
        date: apptForm.date,
        time_slot: apptForm.time_slot,
        reason: apptForm.reason,
        public_notes: apptForm.notes || null,
        status: 'requested',
      })
      .select('*, pastor:profiles!pastor_id(full_name), requester:profiles!requester_id(full_name, email, phone)')
      .single()
    if (!error && data) {
      setLocalAppts(prev => [data as PastoralAppointment, ...prev])
      await logAudit({ action: 'request_appointment', module: 'gabinete', recordId: data.id })
      setShowApptModal(false)
    }
    setLoading(false)
  }

  async function updateApptStatus(id: string, status: string) {
    await supabase.from('pastoral_appointments').update({ status }).eq('id', id)
    setLocalAppts(prev => prev.map(a => a.id === id ? { ...a, status: status as PastoralAppointment['status'] } : a))
    await logAudit({ action: `appointment_${status}`, module: 'gabinete', recordId: id })
  }

  const myAvail = localAvail.filter(a => isPastor ? a.pastor_id === profile.id : true)
  const myAppts = localAppts.filter(a => isPastor ? a.pastor_id === profile.id : isAdmin ? true : a.requester_id === profile.id)

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap gap-2 items-center justify-between">
        <h1 className="font-serif text-2xl text-navy-700 flex items-center gap-2"><CalendarClock size={22} /> Agenda Pastoral</h1>
        <div className="flex gap-2">
          {isPastor && (
            <button className="btn btn-primary" onClick={() => setShowAvailModal(true)}>
              <Plus size={14} /> Informar disponibilidade
            </button>
          )}
          {!isPastor && pastors.length > 0 && (
            <button className="btn btn-gold" onClick={() => setShowApptModal(true)}>
              <Plus size={14} /> Solicitar agendamento
            </button>
          )}
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {/* Availability */}
        <div className="card">
          <div className="section-title">
            <Clock size={15} /> {isPastor ? 'Minha disponibilidade' : 'Disponibilidade dos pastores'}
          </div>
          {myAvail.length === 0 ? (
            <div className="empty-state text-sm">Nenhuma disponibilidade informada.</div>
          ) : (
            <div className="space-y-3">
              {myAvail.map(a => (
                <div key={a.id} className="border border-stone-200 rounded-lg p-3">
                  <div className="flex items-center justify-between mb-2">
                    <div className="font-medium text-sm">
                      {!isPastor && <span className="text-stone-500 text-xs mr-2">{(a.profiles as { full_name: string } | null)?.full_name}</span>}
                      {new Date(a.date + 'T12:00').toLocaleDateString('pt-BR', { weekday: 'short', day: '2-digit', month: 'short' })}
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {a.time_slots.map(slot => {
                      const booked = localAppts.some(ap => ap.pastor_id === a.pastor_id && ap.date === a.date && ap.time_slot === slot && ap.status !== 'cancelled')
                      return (
                        <span key={slot} className={`badge ${booked ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-700'}`}>
                          {slot} {booked ? '(ocupado)' : '(livre)'}
                        </span>
                      )
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Appointments */}
        <div className="card">
          <div className="section-title"><CalendarClock size={15} /> Agendamentos</div>
          {myAppts.length === 0 ? (
            <div className="empty-state text-sm">Nenhum agendamento.</div>
          ) : (
            <div className="space-y-2">
              {myAppts.map(a => (
                <div key={a.id} className="border border-stone-200 rounded-lg p-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-sm">
                        {(a.pastor as { full_name: string } | null)?.full_name ?? '—'}
                        <span className="text-stone-400 text-xs ml-2">{a.time_slot}</span>
                      </div>
                      <div className="text-xs text-stone-500">
                        {new Date(a.date + 'T12:00').toLocaleDateString('pt-BR', { weekday: 'short', day: '2-digit', month: 'short' })}
                        {' · '}{a.reason}
                      </div>
                      {!isPastor && <div className="text-xs text-stone-400 mt-0.5">{(a.requester as { full_name: string } | null)?.full_name}</div>}
                    </div>
                    <span className={`badge flex-shrink-0 ${STATUS_COLORS[a.status]}`}>{STATUS_LABELS[a.status]}</span>
                  </div>
                  {/* Pastor actions */}
                  {isPastor && a.status === 'requested' && (
                    <div className="flex gap-2 mt-2">
                      <button className="btn btn-success btn-sm" onClick={() => updateApptStatus(a.id, 'confirmed')}><Check size={11} /> Confirmar</button>
                      <button className="btn btn-danger btn-sm" onClick={() => updateApptStatus(a.id, 'cancelled')}><X size={11} /> Recusar</button>
                    </div>
                  )}
                  {isPastor && a.status === 'confirmed' && (
                    <button className="btn btn-sm mt-2" onClick={() => updateApptStatus(a.id, 'done')}><Check size={11} /> Marcar como realizado</button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Pastor: inform availability */}
      {showAvailModal && (
        <Modal title="Informar disponibilidade" onClose={() => setShowAvailModal(false)}>
          <form onSubmit={handleSaveAvail} className="space-y-4">
            <div>
              <label className="label">Data *</label>
              <input className="input" type="date" required min={new Date().toISOString().slice(0,10)} value={availForm.date} onChange={e => setAvailForm(p => ({ ...p, date: e.target.value }))} />
            </div>
            <div>
              <label className="label">Horários disponíveis *</label>
              <div className="grid grid-cols-5 gap-2 mt-1">
                {TIME_SLOTS.map(s => (
                  <label key={s} className={`flex flex-col items-center p-2 rounded-lg border cursor-pointer text-xs transition-all ${availForm.slots.includes(s) ? 'bg-green-50 border-green-400 text-green-700 font-semibold' : 'border-stone-200 text-stone-500 hover:border-stone-300'}`}>
                    <input type="checkbox" className="sr-only" checked={availForm.slots.includes(s)}
                      onChange={e => setAvailForm(p => ({ ...p, slots: e.target.checked ? [...p.slots, s] : p.slots.filter(x => x !== s) }))} />
                    {s}
                  </label>
                ))}
              </div>
            </div>
            <div className="flex gap-2 justify-end pt-2 border-t border-stone-100">
              <button type="button" className="btn" onClick={() => setShowAvailModal(false)}>Cancelar</button>
              <button type="submit" disabled={loading} className="btn btn-gold">{loading ? 'Salvando...' : '✓ Salvar'}</button>
            </div>
          </form>
        </Modal>
      )}

      {/* Member: request appointment */}
      {showApptModal && (
        <Modal title="Solicitar agendamento pastoral" onClose={() => setShowApptModal(false)}>
          <form onSubmit={handleNewAppt} className="space-y-3">
            <div>
              <label className="label">Pastor *</label>
              <select className="input" value={apptForm.pastor_id} onChange={e => setApptForm(p => ({ ...p, pastor_id: e.target.value, time_slot: '' }))}>
                {pastors.map(p => <option key={p.id} value={p.id}>{p.full_name}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Data *</label>
              <input className="input" type="date" required min={new Date().toISOString().slice(0,10)} value={apptForm.date}
                onChange={e => setApptForm(p => ({ ...p, date: e.target.value, time_slot: '' }))} />
            </div>
            <div>
              <label className="label">Horário disponível *</label>
              {availableSlots.length === 0 ? (
                <div className="alert-warn">Nenhum horário disponível para esta data. Escolha outra data.</div>
              ) : (
                <div className="flex flex-wrap gap-2 mt-1">
                  {availableSlots.map(s => (
                    <button key={s} type="button"
                      className={`px-3 py-1.5 rounded-lg text-xs border font-medium transition-all ${apptForm.time_slot === s ? 'bg-gold-400 text-white border-gold-400' : 'border-stone-200 text-stone-600 hover:border-gold-400'}`}
                      onClick={() => setApptForm(p => ({ ...p, time_slot: s }))}>
                      {s}
                    </button>
                  ))}
                </div>
              )}
            </div>
            <div>
              <label className="label">Motivo *</label>
              <select className="input" value={apptForm.reason} onChange={e => setApptForm(p => ({ ...p, reason: e.target.value }))}>
                {REASONS.map(r => <option key={r}>{r}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Observações</label>
              <textarea className="input" rows={2} value={apptForm.notes} onChange={e => setApptForm(p => ({ ...p, notes: e.target.value }))} placeholder="Informações adicionais..." />
            </div>
            <div className="flex gap-2 justify-end pt-2 border-t border-stone-100">
              <button type="button" className="btn" onClick={() => setShowApptModal(false)}>Cancelar</button>
              <button type="submit" disabled={loading || availableSlots.length === 0} className="btn btn-gold">
                {loading ? 'Enviando...' : '✓ Solicitar agendamento'}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  )
}
