import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import GabineteClient from './GabineteClient'

export default async function GabinetePage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  const { data: profile } = await supabase.from('profiles').select('role, id, full_name').eq('id', user.id).single()
  if (!profile) redirect('/auth/login')

  // Fetch pastors for dropdowns
  const { data: pastors } = await supabase
    .from('profiles')
    .select('id, full_name')
    .eq('role', 'pastor')
    .eq('is_active', true)

  // Fetch availability
  const { data: availability } = await supabase
    .from('pastoral_availability')
    .select('*, profiles(full_name)')
    .gte('date', new Date().toISOString().slice(0, 10))
    .order('date')

  // Fetch appointments
  const { data: appointments } = await supabase
    .from('pastoral_appointments')
    .select('*, pastor:profiles!pastor_id(full_name), requester:profiles!requester_id(full_name, email, phone)')
    .gte('date', new Date().toISOString().slice(0, 10))
    .order('date')

  return (
    <GabineteClient
      profile={profile}
      pastors={pastors ?? []}
      availability={availability ?? []}
      appointments={appointments ?? []}
    />
  )
}
