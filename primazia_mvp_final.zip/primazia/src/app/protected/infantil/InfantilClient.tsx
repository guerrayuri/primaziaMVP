'use client'

import { useState, useMemo } from 'react'
import { createClient } from '@/lib/supabase/client'
import type { ChildrenClass, Child, UserRole } from '@/lib/types/database'
import { logAudit } from '@/lib/utils/audit'
import Modal from '@/components/ui/Modal'
import { Heart, Users, Baby, FileText, Plus, Eye, Trash2 } from 'lucide-react'

type TabId = 'classes' | 'children' | 'reports'

interface Props {
  classes: ChildrenClass[]
  criancas: Child[]
  teachers: { id: string; full_name: string }[]
  allProfiles: { id: string; full_name: string; email: string }[]
  userId: string
  userRole: UserRole
}

const BEHAVIOR_LABELS: Record<string, string> = {
  excellent: 'Excelente', good: 'Bom', regular: 'Regular', needs_attention: 'Precisa atenção'
}
const BEHAVIOR_COLORS: Record<string, string> = {
  excellent: 'bg-green-100 text-green-700', good: 'bg-blue-100 text-blue-700',
  regular: 'bg-amber-100 text-amber-700', needs_attention: 'bg-red-100 text-red-700'
}

export default function InfantilClient({ classes, criancas, teachers, allProfiles, userId, userRole }: Props) {
  const supabase = createClient()
  const [tab, setTab] = useState<TabId>('classes')
  const [localClasses, setLocalClasses] = useState(classes)
  const [localChildren, setLocalChildren] = useState(criancas)
  const [loading, setLoading] = useState(false)

  // Modals
  const [showClassModal, setShowClassModal] = useState(false)
  const [showChildModal, setShowChildModal] = useState(false)
  const [showReportModal, setShowReportModal] = useState<Child | null>(null)
  const [showViewChild, setShowViewChild] = useState<Child | null>(null)

  const isCoordPlus = ['super_admin','admin','pastor','coordinator'].includes(userRole)
  const isTeacher = userRole === 'teacher'
  const isGuardian = userRole === 'guardian'

  const [classForm, setClassForm] = useState({ name: '', age_range: '', teacher_id: '' })
  const [childForm, setChildForm] = useState({
    full_name: '', birth_date: '', class_id: '', gender: '' as '' | 'M' | 'F' | 'other',
    allergies: '', special_needs: '', guardian_id: '', consent_given: false,
  })
  const [reportForm, setReportForm] = useState({
    behavior: 'good' as 'excellent'|'good'|'regular'|'needs_attention',
    text: '', private_notes: '', visibility: 'guardians' as 'private'|'guardians'|'all_staff',
  })

  // Children for teacher: only their classes
  const visibleChildren = useMemo(() => {
    if (isTeacher) {
      const myClassIds = localClasses.map(c => c.id)
      return localChildren.filter(c => c.class_id && myClassIds.includes(c.class_id))
    }
    return localChildren
  }, [localChildren, localClasses, isTeacher])

  async function handleCreateClass(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    const teacher = teachers.find(t => t.id === classForm.teacher_id)
    const { data, error } = await supabase
      .from('children_classes')
      .insert({ name: classForm.name, age_range: classForm.age_range || null, teacher_id: classForm.teacher_id || null, created_by: userId })
      .select('*, profiles(full_name)')
      .single()
    if (!error && data) {
      setLocalClasses(prev => [...prev, data as ChildrenClass])
      setShowClassModal(false)
      setClassForm({ name: '', age_range: '', teacher_id: '' })
    }
    setLoading(false)
  }

  async function handleCreateChild(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    const { data, error } = await supabase
      .from('children')
      .insert({
        full_name: childForm.full_name,
        birth_date: childForm.birth_date || null,
        class_id: childForm.class_id || null,
        gender: childForm.gender || null,
        allergies: childForm.allergies || null,
        special_needs: childForm.special_needs || null,
        consent_given: childForm.consent_given,
        consent_date: childForm.consent_given ? new Date().toISOString() : null,
        consent_by: childForm.consent_given ? userId : null,
        created_by: userId,
      })
      .select('*, children_classes(name), children_guardians(profile_id, relationship, is_primary, profiles(full_name, email, phone))')
      .single()

    if (!error && data) {
      // Link guardian
      if (childForm.guardian_id) {
        await supabase.from('children_guardians').insert({
          child_id: data.id, profile_id: childForm.guardian_id,
          relationship: 'guardian', is_primary: true,
        })
      }
      await logAudit({ action: 'create_child', module: 'infantil', recordId: data.id, recordType: 'child', newData: { name: data.full_name } })
      setLocalChildren(prev => [...prev, data as Child])
      setShowChildModal(false)
      setChildForm({ full_name: '', birth_date: '', class_id: '', gender: '', allergies: '', special_needs: '', guardian_id: '', consent_given: false })
    }
    setLoading(false)
  }

  async function handleCreateReport(e: React.FormEvent) {
    e.preventDefault()
    if (!showReportModal) return
    setLoading(true)
    const { error } = await supabase.from('children_feedbacks').insert({
      child_id: showReportModal.id,
      behavior: reportForm.behavior,
      text: reportForm.text,
      private_notes: reportForm.private_notes || null,
      visibility: reportForm.visibility,
      teacher_id: userId,
    })
    if (!error) {
      await logAudit({ action: 'create_feedback', module: 'infantil', recordId: showReportModal.id, recordType: 'child' })
      setShowReportModal(null)
      setReportForm({ behavior: 'good', text: '', private_notes: '', visibility: 'guardians' })
    }
    setLoading(false)
  }

  async function handleDeleteClass(id: string) {
    if (!confirm('Remover turma?')) return
    await supabase.from('children_classes').update({ is_active: false }).eq('id', id)
    setLocalClasses(prev => prev.filter(c => c.id !== id))
  }

  async function handleDeleteChild(id: string, name: string) {
    if (!confirm(`Arquivar "${name}"?`)) return
    await supabase.from('children').update({ deleted_at: new Date().toISOString() }).eq('id', id)
    setLocalChildren(prev => prev.filter(c => c.id !== id))
    await logAudit({ action: 'archive_child', module: 'infantil', recordId: id })
  }

  const TABS: { id: TabId; label: string; icon: React.ReactNode }[] = [
    { id: 'classes', label: 'Turmas', icon: <Users size={14} /> },
    { id: 'children', label: 'Crianças', icon: <Baby size={14} /> },
    ...(isCoordPlus || isTeacher ? [{ id: 'reports' as TabId, label: 'Relatórios', icon: <FileText size={14} /> }] : []),
  ]

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-wrap gap-2 items-center justify-between">
        <h1 className="font-serif text-2xl text-navy-700 flex items-center gap-2"><Heart size={22} /> Ministério Infantil</h1>
        {!isGuardian && (
          <div className="flex gap-2">
            {isCoordPlus && (
              <button className="btn btn-primary" onClick={() => setShowClassModal(true)}><Plus size={14} /> Nova turma</button>
            )}
            {(isCoordPlus || isTeacher) && (
              <button className="btn btn-gold" onClick={() => setShowChildModal(true)}><Baby size={14} /> Cadastrar criança</button>
            )}
          </div>
        )}
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-3 gap-3">
        <div className="metric-card"><div className="text-[10px] font-semibold uppercase tracking-wide text-stone-500 mb-1">Turmas</div><div className="font-serif text-2xl text-navy-700">{localClasses.length}</div></div>
        <div className="metric-card"><div className="text-[10px] font-semibold uppercase tracking-wide text-stone-500 mb-1">Crianças</div><div className="font-serif text-2xl text-navy-700">{visibleChildren.length}</div></div>
        <div className="metric-card"><div className="text-[10px] font-semibold uppercase tracking-wide text-stone-500 mb-1">Famílias</div><div className="font-serif text-2xl text-navy-700">{new Set(visibleChildren.map(c => c.class_id)).size}</div></div>
      </div>

      {/* Guardian: show only their children */}
      {isGuardian ? (
        <div className="space-y-3">
          {visibleChildren.length === 0 ? (
            <div className="card empty-state"><Baby size={32} className="mx-auto mb-2 text-stone-300" /><p>Nenhuma criança vinculada ao seu perfil.</p></div>
          ) : visibleChildren.map(child => <ChildCard key={child.id} child={child} isGuardian />)}
        </div>
      ) : (
        <>
          {/* Tabs */}
          <div className="flex gap-1 bg-stone-100 rounded-lg p-1 w-fit">
            {TABS.map(t => (
              <button key={t.id} onClick={() => setTab(t.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all ${tab === t.id ? 'bg-white text-navy-700 shadow-sm' : 'text-stone-500 hover:text-stone-700'}`}>
                {t.icon}{t.label}
              </button>
            ))}
          </div>

          {/* Classes tab */}
          {tab === 'classes' && (
            <div className="grid md:grid-cols-2 gap-3">
              {localClasses.length === 0 ? (
                <div className="card col-span-2 empty-state"><Users size={32} className="mx-auto mb-2 text-stone-300" /><p>Nenhuma turma criada.</p></div>
              ) : localClasses.map(cls => {
                const count = localChildren.filter(c => c.class_id === cls.id).length
                return (
                  <div key={cls.id} className="card">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <div className="font-serif text-base font-medium text-navy-700">{cls.name}</div>
                        <div className="text-xs text-stone-500">{cls.age_range} · Prof: {(cls.profiles as { full_name: string } | null)?.full_name ?? 'A definir'}</div>
                      </div>
                      <span className="badge bg-navy-100 text-navy-700">{count} criança{count !== 1 ? 's' : ''}</span>
                    </div>
                    <div className="flex flex-wrap gap-1 mb-3">
                      {localChildren.filter(c => c.class_id === cls.id).map(c => (
                        <span key={c.id} className="text-[11px] bg-stone-100 px-2 py-0.5 rounded-full text-stone-600">{c.full_name}</span>
                      ))}
                    </div>
                    {isCoordPlus && (
                      <button className="btn btn-danger btn-sm btn-icon" onClick={() => handleDeleteClass(cls.id)}><Trash2 size={11} /></button>
                    )}
                  </div>
                )
              })}
            </div>
          )}

          {/* Children tab */}
          {tab === 'children' && (
            <div className="card">
              <div className="table-wrap">
                <table className="data-table">
                  <thead><tr><th>Nome</th><th>Nascimento</th><th>Turma</th><th>Responsável</th><th>Consentimento</th><th></th></tr></thead>
                  <tbody>
                    {visibleChildren.length === 0 && <tr><td colSpan={6} className="text-center py-8 text-stone-400">Nenhuma criança.</td></tr>}
                    {visibleChildren.map(child => {
                      const cls = localClasses.find(c => c.id === child.class_id)
                      const guardians = (child.children_guardians ?? []) as Array<{ profiles: { full_name: string } | null; is_primary: boolean }>
                      const primary = guardians.find(g => g.is_primary)
                      return (
                        <tr key={child.id}>
                          <td className="font-medium">{child.full_name}</td>
                          <td>{child.birth_date ? new Date(child.birth_date + 'T12:00').toLocaleDateString('pt-BR') : '—'}</td>
                          <td>{cls?.name ?? '—'}</td>
                          <td className="text-stone-500 text-[11px]">{primary?.profiles?.full_name ?? '—'}</td>
                          <td><span className={`badge ${child.consent_given ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>{child.consent_given ? 'Sim' : 'Não'}</span></td>
                          <td>
                            <div className="flex gap-1">
                              <button className="btn btn-icon btn-sm" onClick={() => setShowViewChild(child)}><Eye size={11} /></button>
                              {(isCoordPlus || isTeacher) && (
                                <button className="btn btn-icon btn-sm" title="Relatório" onClick={() => setShowReportModal(child)}><FileText size={11} /></button>
                              )}
                              {isCoordPlus && (
                                <button className="btn btn-icon btn-sm btn-danger" onClick={() => handleDeleteChild(child.id, child.full_name)}><Trash2 size={11} /></button>
                              )}
                            </div>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Reports tab */}
          {tab === 'reports' && (
            <div className="card">
              <div className="alert-info mb-4"><span>ℹ️</span> Selecione uma criança na aba "Crianças" e clique em "Relatório" para adicionar um feedback.</div>
              <p className="text-xs text-stone-500">Os relatórios são vinculados individualmente a cada criança e ficam visíveis conforme a configuração de visibilidade.</p>
            </div>
          )}
        </>
      )}

      {/* Modals */}
      {showClassModal && (
        <Modal title="Nova turma" onClose={() => setShowClassModal(false)}>
          <form onSubmit={handleCreateClass} className="space-y-3">
            <div><label className="label">Nome *</label><input className="input" required value={classForm.name} onChange={e => setClassForm(p => ({ ...p, name: e.target.value }))} placeholder="Ex: Primários" /></div>
            <div><label className="label">Faixa etária</label><input className="input" value={classForm.age_range} onChange={e => setClassForm(p => ({ ...p, age_range: e.target.value }))} placeholder="Ex: 7–9 anos" /></div>
            <div><label className="label">Professor responsável</label>
              <select className="input" value={classForm.teacher_id} onChange={e => setClassForm(p => ({ ...p, teacher_id: e.target.value }))}>
                <option value="">A definir</option>
                {teachers.map(t => <option key={t.id} value={t.id}>{t.full_name}</option>)}
              </select>
            </div>
            <div className="flex gap-2 justify-end pt-2 border-t border-stone-100">
              <button type="button" className="btn" onClick={() => setShowClassModal(false)}>Cancelar</button>
              <button type="submit" disabled={loading} className="btn btn-gold">{loading ? 'Salvando...' : '✓ Criar turma'}</button>
            </div>
          </form>
        </Modal>
      )}

      {showChildModal && (
        <Modal title="Cadastrar criança" onClose={() => setShowChildModal(false)}>
          <form onSubmit={handleCreateChild} className="space-y-3">
            <div><label className="label">Nome completo *</label><input className="input" required value={childForm.full_name} onChange={e => setChildForm(p => ({ ...p, full_name: e.target.value }))} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="label">Data de nascimento</label><input className="input" type="date" value={childForm.birth_date} onChange={e => setChildForm(p => ({ ...p, birth_date: e.target.value }))} /></div>
              <div><label className="label">Gênero</label>
                <select className="input" value={childForm.gender} onChange={e => setChildForm(p => ({ ...p, gender: e.target.value as '' | 'M' | 'F' | 'other' }))}>
                  <option value="">Não informar</option><option value="M">Masculino</option><option value="F">Feminino</option><option value="other">Outro</option>
                </select>
              </div>
            </div>
            <div><label className="label">Turma</label>
              <select className="input" value={childForm.class_id} onChange={e => setChildForm(p => ({ ...p, class_id: e.target.value }))}>
                <option value="">Não definida</option>
                {localClasses.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div><label className="label">Responsável (pai/mãe) *</label>
              <select className="input" required value={childForm.guardian_id} onChange={e => setChildForm(p => ({ ...p, guardian_id: e.target.value }))}>
                <option value="">Selecione...</option>
                {allProfiles.map(p => <option key={p.id} value={p.id}>{p.full_name} ({p.email})</option>)}
              </select>
            </div>
            <div><label className="label">Alergias</label><input className="input" value={childForm.allergies} onChange={e => setChildForm(p => ({ ...p, allergies: e.target.value }))} placeholder="Descreva se houver" /></div>
            <div><label className="label">Necessidades especiais</label><input className="input" value={childForm.special_needs} onChange={e => setChildForm(p => ({ ...p, special_needs: e.target.value }))} /></div>
            <label className="flex items-center gap-2 text-xs cursor-pointer p-2 bg-stone-50 rounded-lg">
              <input type="checkbox" checked={childForm.consent_given} onChange={e => setChildForm(p => ({ ...p, consent_given: e.target.checked }))} />
              Responsável deu consentimento para participação e uso de dados (LGPD)
            </label>
            <div className="flex gap-2 justify-end pt-2 border-t border-stone-100">
              <button type="button" className="btn" onClick={() => setShowChildModal(false)}>Cancelar</button>
              <button type="submit" disabled={loading} className="btn btn-gold">{loading ? 'Salvando...' : '✓ Cadastrar'}</button>
            </div>
          </form>
        </Modal>
      )}

      {showReportModal && (
        <Modal title={`Relatório — ${showReportModal.full_name}`} onClose={() => setShowReportModal(null)}>
          <form onSubmit={handleCreateReport} className="space-y-3">
            <div><label className="label">Comportamento</label>
              <div className="flex gap-2 flex-wrap">
                {(['excellent','good','regular','needs_attention'] as const).map(b => (
                  <button key={b} type="button"
                    className={`px-3 py-1.5 rounded-lg text-xs border font-medium transition-all ${reportForm.behavior === b ? BEHAVIOR_COLORS[b] + ' border-current' : 'border-stone-200 text-stone-500'}`}
                    onClick={() => setReportForm(p => ({ ...p, behavior: b }))}>
                    {BEHAVIOR_LABELS[b]}
                  </button>
                ))}
              </div>
            </div>
            <div><label className="label">Observações *</label>
              <textarea className="input" rows={3} required value={reportForm.text}
                onChange={e => setReportForm(p => ({ ...p, text: e.target.value }))}
                placeholder="Descreva o comportamento, participação, atividades..." />
            </div>
            <div><label className="label">Notas privadas (não visíveis aos pais)</label>
              <textarea className="input" rows={2} value={reportForm.private_notes}
                onChange={e => setReportForm(p => ({ ...p, private_notes: e.target.value }))}
                placeholder="Apenas para uso interno da equipe..." />
            </div>
            <div><label className="label">Visibilidade do relatório</label>
              <select className="input" value={reportForm.visibility} onChange={e => setReportForm(p => ({ ...p, visibility: e.target.value as typeof reportForm.visibility }))}>
                <option value="private">Apenas equipe interna</option>
                <option value="guardians">Responsáveis e equipe</option>
                <option value="all_staff">Toda a equipe ministerial</option>
              </select>
            </div>
            <div className="flex gap-2 justify-end pt-2 border-t border-stone-100">
              <button type="button" className="btn" onClick={() => setShowReportModal(null)}>Cancelar</button>
              <button type="submit" disabled={loading} className="btn btn-gold">{loading ? 'Salvando...' : '✓ Salvar relatório'}</button>
            </div>
          </form>
        </Modal>
      )}

      {showViewChild && (
        <Modal title={showViewChild.full_name} onClose={() => setShowViewChild(null)}>
          <div className="space-y-3 text-sm">
            {showViewChild.birth_date && <div><span className="label">Nascimento</span><div>{new Date(showViewChild.birth_date + 'T12:00').toLocaleDateString('pt-BR')}</div></div>}
            {showViewChild.allergies && <div><span className="label">Alergias</span><div className="text-red-600">{showViewChild.allergies}</div></div>}
            {showViewChild.special_needs && <div><span className="label">Necessidades especiais</span><div>{showViewChild.special_needs}</div></div>}
            <div><span className="label">Consentimento LGPD</span><div><span className={`badge ${showViewChild.consent_given ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>{showViewChild.consent_given ? 'Concedido' : 'Não concedido'}</span></div></div>
            <div className="flex gap-2 justify-end pt-2 border-t border-stone-100">
              <button className="btn btn-primary" onClick={() => setShowViewChild(null)}>Fechar</button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  )
}

function ChildCard({ child, isGuardian }: { child: Child; isGuardian?: boolean }) {
  const cls = child.children_classes as { name: string } | null
  return (
    <div className="card">
      <div className="flex items-center gap-3 mb-3">
        <div className="w-10 h-10 rounded-full bg-gold-100 flex items-center justify-center font-bold text-gold-600 text-sm flex-shrink-0">
          {child.full_name.charAt(0)}
        </div>
        <div>
          <div className="font-semibold text-sm">{child.full_name}</div>
          <div className="text-xs text-stone-500">Turma: {cls?.name ?? 'Não definida'}</div>
        </div>
      </div>
      {child.allergies && (
        <div className="text-xs text-red-600 bg-red-50 rounded p-2 mb-2">⚠️ Alergia: {child.allergies}</div>
      )}
    </div>
  )
}
