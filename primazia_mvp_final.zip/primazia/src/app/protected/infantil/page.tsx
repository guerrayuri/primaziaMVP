import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import InfantilClient from './InfantilClient'

export default async function InfantilPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  const { data: profile } = await supabase.from('profiles').select('role, id').eq('id', user.id).single()
  if (!profile) redirect('/auth/login')

  const role = profile.role

  // Only these roles can access
  if (!['super_admin','admin','pastor','coordinator','teacher','guardian'].includes(role)) {
    redirect('/dashboard?error=unauthorized')
  }

  // Log access to children module (sensitive)
  await supabase.from('audit_logs').insert({ user_id: user.id, action: 'view_children_module', module: 'infantil' })

  // Fetch classes
  const classQuery = supabase.from('children_classes').select('*, profiles(full_name)').eq('is_active', true)
  if (role === 'teacher') classQuery.eq('teacher_id', user.id)
  const { data: classes } = await classQuery

  // Fetch children (RLS handles visibility)
  const { data: children } = await supabase
    .from('children')
    .select('*, children_classes(name), children_guardians(profile_id, relationship, is_primary, profiles(full_name, email, phone))')
    .is('deleted_at', null)
    .order('full_name')

  // Fetch available teachers for class assignment
  const { data: teachers } = await supabase
    .from('profiles')
    .select('id, full_name')
    .in('role', ['teacher', 'coordinator', 'admin', 'super_admin'])
    .eq('is_active', true)

  // Fetch all profiles for guardian dropdown
  const { data: allProfiles } = await supabase
    .from('profiles')
    .select('id, full_name, email')
    .eq('is_active', true)
    .order('full_name')

  return (
    <InfantilClient
      classes={classes ?? []}
      criancas={children ?? []}
      teachers={teachers ?? []}
      allProfiles={allProfiles ?? []}
      userId={user.id}
      userRole={role}
    />
  )
}
