import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import AppShell from '@/components/layout/AppShell'
import ToastContainer from '@/components/ui/Toast'

export default async function ProtectedLayout({ children }: { children: React.ReactNode }) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) redirect('/auth/login')

  const { data: profile } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .single()

  if (!profile) {
    await supabase.auth.signOut()
    redirect('/auth/login?error=account_disabled')
  }

  // Account inactive = awaiting admin approval after self-registration
  if (!profile.is_active) {
    await supabase.auth.signOut()
    redirect('/auth/login?error=pending_approval')
  }

  // Count pending role requests (for admin bell)
  let pendingRequests = 0
  if (['super_admin', 'admin'].includes(profile.role)) {
    const { count } = await supabase
      .from('role_requests')
      .select('id', { count: 'exact', head: true })
      .eq('status', 'pending')
    pendingRequests = count ?? 0
  }

  return (
    <>
      <AppShell profile={profile} pendingRequests={pendingRequests}>
        {children}
      </AppShell>
      <ToastContainer />
    </>
  )
}
