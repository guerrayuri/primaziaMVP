'use client'

import { useState, useMemo } from 'react'
import { createClient } from '@/lib/supabase/client'
import type { Member, UserRole } from '@/lib/types/database'
import { logAudit } from '@/lib/utils/audit'
import { exportToCSV } from '@/lib/utils/export'
import Modal from '@/components/ui/Modal'
import { Users, Plus, Pencil, Trash2, Download } from 'lucide-react'

const MINISTRIES = ['Louvor','Ensino','Infantil','Diáconos','Pastoral','Evangelismo','Jovens','Mulheres','Homens','Administração','Outro']
const STATUS_OPTIONS = ['active','inactive','transferred','deceased']
const STATUS_LABELS: Record<string, string> = { active: 'Ativo', inactive: 'Inativo', transferred: 'Transferido', deceased: 'Falecido' }
const STATUS_COLORS: Record<string, string> = { active: 'bg-green-100 text-green-700', inactive: 'bg-stone-100 text-stone-500', transferred: 'bg-blue-100 text-blue-700', deceased: 'bg-stone-200 text-stone-600' }

interface Props { members: Member[]; userId: string; userRole: UserRole }

export default function MembrosClient({ members, userId, userRole }: Props) {
  const supabase = createClient()
  const isAdmin = ['super_admin','admin'].includes(userRole)

  const [local, setLocal] = useState(members)
  const [search, setSearch] = useState('')
  const [filterStatus, setFilterStatus] = useState('')
  const [filterMin, setFilterMin] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [editMember, setEditMember] = useState<Member | null>(null)
  const [loading, setLoading] = useState(false)

  const emptyForm = { full_name: '', email: '', phone: '', birth_date: '', gender: '' as Member['gender'] | '', ministry: '', status: 'active' as Member['status'], notes: '' }
  const [form, setForm] = useState(emptyForm)

  const filtered = useMemo(() => local.filter(m => {
    const q = search.toLowerCase()
    const matchQ = !q || m.full_name.toLowerCase().includes(q) || (m.email ?? '').toLowerCase().includes(q)
    const matchS = !filterStatus || m.status === filterStatus
    const matchM = !filterMin || m.ministry === filterMin
    return matchQ && matchS && matchM
  }), [local, search, filterStatus, filterMin])

  function openCreate() { setEditMember(null); setForm(emptyForm); setShowModal(true) }
  function openEdit(m: Member) {
    setEditMember(m)
    setForm({ full_name: m.full_name, email: m.email ?? '', phone: m.phone ?? '', birth_date: m.birth_date ?? '', gender: m.gender ?? '', ministry: m.ministry ?? '', status: m.status, notes: m.notes ?? '' })
    setShowModal(true)
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    const payload = { full_name: form.full_name, email: form.email || null, phone: form.phone || null, birth_date: form.birth_date || null, gender: (form.gender as Member['gender']) || null, ministry: form.ministry || null, status: form.status, notes: form.notes || null }

    if (editMember) {
      const { data, error } = await supabase.from('members').update({ ...payload, updated_by: userId }).eq('id', editMember.id).select().single()
      if (!error && data) {
        setLocal(prev => prev.map(m => m.id === data.id ? data as Member : m))
        await logAudit({ action: 'edit_member', module: 'membros', recordId: data.id, recordType: 'member' })
        setShowModal(false)
      }
    } else {
      const { data, error } = await supabase.from('members').insert({ ...payload, created_by: userId }).select().single()
      if (!error && data) {
        setLocal(prev => [data as Member, ...prev])
        await logAudit({ action: 'create_member', module: 'membros', recordId: data.id, newData: { name: data.full_name } })
        setShowModal(false)
      }
    }
    setLoading(false)
  }

  async function handleDelete(id: string, name: string) {
    if (!confirm(`Arquivar membro "${name}"?`)) return
    await supabase.from('members').update({ deleted_at: new Date().toISOString() }).eq('id', id)
    setLocal(prev => prev.filter(m => m.id !== id))
    await logAudit({ action: 'archive_member', module: 'membros', recordId: id })
  }

  const FormFields = () => (
    <div className="space-y-3">
      <div><label className="label">Nome completo *</label><input className="input" required value={form.full_name} onChange={e => setForm(p => ({ ...p, full_name: e.target.value }))} /></div>
      <div className="grid grid-cols-2 gap-3">
        <div><label className="label">E-mail</label><input className="input" type="email" value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))} /></div>
        <div><label className="label">Telefone</label><input className="input" value={form.phone} onChange={e => setForm(p => ({ ...p, phone: e.target.value }))} /></div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div><label className="label">Data de nascimento</label><input className="input" type="date" value={form.birth_date} onChange={e => setForm(p => ({ ...p, birth_date: e.target.value }))} /></div>
        <div><label className="label">Gênero</label>
          <select className="input" value={form.gender ?? ''} onChange={e => setForm(p => ({ ...p, gender: e.target.value as Member['gender'] | '' }))}>
            <option value="">Não informar</option><option value="M">Masculino</option><option value="F">Feminino</option><option value="other">Outro</option>
          </select>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div><label className="label">Ministério</label>
          <select className="input" value={form.ministry} onChange={e => setForm(p => ({ ...p, ministry: e.target.value }))}>
            <option value="">Nenhum</option>
            {MINISTRIES.map(m => <option key={m}>{m}</option>)}
          </select>
        </div>
        <div><label className="label">Status</label>
          <select className="input" value={form.status} onChange={e => setForm(p => ({ ...p, status: e.target.value as Member['status'] }))}>
            {STATUS_OPTIONS.map(s => <option key={s} value={s}>{STATUS_LABELS[s]}</option>)}
          </select>
        </div>
      </div>
      <div><label className="label">Observações</label><textarea className="input" rows={2} value={form.notes} onChange={e => setForm(p => ({ ...p, notes: e.target.value }))} /></div>
    </div>
  )

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap gap-2 items-center justify-between">
        <h1 className="font-serif text-2xl text-navy-700 flex items-center gap-2"><Users size={22} /> Membros</h1>
        <div className="flex gap-2">
          <button className="btn btn-sm" onClick={() => exportToCSV(filtered.map(m => ({ Nome: m.full_name, Email: m.email ?? '', Telefone: m.phone ?? '', Ministério: m.ministry ?? '', Status: STATUS_LABELS[m.status] })), 'membros')}>
            <Download size={13} /> CSV
          </button>
          {isAdmin && <button className="btn btn-gold" onClick={openCreate}><Plus size={14} /> Novo membro</button>}
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {STATUS_OPTIONS.map(s => (
          <div key={s} className="metric-card">
            <div className="text-[10px] font-semibold uppercase tracking-wide text-stone-500 mb-1">{STATUS_LABELS[s]}</div>
            <div className="font-serif text-2xl text-navy-700">{local.filter(m => m.status === s).length}</div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="card">
        <div className="flex flex-wrap gap-2 mb-4">
          <input className="input flex-1 min-w-[160px]" placeholder="Buscar membro..." value={search} onChange={e => setSearch(e.target.value)} />
          <select className="input w-36" value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
            <option value="">Todos status</option>
            {STATUS_OPTIONS.map(s => <option key={s} value={s}>{STATUS_LABELS[s]}</option>)}
          </select>
          <select className="input w-44" value={filterMin} onChange={e => setFilterMin(e.target.value)}>
            <option value="">Todos ministérios</option>
            {MINISTRIES.map(m => <option key={m}>{m}</option>)}
          </select>
        </div>

        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr><th>Nome</th><th>Contato</th><th>Ministério</th><th>Status</th>{isAdmin && <th></th>}</tr>
            </thead>
            <tbody>
              {filtered.length === 0 && <tr><td colSpan={5} className="text-center py-8 text-stone-400">Nenhum membro encontrado.</td></tr>}
              {filtered.map(m => (
                <tr key={m.id}>
                  <td>
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full bg-navy-100 flex items-center justify-center text-[10px] font-bold text-navy-700 flex-shrink-0">{m.full_name.charAt(0)}</div>
                      <div><div className="font-medium">{m.full_name}</div><div className="text-[10px] text-stone-400">{m.birth_date ? new Date(m.birth_date + 'T12:00').toLocaleDateString('pt-BR') : ''}</div></div>
                    </div>
                  </td>
                  <td className="text-[11px] text-stone-500"><div>{m.email ?? '—'}</div><div>{m.phone ?? '—'}</div></td>
                  <td>{m.ministry ?? '—'}</td>
                  <td><span className={`badge ${STATUS_COLORS[m.status]}`}>{STATUS_LABELS[m.status]}</span></td>
                  {isAdmin && (
                    <td>
                      <div className="flex gap-1">
                        <button className="btn btn-icon btn-sm" onClick={() => openEdit(m)}><Pencil size={11} /></button>
                        <button className="btn btn-icon btn-sm btn-danger" onClick={() => handleDelete(m.id, m.full_name)}><Trash2 size={11} /></button>
                      </div>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <Modal title={editMember ? 'Editar membro' : 'Novo membro'} onClose={() => setShowModal(false)}>
          <form onSubmit={handleSave}>
            <FormFields />
            <div className="flex gap-2 justify-end pt-3 mt-3 border-t border-stone-100">
              <button type="button" className="btn" onClick={() => setShowModal(false)}>Cancelar</button>
              <button type="submit" disabled={loading} className="btn btn-gold">{loading ? 'Salvando...' : '✓ Salvar'}</button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  )
}
