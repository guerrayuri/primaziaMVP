import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import MembrosClient from './MembrosClient'

export default async function MembrosPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  const { data: profile } = await supabase.from('profiles').select('role').eq('id', user.id).single()
  if (!profile || !['super_admin','admin','pastor'].includes(profile.role)) {
    redirect('/dashboard?error=unauthorized')
  }

  const { data: members } = await supabase
    .from('members')
    .select('*')
    .is('deleted_at', null)
    .order('full_name')

  return <MembrosClient members={members ?? []} userId={user.id} userRole={profile.role} />
}
