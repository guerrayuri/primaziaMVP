'use client'

import { useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import type { Profile, UserRole } from '@/lib/types/database'
import { ROLE_LABELS, ROLE_COLORS } from '@/lib/utils/permissions'
import { useRouter } from 'next/navigation'
import { User, Calendar, BookOpen, ArrowUp } from 'lucide-react'

interface Props {
  profile: Profile
  myEvents: { id: string; status: string; events: { title: string; event_date: string; location: string | null; status: string } | null }[]
  myCourses: { id: string; status: string; progress_pct: number; courses: { title: string; instructor: string | null; status: string } | null }[]
  pendingRequest: { id: string; requested_role: UserRole; justification: string } | null
}

export default function MinhaAreaClient({ profile, myEvents, myCourses, pendingRequest }: Props) {
  const supabase = createClient()
  const router = useRouter()

  const [editing, setEditing] = useState(false)
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({ full_name: profile.full_name, phone: profile.phone ?? '' })
  const [passForm, setPassForm] = useState({ current: '', new1: '', new2: '' })
  const [showPassForm, setShowPassForm] = useState(false)
  const [passMsg, setPassMsg] = useState('')
  const [showRoleModal, setShowRoleModal] = useState(false)
  const [roleForm, setRoleForm] = useState({ requested_role: 'coordinator' as UserRole, justification: '' })
  const [msg, setMsg] = useState('')

  async function handleSaveProfile(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    // Use safe RPC — prevents updating sensitive fields (role, is_active, etc.)
    const { error } = await supabase.rpc('update_own_profile', {
      p_full_name: form.full_name,
      p_phone: form.phone || null,
    })
    if (!error) { setEditing(false); setMsg('Perfil atualizado!'); router.refresh() }
    setLoading(false)
  }

  async function handleChangePassword(e: React.FormEvent) {
    e.preventDefault()
    if (passForm.new1.length < 6) { setPassMsg('Senha deve ter no mínimo 6 caracteres.'); return }
    if (passForm.new1 !== passForm.new2) { setPassMsg('As senhas não coincidem.'); return }
    setLoading(true)
    const { error } = await supabase.auth.updateUser({ password: passForm.new1 })
    if (error) setPassMsg('Erro: ' + error.message)
    else { setPassMsg('Senha alterada com sucesso!'); setPassForm({ current: '', new1: '', new2: '' }) }
    setLoading(false)
  }

  async function handleRoleRequest(e: React.FormEvent) {
    e.preventDefault()
    if (!roleForm.justification) return
    setLoading(true)
    await supabase.from('role_requests').insert({
      user_id: profile.id,
      current_role: profile.role,
      requested_role: roleForm.requested_role,
      justification: roleForm.justification,
      status: 'pending',
    })
    setShowRoleModal(false)
    setMsg('Solicitação enviada! Aguarde aprovação do administrador.')
    router.refresh()
    setLoading(false)
  }

  const REG_STATUS: Record<string, string> = {
    registered: 'Inscrito', confirmed: 'Confirmado', paid: 'Pago',
    present: 'Presente', absent: 'Ausente', cancelled: 'Cancelado',
  }
  const ENROLL_STATUS: Record<string, string> = {
    pending: 'Pendente', active: 'Ativo', in_progress: 'Em andamento',
    completed: 'Concluído', blocked: 'Bloqueado', cancelled: 'Cancelado',
  }

  const availableRoles = Object.entries(ROLE_LABELS)
    .filter(([k]) => k !== 'super_admin' && k !== profile.role) as [UserRole, string][]

  return (
    <div className="space-y-5 max-w-2xl">
      <h1 className="font-serif text-2xl text-navy-700 flex items-center gap-2"><User size={22} /> Minha Área</h1>

      {msg && <div className="alert-ok">{msg}</div>}

      {/* Profile card */}
      <div className="card">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-gold-400 to-gold-500 flex items-center justify-center font-serif text-lg font-bold text-navy-700">
              {profile.full_name.charAt(0)}
            </div>
            <div>
              <div className="font-semibold text-base">{profile.full_name}</div>
              <div className="text-xs text-stone-500">{profile.email}</div>
              <span className={`badge mt-1 ${ROLE_COLORS[profile.role]}`}>{ROLE_LABELS[profile.role]}</span>
            </div>
          </div>
          {!editing && (
            <button className="btn btn-sm" onClick={() => setEditing(true)}>
              Editar perfil
            </button>
          )}
        </div>

        {editing ? (
          <form onSubmit={handleSaveProfile} className="space-y-3 border-t border-stone-100 pt-4">
            <div>
              <label className="label">Nome completo</label>
              <input className="input" value={form.full_name} onChange={e => setForm(p => ({ ...p, full_name: e.target.value }))} required />
            </div>
            <div>
              <label className="label">Telefone / WhatsApp</label>
              <input className="input" value={form.phone} onChange={e => setForm(p => ({ ...p, phone: e.target.value }))} placeholder="(11) 9xxxx-xxxx" />
            </div>
            <div className="flex gap-2">
              <button type="submit" disabled={loading} className="btn btn-gold">{loading ? 'Salvando...' : '✓ Salvar'}</button>
              <button type="button" className="btn" onClick={() => setEditing(false)}>Cancelar</button>
            </div>
          </form>
        ) : (
          <div className="text-xs text-stone-500 space-y-1 border-t border-stone-100 pt-3">
            <div>📞 {profile.phone ?? 'Telefone não informado'}</div>
            <div>📧 {profile.email}</div>
            <div>📅 Membro desde {new Date(profile.created_at).toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}</div>
          </div>
        )}
      </div>

      {/* Role request */}
      {!pendingRequest ? (
        <div className="card">
          <div className="section-title"><ArrowUp size={15} /> Solicitar elevação de perfil</div>
          <p className="text-xs text-stone-500 mb-3">
            Seu perfil atual: <span className={`badge ${ROLE_COLORS[profile.role]}`}>{ROLE_LABELS[profile.role]}</span>. 
            Solicite uma mudança de perfil ao administrador.
          </p>
          <button className="btn btn-primary btn-sm" onClick={() => setShowRoleModal(true)}>
            Solicitar mudança de perfil
          </button>
        </div>
      ) : (
        <div className="alert-warn">
          <ArrowUp size={14} />
          <div>
            <strong>Solicitação pendente</strong>
            <p className="text-[11px] mt-0.5">
              Aguardando aprovação para: <span className={`badge ${ROLE_COLORS[pendingRequest.requested_role]}`}>{ROLE_LABELS[pendingRequest.requested_role]}</span>
            </p>
          </div>
        </div>
      )}

      {/* Password change */}
      <div className="card">
        <div className="section-title">🔒 Alterar senha</div>
        {!showPassForm ? (
          <button className="btn btn-sm btn-primary" onClick={() => setShowPassForm(true)}>Alterar senha</button>
        ) : (
          <form onSubmit={handleChangePassword} className="space-y-3">
            {passMsg && <div className={`${passMsg.startsWith('Erro') ? 'alert-error' : 'alert-ok'}`}>{passMsg}</div>}
            <div>
              <label className="label">Nova senha *</label>
              <input className="input" type="password" required value={passForm.new1} onChange={e => setPassForm(p => ({ ...p, new1: e.target.value }))} placeholder="Mínimo 6 caracteres" />
            </div>
            <div>
              <label className="label">Confirmar nova senha *</label>
              <input className="input" type="password" required value={passForm.new2} onChange={e => setPassForm(p => ({ ...p, new2: e.target.value }))} />
            </div>
            <div className="flex gap-2">
              <button type="submit" disabled={loading} className="btn btn-primary btn-sm">{loading ? 'Salvando...' : 'Alterar senha'}</button>
              <button type="button" className="btn btn-sm" onClick={() => setShowPassForm(false)}>Cancelar</button>
            </div>
          </form>
        )}
      </div>

      {/* My event registrations */}
      <div className="card">
        <div className="section-title"><Calendar size={15} /> Minhas inscrições em eventos</div>
        {myEvents.length === 0 ? (
          <p className="text-xs text-stone-400">Você não está inscrito em nenhum evento.</p>
        ) : (
          <div className="space-y-2">
            {myEvents.map(reg => (
              <div key={reg.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-stone-50">
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm truncate">{reg.events?.title ?? '—'}</div>
                  <div className="text-xs text-stone-500">
                    {reg.events?.event_date ? new Date(reg.events.event_date + 'T12:00').toLocaleDateString('pt-BR') : '—'}
                    {reg.events?.location ? ` · ${reg.events.location}` : ''}
                  </div>
                </div>
                <span className={`badge flex-shrink-0 ${
                  reg.status === 'present' ? 'bg-green-100 text-green-700' :
                  reg.status === 'cancelled' ? 'bg-red-100 text-red-700' :
                  'bg-stone-100 text-stone-600'
                }`}>
                  {REG_STATUS[reg.status] ?? reg.status}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* My course enrollments */}
      <div className="card">
        <div className="section-title"><BookOpen size={15} /> Meus cursos</div>
        {myCourses.length === 0 ? (
          <p className="text-xs text-stone-400">Você não está matriculado em nenhum curso.</p>
        ) : (
          <div className="space-y-2">
            {myCourses.map(enr => (
              <div key={enr.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-stone-50">
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm truncate">{enr.courses?.title ?? '—'}</div>
                  <div className="text-xs text-stone-500">{enr.courses?.instructor ?? '—'}</div>
                  {enr.progress_pct > 0 && (
                    <div className="w-full bg-stone-200 rounded h-1 mt-1">
                      <div className="h-1 bg-gold-400 rounded" style={{ width: `${enr.progress_pct}%` }} />
                    </div>
                  )}
                </div>
                <span className={`badge flex-shrink-0 ${
                  enr.status === 'active' || enr.status === 'in_progress' ? 'bg-green-100 text-green-700' :
                  enr.status === 'completed' ? 'bg-blue-100 text-blue-700' :
                  enr.status === 'pending' ? 'bg-amber-100 text-amber-700' :
                  'bg-stone-100 text-stone-600'
                }`}>
                  {ENROLL_STATUS[enr.status] ?? enr.status}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Role request modal */}
      {showRoleModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: 'rgba(27,43,75,0.5)', backdropFilter: 'blur(3px)' }} onClick={e => { if (e.target === e.currentTarget) setShowRoleModal(false) }}>
          <div className="modal-animate bg-white rounded-2xl p-6 w-full max-w-md shadow-2xl">
            <h2 className="font-serif text-lg text-navy-700 mb-4">Solicitar mudança de perfil</h2>
            <div className="alert-info mb-4">
              <span>ℹ️</span> Você continuará com seu perfil atual até a aprovação do administrador.
            </div>
            <form onSubmit={handleRoleRequest} className="space-y-3">
              <div>
                <label className="label">Perfil solicitado *</label>
                <select className="input" value={roleForm.requested_role} onChange={e => setRoleForm(p => ({ ...p, requested_role: e.target.value as UserRole }))}>
                  {availableRoles.map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select>
              </div>
              <div>
                <label className="label">Justificativa *</label>
                <textarea
                  className="input" rows={3} required
                  value={roleForm.justification}
                  onChange={e => setRoleForm(p => ({ ...p, justification: e.target.value }))}
                  placeholder="Por que você precisa deste acesso?"
                />
              </div>
              <div className="flex gap-2 justify-end pt-2 border-t border-stone-100">
                <button type="button" className="btn" onClick={() => setShowRoleModal(false)}>Cancelar</button>
                <button type="submit" disabled={loading} className="btn btn-gold">
                  {loading ? 'Enviando...' : '✓ Enviar solicitação'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
