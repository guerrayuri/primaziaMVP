import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import MinhaAreaClient from './MinhaAreaClient'

export default async function MinhaAreaPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  const { data: profile } = await supabase.from('profiles').select('*').eq('id', user.id).single()
  if (!profile) redirect('/auth/login')

  const [{ data: myEvents }, { data: myCourses }, { data: myRequest }] = await Promise.all([
    supabase
      .from('event_registrations')
      .select('*, events(title, event_date, location, status)')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false }),
    supabase
      .from('course_enrollments')
      .select('*, courses(title, instructor, status)')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false }),
    supabase
      .from('role_requests')
      .select('*')
      .eq('user_id', user.id)
      .eq('status', 'pending')
      .maybeSingle(),
  ])

  return (
    <MinhaAreaClient
      profile={profile}
      myEvents={myEvents ?? []}
      myCourses={myCourses ?? []}
      pendingRequest={myRequest ?? null}
    />
  )
}
