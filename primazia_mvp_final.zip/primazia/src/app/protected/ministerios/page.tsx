import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'

export default async function MinistriosPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  const { data: profile } = await supabase.from('profiles').select('role').eq('id', user.id).single()
  if (!profile || !['super_admin','admin','pastor'].includes(profile.role)) {
    redirect('/dashboard?error=unauthorized')
  }

  const { data: members } = await supabase
    .from('members')
    .select('id, full_name, ministry, status')
    .eq('status', 'active')
    .is('deleted_at', null)
    .order('full_name')

  const ministryNames = ['Louvor','Ensino','Infantil','Diáconos','Pastoral','Evangelismo','Jovens','Mulheres','Homens','Administração']

  const grouped = ministryNames.map(name => ({
    name,
    members: (members ?? []).filter(m => m.ministry === name),
  }))

  const noMinistry = (members ?? []).filter(m => !ministryNames.includes(m.ministry ?? ''))

  return (
    <div className="space-y-5">
      <h1 className="font-serif text-2xl text-navy-700">Ministérios</h1>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {grouped.map(g => (
          <div key={g.name} className="card">
            <div className="font-serif text-base font-medium text-navy-700 mb-1">{g.name}</div>
            <div className="font-serif text-2xl text-gold-400 mb-2">{g.members.length}</div>
            <div className="text-[10px] text-stone-400 mb-3">membro(s) ativo(s)</div>
            {g.members.length > 0 && (
              <div className="space-y-1">
                {g.members.slice(0, 5).map(m => (
                  <div key={m.id} className="flex items-center gap-2 text-xs text-stone-600">
                    <div className="w-5 h-5 rounded-full bg-navy-100 flex items-center justify-center text-[9px] font-bold text-navy-700 flex-shrink-0">
                      {m.full_name.charAt(0)}
                    </div>
                    <span className="truncate">{m.full_name}</span>
                  </div>
                ))}
                {g.members.length > 5 && (
                  <div className="text-[10px] text-stone-400">+{g.members.length - 5} outros</div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>

      {noMinistry.length > 0 && (
        <div className="card">
          <div className="font-serif text-base font-medium text-navy-700 mb-3">Sem ministério definido ({noMinistry.length})</div>
          <div className="flex flex-wrap gap-2">
            {noMinistry.map(m => (
              <span key={m.id} className="badge bg-stone-100 text-stone-600">{m.full_name}</span>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
