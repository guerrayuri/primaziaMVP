'use client'

import { useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import type { ChurchInfo, ServiceSchedule } from '@/lib/types/database'
import { Globe, Plus, Trash2, Save, Pencil } from 'lucide-react'

interface Props {
  churchInfo: ChurchInfo
  serviceSchedule: ServiceSchedule[]
  canEdit: boolean
  userId: string
}

export default function PublicaClient({ churchInfo, serviceSchedule, canEdit, userId }: Props) {
  const supabase = createClient()
  const [info, setInfo] = useState(churchInfo)
  const [schedule, setSchedule] = useState(serviceSchedule)
  const [editingInfo, setEditingInfo] = useState(false)
  const [loading, setLoading] = useState(false)
  const [saved, setSaved] = useState(false)
  const [newService, setNewService] = useState({ name: '', day: '', time: '', location: '' })
  const [addingService, setAddingService] = useState(false)

  async function handleSaveInfo(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    await supabase.from('church_settings').update({ value: info, updated_by: userId }).eq('key', 'church_info')
    setSaved(true)
    setEditingInfo(false)
    setLoading(false)
    setTimeout(() => setSaved(false), 2500)
  }

  async function handleSaveSchedule() {
    setLoading(true)
    await supabase.from('church_settings').update({ value: schedule, updated_by: userId }).eq('key', 'service_schedule')
    setSaved(true)
    setLoading(false)
    setTimeout(() => setSaved(false), 2500)
  }

  async function addService() {
    if (!newService.name || !newService.day || !newService.time) return
    const updated = [...schedule, newService]
    setSchedule(updated)
    setNewService({ name: '', day: '', time: '', location: '' })
    setAddingService(false)
    setLoading(true)
    await supabase.from('church_settings').update({ value: updated, updated_by: userId }).eq('key', 'service_schedule')
    setLoading(false)
  }

  function removeService(index: number) {
    const updated = schedule.filter((_, i) => i !== index)
    setSchedule(updated)
    supabase.from('church_settings').update({ value: updated, updated_by: userId }).eq('key', 'service_schedule')
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-2">
        <Globe size={22} className="text-gold-400" />
        <h1 className="font-serif text-2xl text-navy-700">Área Pública</h1>
        {!canEdit && <span className="badge bg-stone-100 text-stone-500 text-[10px]">somente leitura</span>}
      </div>

      {saved && <div className="alert-ok">✓ Salvo com sucesso!</div>}

      {/* Church info */}
      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <div className="section-title" style={{ margin: 0 }}>🏛️ Informações da Igreja</div>
          {canEdit && !editingInfo && (
            <button className="btn btn-sm" onClick={() => setEditingInfo(true)}><Pencil size={12} /> Editar</button>
          )}
        </div>

        {editingInfo && canEdit ? (
          <form onSubmit={handleSaveInfo} className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div><label className="label">Nome da Igreja *</label><input className="input" required value={info.name} onChange={e => setInfo(p => ({ ...p, name: e.target.value }))} /></div>
              <div><label className="label">Endereço</label><input className="input" value={info.address} onChange={e => setInfo(p => ({ ...p, address: e.target.value }))} /></div>
              <div><label className="label">WhatsApp</label><input className="input" value={info.whatsapp} onChange={e => setInfo(p => ({ ...p, whatsapp: e.target.value }))} placeholder="(11) 9xxxx-xxxx" /></div>
              <div><label className="label">E-mail</label><input className="input" type="email" value={info.email} onChange={e => setInfo(p => ({ ...p, email: e.target.value }))} /></div>
            </div>
            <div><label className="label">Visão</label><textarea className="input" rows={2} value={info.vision} onChange={e => setInfo(p => ({ ...p, vision: e.target.value }))} /></div>
            <div><label className="label">Missão</label><textarea className="input" rows={2} value={info.mission} onChange={e => setInfo(p => ({ ...p, mission: e.target.value }))} /></div>
            <div><label className="label">Valores</label><textarea className="input" rows={2} value={info.values} onChange={e => setInfo(p => ({ ...p, values: e.target.value }))} /></div>
            <div className="flex gap-2">
              <button type="submit" disabled={loading} className="btn btn-gold"><Save size={13} /> {loading ? 'Salvando...' : 'Salvar'}</button>
              <button type="button" className="btn" onClick={() => setEditingInfo(false)}>Cancelar</button>
            </div>
          </form>
        ) : (
          <div className="grid md:grid-cols-2 gap-4 text-sm">
            <InfoRow label="Igreja" value={info.name} />
            <InfoRow label="Endereço" value={info.address} />
            <InfoRow label="WhatsApp" value={info.whatsapp} />
            <InfoRow label="E-mail" value={info.email} />
            {info.vision && <div className="col-span-2"><InfoRow label="Visão" value={info.vision} /></div>}
            {info.mission && <div className="col-span-2"><InfoRow label="Missão" value={info.mission} /></div>}
            {info.values && <div className="col-span-2"><InfoRow label="Valores" value={info.values} /></div>}
          </div>
        )}
      </div>

      {/* Service schedule */}
      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <div className="section-title" style={{ margin: 0 }}>🗓️ Horários dos Cultos</div>
          {canEdit && (
            <button className="btn btn-sm" onClick={() => setAddingService(true)}><Plus size={12} /> Adicionar</button>
          )}
        </div>

        {schedule.length === 0 && !addingService && (
          <p className="text-xs text-stone-400">Nenhum horário de culto cadastrado.</p>
        )}

        <div className="space-y-2">
          {schedule.map((s, i) => (
            <div key={i} className="flex items-center gap-3 p-3 bg-stone-50 rounded-lg">
              <div className="flex-1">
                <div className="font-medium text-sm">{s.name}</div>
                <div className="text-xs text-stone-500">{s.day} · {s.time}{s.location ? ` · ${s.location}` : ''}</div>
              </div>
              {canEdit && (
                <button className="btn btn-icon btn-sm btn-danger" onClick={() => removeService(i)}><Trash2 size={11} /></button>
              )}
            </div>
          ))}
        </div>

        {addingService && canEdit && (
          <div className="mt-4 p-4 border border-stone-200 rounded-xl bg-stone-50 space-y-3">
            <div className="text-xs font-semibold text-stone-600">Novo horário de culto</div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="label">Nome do culto *</label><input className="input" value={newService.name} onChange={e => setNewService(p => ({ ...p, name: e.target.value }))} placeholder="Ex: Culto Dominical" /></div>
              <div><label className="label">Dia *</label><input className="input" value={newService.day} onChange={e => setNewService(p => ({ ...p, day: e.target.value }))} placeholder="Ex: Domingo" /></div>
              <div><label className="label">Horário *</label><input className="input" value={newService.time} onChange={e => setNewService(p => ({ ...p, time: e.target.value }))} placeholder="Ex: 09h00" /></div>
              <div><label className="label">Local</label><input className="input" value={newService.location} onChange={e => setNewService(p => ({ ...p, location: e.target.value }))} placeholder="Ex: Templo principal" /></div>
            </div>
            <div className="flex gap-2">
              <button className="btn btn-gold btn-sm" onClick={addService} disabled={loading}><Save size={12} /> Salvar</button>
              <button className="btn btn-sm" onClick={() => setAddingService(false)}>Cancelar</button>
            </div>
          </div>
        )}
      </div>

      {/* Preview */}
      <div className="card border-2 border-dashed border-stone-200">
        <div className="section-title">👁️ Preview — Como aparece na área pública</div>
        <div className="bg-gradient-to-br from-navy-700 to-navy-600 rounded-xl p-5 text-white">
          <div className="font-serif text-xl font-semibold mb-2">{info.name || 'Nome da Igreja'}</div>
          {info.vision && <p className="text-sm text-white/70 italic mb-3">"{info.vision}"</p>}
          <div className="flex flex-wrap gap-4 text-sm">
            {info.address && <span>📍 {info.address}</span>}
            {info.whatsapp && <span>💬 {info.whatsapp}</span>}
            {info.email && <span>✉️ {info.email}</span>}
          </div>
        </div>
        {schedule.length > 0 && (
          <div className="mt-4">
            <div className="text-xs font-semibold text-stone-500 uppercase tracking-wide mb-2">Horários dos cultos</div>
            <div className="grid gap-2 sm:grid-cols-2 md:grid-cols-3">
              {schedule.map((s, i) => (
                <div key={i} className="bg-stone-50 rounded-lg p-3 text-xs">
                  <div className="font-semibold text-navy-700">{s.name}</div>
                  <div className="text-stone-500">{s.day} · {s.time}</div>
                  {s.location && <div className="text-stone-400">{s.location}</div>}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="label" style={{ marginBottom: '2px' }}>{label}</div>
      <div className="text-stone-700">{value || <span className="text-stone-300 italic">Não informado</span>}</div>
    </div>
  )
}
