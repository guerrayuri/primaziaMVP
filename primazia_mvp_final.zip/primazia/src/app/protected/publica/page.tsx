import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import PublicaClient from './PublicaClient'
import type { ChurchInfo, ServiceSchedule } from '@/lib/types/database'

export default async function PublicaProtectedPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  const { data: profile } = await supabase.from('profiles').select('role').eq('id', user.id).single()
  if (!profile) redirect('/auth/login')

  const { data: settings } = await supabase
    .from('church_settings')
    .select('key, value')
    .in('key', ['church_info', 'service_schedule'])

  const churchInfo: ChurchInfo = settings?.find(s => s.key === 'church_info')?.value ?? {
    name: '', address: '', whatsapp: '', email: '', vision: '', mission: '', values: '', logo_url: ''
  }
  const serviceSchedule: ServiceSchedule[] = settings?.find(s => s.key === 'service_schedule')?.value ?? []

  const canEdit = ['super_admin', 'admin'].includes(profile.role)

  return <PublicaClient churchInfo={churchInfo} serviceSchedule={serviceSchedule} canEdit={canEdit} userId={user.id} />
}
