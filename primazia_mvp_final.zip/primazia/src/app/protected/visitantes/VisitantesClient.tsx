'use client'

import { useState, useMemo } from 'react'
import { createClient } from '@/lib/supabase/client'
import type { Visitor, UserRole } from '@/lib/types/database'
import { exportToCSV, formatVisitorReport } from '@/lib/utils/export'
import { logAudit } from '@/lib/utils/audit'
import Modal from '@/components/ui/Modal'
import { Bar, Doughnut } from 'react-chartjs-2'
import {
  Chart as ChartJS, CategoryScale, LinearScale, BarElement,
  Title, Tooltip, Legend, ArcElement
} from 'chart.js'

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement)

interface Props { visitors: Visitor[]; userRole: UserRole }

const CULTO_OPTIONS = ['Dominical', 'Culto da Família', 'Estudo Bíblico', 'Culto de Oração', 'Outro']
const HOW_FOUND_OPTIONS = ['Indicação de amigo', 'Redes sociais', 'Busca online', 'Passou na frente', 'Família', 'Outro']

export default function VisitantesClient({ visitors, userRole }: Props) {
  const [search, setSearch] = useState('')
  const [filterCulto, setFilterCulto] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [loading, setLoading] = useState(false)
  const [localVisitors, setLocalVisitors] = useState(visitors)
  const [form, setForm] = useState({
    full_name: '', visit_date: new Date().toISOString().slice(0, 10),
    service_type: 'Dominical', gender: '', age: '',
    neighborhood: '', city: '', phone: '', how_found: '',
    wants_contact: false, consent_contact: false,
    pastoral_notes: '',
  })

  const supabase = createClient()

  const filtered = useMemo(() => localVisitors.filter(v => {
    const q = search.toLowerCase()
    const matchQ = !q || v.full_name.toLowerCase().includes(q) || (v.neighborhood ?? '').toLowerCase().includes(q)
    const matchC = !filterCulto || v.service_type === filterCulto
    return matchQ && matchC && v.status === 'active'
  }), [localVisitors, search, filterCulto])

  // Chart data
  const cultoCounts = useMemo(() => {
    const counts: Record<string, number> = {}
    localVisitors.forEach(v => { counts[v.service_type] = (counts[v.service_type] || 0) + 1 })
    return counts
  }, [localVisitors])

  const howFoundCounts = useMemo(() => {
    const counts: Record<string, number> = {}
    localVisitors.forEach(v => { if (v.how_found) counts[v.how_found] = (counts[v.how_found] || 0) + 1 })
    return counts
  }, [localVisitors])

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) { setLoading(false); return }

    const { data, error } = await supabase.from('visitors').insert({
      full_name: form.full_name,
      visit_date: form.visit_date,
      service_type: form.service_type,
      gender: form.gender || null,
      age: form.age ? parseInt(form.age) : null,
      neighborhood: form.neighborhood || null,
      city: form.city || null,
      phone: form.phone || null,
      how_found: form.how_found || null,
      wants_contact: form.wants_contact,
      consent_contact: form.consent_contact,
      pastoral_notes: form.pastoral_notes || null,
      registered_by: user.id,
    }).select().single()

    if (!error && data) {
      setLocalVisitors(prev => [data, ...prev])
      await logAudit({ action: 'create_visitor', module: 'visitors', recordId: data.id, recordType: 'visitor', newData: { name: data.full_name } })
      setShowModal(false)
    }
    setLoading(false)
  }

  async function handleArchive(id: string) {
    if (!confirm('Arquivar este visitante?')) return
    await supabase.from('visitors').update({ status: 'archived' }).eq('id', id)
    setLocalVisitors(prev => prev.filter(v => v.id !== id))
  }

  const CHART_COLORS = ['#C9A84C', '#1B2B4B', '#2D6A4F', '#8B1A1A', '#7A4A00', '#6B7A99']

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-wrap gap-2 items-center justify-between">
        <h1 className="font-serif text-2xl text-navy-700">Visitantes</h1>
        <div className="flex gap-2 flex-wrap">
          <button className="btn" onClick={() => exportToCSV(formatVisitorReport(filtered), `visitantes_${new Date().toISOString().slice(0,10)}`)}>
            📥 Exportar CSV
          </button>
          <button className="btn btn-gold" onClick={() => setShowModal(true)}>
            + Registrar visitante
          </button>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Total', value: localVisitors.filter(v => v.status === 'active').length },
          { label: 'Querem contato', value: localVisitors.filter(v => v.wants_contact && v.status === 'active').length },
          { label: 'Recorrentes', value: localVisitors.filter(v => v.is_recurring && v.status === 'active').length },
          { label: 'Média de idade', value: Math.round(localVisitors.filter(v => v.age).reduce((s, v) => s + (v.age ?? 0), 0) / (localVisitors.filter(v => v.age).length || 1)) || 0 },
        ].map(m => (
          <div key={m.label} className="metric-card">
            <div className="text-[10px] font-semibold uppercase tracking-wide text-stone-500 mb-1">{m.label}</div>
            <div className="font-serif text-2xl text-navy-700">{m.value}</div>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div className="grid md:grid-cols-2 gap-4">
        <div className="card">
          <div className="section-title">Por culto</div>
          <div className="h-44">
            <Bar
              data={{
                labels: Object.keys(cultoCounts),
                datasets: [{ data: Object.values(cultoCounts), backgroundColor: '#C9A84C', borderRadius: 4 }]
              }}
              options={{ responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }}
            />
          </div>
        </div>
        <div className="card">
          <div className="section-title">Como conheceram a igreja</div>
          <div className="h-44">
            <Doughnut
              data={{
                labels: Object.keys(howFoundCounts),
                datasets: [{ data: Object.values(howFoundCounts), backgroundColor: CHART_COLORS }]
              }}
              options={{ responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { font: { size: 10 }, boxWidth: 10 } } } }}
            />
          </div>
        </div>
      </div>

      {/* Filters + Table */}
      <div className="card">
        <div className="flex flex-wrap gap-2 mb-4">
          <input className="input flex-1 min-w-[160px]" placeholder="Buscar visitante..." value={search} onChange={e => setSearch(e.target.value)} />
          <select className="input w-44" value={filterCulto} onChange={e => setFilterCulto(e.target.value)}>
            <option value="">Todos os cultos</option>
            {CULTO_OPTIONS.map(c => <option key={c}>{c}</option>)}
          </select>
        </div>

        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Nome</th><th>Data</th><th>Culto</th><th>Gênero</th>
                <th>Idade</th><th>Bairro</th><th>Como conheceu</th><th>Contato</th><th></th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr><td colSpan={9} className="text-center py-8 text-stone-400">Nenhum visitante encontrado.</td></tr>
              )}
              {filtered.map(v => (
                <tr key={v.id}>
                  <td className="font-medium">{v.full_name}</td>
                  <td>{new Date(v.visit_date + 'T12:00').toLocaleDateString('pt-BR')}</td>
                  <td>{v.service_type}</td>
                  <td>{v.gender === 'M' ? 'M' : v.gender === 'F' ? 'F' : '—'}</td>
                  <td>{v.age ?? '—'}</td>
                  <td>{v.neighborhood ?? '—'}</td>
                  <td>{v.how_found ?? '—'}</td>
                  <td>
                    <span className={`badge ${v.wants_contact ? 'bg-green-100 text-green-700' : 'bg-stone-100 text-stone-500'}`}>
                      {v.wants_contact ? 'Sim' : 'Não'}
                    </span>
                  </td>
                  <td>
                    <button className="btn btn-icon btn-danger btn-sm" onClick={() => handleArchive(v.id)}>🗄️</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <Modal title="Registrar visitante" onClose={() => setShowModal(false)}>
          <form onSubmit={handleSubmit} className="space-y-3">
            <div><label className="label">Nome *</label><input className="input" required value={form.full_name} onChange={e => setForm(p => ({ ...p, full_name: e.target.value }))} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="label">Data do culto *</label><input className="input" type="date" required value={form.visit_date} onChange={e => setForm(p => ({ ...p, visit_date: e.target.value }))} /></div>
              <div><label className="label">Culto</label>
                <select className="input" value={form.service_type} onChange={e => setForm(p => ({ ...p, service_type: e.target.value }))}>
                  {CULTO_OPTIONS.map(c => <option key={c}>{c}</option>)}
                </select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="label">Gênero</label>
                <select className="input" value={form.gender} onChange={e => setForm(p => ({ ...p, gender: e.target.value }))}>
                  <option value="">Não informar</option><option value="M">Masculino</option><option value="F">Feminino</option>
                </select>
              </div>
              <div><label className="label">Idade</label><input className="input" type="number" min="0" max="120" value={form.age} onChange={e => setForm(p => ({ ...p, age: e.target.value }))} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="label">Bairro</label><input className="input" value={form.neighborhood} onChange={e => setForm(p => ({ ...p, neighborhood: e.target.value }))} /></div>
              <div><label className="label">Cidade</label><input className="input" value={form.city} onChange={e => setForm(p => ({ ...p, city: e.target.value }))} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="label">Telefone / WhatsApp</label><input className="input" value={form.phone} onChange={e => setForm(p => ({ ...p, phone: e.target.value }))} /></div>
              <div><label className="label">Como conheceu</label>
                <select className="input" value={form.how_found} onChange={e => setForm(p => ({ ...p, how_found: e.target.value }))}>
                  <option value="">Selecione</option>
                  {HOW_FOUND_OPTIONS.map(o => <option key={o}>{o}</option>)}
                </select>
              </div>
            </div>
            <div><label className="label">Notas pastorais (privado)</label>
              <textarea className="input" rows={2} value={form.pastoral_notes} onChange={e => setForm(p => ({ ...p, pastoral_notes: e.target.value }))} />
            </div>
            <div className="flex gap-4">
              <label className="flex items-center gap-2 text-xs cursor-pointer">
                <input type="checkbox" checked={form.wants_contact} onChange={e => setForm(p => ({ ...p, wants_contact: e.target.checked }))} />
                Deseja contato pastoral
              </label>
              <label className="flex items-center gap-2 text-xs cursor-pointer">
                <input type="checkbox" checked={form.consent_contact} onChange={e => setForm(p => ({ ...p, consent_contact: e.target.checked }))} />
                Consentiu contato
              </label>
            </div>
            <div className="flex gap-2 justify-end pt-2 border-t border-stone-100">
              <button type="button" className="btn" onClick={() => setShowModal(false)}>Cancelar</button>
              <button type="submit" disabled={loading} className="btn btn-gold">{loading ? 'Salvando...' : '✓ Registrar'}</button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  )
}
