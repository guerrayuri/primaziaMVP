import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import { hasRole } from '@/lib/utils/permissions'
import VisitantesClient from './VisitantesClient'

export default async function VisitantesPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  const { data: profile } = await supabase.from('profiles').select('role').eq('id', user.id).single()
  if (!profile || !hasRole(profile.role, 'pastor')) redirect('/dashboard?error=unauthorized')

  const { data: visitors } = await supabase
    .from('visitors')
    .select('*, profiles(full_name)')
    .is('deleted_at', null)
    .order('visit_date', { ascending: false })

  return <VisitantesClient visitors={visitors ?? []} userRole={profile.role} />
}
