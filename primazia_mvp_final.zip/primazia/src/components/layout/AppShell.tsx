'use client'

import { useState } from 'react'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import type { Profile } from '@/lib/types/database'
import { hasRole } from '@/lib/utils/permissions'
import {
  LayoutDashboard, User, Globe, Users, UserPlus, CalendarDays,
  Play, Heart, Building2, CalendarClock, FileText, Coins,
  ShieldCheck, Menu, X, LogOut, Bell, ChevronRight
} from 'lucide-react'

interface NavItem {
  id: string
  label: string
  href: string
  icon: React.ReactNode
  section: string
  minRole: import('@/lib/types/database').UserRole
}

const NAV_ITEMS: NavItem[] = [
  { id: 'dashboard',   label: 'Dashboard',         href: '/dashboard',   icon: <LayoutDashboard size={15}/>, section: 'Geral',          minRole: 'member' },
  { id: 'minha-area',  label: 'Minha Área',         href: '/minha-area',  icon: <User size={15}/>,            section: 'Geral',          minRole: 'member' },
  { id: 'publica',     label: 'Área Pública',       href: '/publica',     icon: <Globe size={15}/>,           section: 'Institucional',  minRole: 'member' },
  { id: 'membros',     label: 'Membros',             href: '/membros',     icon: <Users size={15}/>,           section: 'Pessoas',        minRole: 'pastor' },
  { id: 'visitantes',  label: 'Visitantes',          href: '/visitantes',  icon: <UserPlus size={15}/>,        section: 'Pessoas',        minRole: 'pastor' },
  { id: 'eventos',     label: 'Eventos',             href: '/eventos',     icon: <CalendarDays size={15}/>,    section: 'Atividades',     minRole: 'member' },
  { id: 'cursos',      label: 'Cursos & Aulas',      href: '/cursos',      icon: <Play size={15}/>,            section: 'Atividades',     minRole: 'member' },
  { id: 'infantil',    label: 'Ministério Infantil', href: '/infantil',    icon: <Heart size={15}/>,           section: 'Ministérios',    minRole: 'teacher' },
  { id: 'ministerios', label: 'Ministérios',         href: '/ministerios', icon: <Building2 size={15}/>,       section: 'Ministérios',    minRole: 'pastor' },
  { id: 'gabinete',    label: 'Agenda Pastoral',     href: '/gabinete',    icon: <CalendarClock size={15}/>,   section: 'Pastoral',       minRole: 'member' },
  { id: 'atas',        label: 'Atas Pastorais',      href: '/atas',        icon: <FileText size={15}/>,        section: 'Pastoral',       minRole: 'pastor' },
  { id: 'financeiro',  label: 'Financeiro',          href: '/financeiro',  icon: <Coins size={15}/>,           section: 'Administração',  minRole: 'financial_admin' },
  { id: 'admin',       label: 'Administração',       href: '/admin',       icon: <ShieldCheck size={15}/>,     section: 'Administração',  minRole: 'admin' },
]

interface Props {
  profile: Profile
  children: React.ReactNode
  pendingRequests?: number
}

export default function AppShell({ profile, children, pendingRequests = 0 }: Props) {
  const pathname = usePathname()
  const router = useRouter()
  const supabase = createClient()
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const visibleItems = NAV_ITEMS.filter(item => hasRole(profile.role, item.minRole))
  const sections = Array.from(new Set(visibleItems.map(i => i.section)))

  async function handleLogout() {
    await supabase.auth.signOut()
    router.push('/auth/login')
    router.refresh()
  }

  const initials = profile.full_name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="px-4 py-4 border-b border-white/10 flex items-center gap-3">
        <div className="w-9 h-9 bg-gradient-to-br from-gold-400 to-gold-500 rounded-lg flex items-center justify-center font-serif font-bold text-navy-700 text-lg flex-shrink-0">P</div>
        <div>
          <div className="font-serif text-base font-semibold text-white">PrimazIA</div>
          <div className="text-[9px] text-white/35 uppercase tracking-widest">Gestão Ministerial</div>
        </div>
      </div>

      {/* User pill */}
      <div className="mx-2 my-2 bg-white/8 border border-white/10 rounded-lg px-3 py-2 flex items-center gap-2">
        <div className="w-7 h-7 rounded-full bg-gradient-to-br from-gold-400 to-gold-500 flex items-center justify-center font-serif text-[10px] font-bold text-navy-700 flex-shrink-0">
          {initials}
        </div>
        <div className="min-w-0">
          <div className="text-xs font-medium text-white truncate">{profile.full_name}</div>
          <div className="text-[10px] text-white/40 truncate">{profile.email}</div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto px-2 py-2 scrollbar-thin">
        {sections.map(section => (
          <div key={section} className="mb-1">
            <div className="text-[9px] font-semibold uppercase tracking-widest text-white/28 px-2 py-1">{section}</div>
            {visibleItems.filter(i => i.section === section).map(item => {
              const active = pathname.startsWith(item.href)
              return (
                <Link
                  key={item.id}
                  href={item.href}
                  onClick={() => setSidebarOpen(false)}
                  className={`nav-item ${active ? 'active' : ''}`}
                >
                  {item.icon}
                  <span>{item.label}</span>
                  {item.id === 'admin' && pendingRequests > 0 && (
                    <span className="ml-auto bg-red-500 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full">{pendingRequests}</span>
                  )}
                </Link>
              )
            })}
          </div>
        ))}
      </nav>

      {/* Logout */}
      <div className="p-2 border-t border-white/10">
        <button
          onClick={handleLogout}
          className="flex items-center gap-2 w-full px-3 py-2 rounded-md text-xs text-white/35 hover:text-red-300 hover:bg-red-900/20 transition-all"
        >
          <LogOut size={14} /> Sair
        </button>
      </div>
    </div>
  )

  return (
    <div className="flex h-screen overflow-hidden bg-stone-50">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-40 bg-black/50 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Sidebar — desktop */}
      <aside className="hidden lg:flex flex-col w-56 bg-navy-700 flex-shrink-0">
        <SidebarContent />
      </aside>

      {/* Sidebar — mobile drawer */}
      <aside className={`fixed inset-y-0 left-0 z-50 w-64 bg-navy-700 flex flex-col transform transition-transform duration-200 lg:hidden ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <SidebarContent />
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Topbar */}
        <header className="h-12 bg-white border-b border-stone-200 flex items-center justify-between px-4 flex-shrink-0">
          <div className="flex items-center gap-3">
            <button className="lg:hidden p-1 rounded hover:bg-stone-100" onClick={() => setSidebarOpen(!sidebarOpen)}>
              {sidebarOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
            <h1 className="font-serif text-base font-medium text-navy-700">
              {NAV_ITEMS.find(i => pathname.startsWith(i.href))?.label ?? 'PrimazIA'}
            </h1>
          </div>
          <div className="flex items-center gap-2">
            {pendingRequests > 0 && hasRole(profile.role, 'admin') && (
              <Link href="/admin" className="relative p-1.5 rounded hover:bg-stone-100">
                <Bell size={16} className="text-stone-500" />
                <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-red-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center">{pendingRequests}</span>
              </Link>
            )}
            <div className="w-7 h-7 rounded-full bg-gradient-to-br from-gold-400 to-gold-500 flex items-center justify-center font-serif text-[10px] font-bold text-navy-700">
              {initials}
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-y-auto p-4 md:p-5">
          {children}
        </main>
      </div>
    </div>
  )
}
