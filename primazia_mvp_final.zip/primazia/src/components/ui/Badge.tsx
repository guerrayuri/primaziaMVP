interface Props {
  children: React.ReactNode
  variant?: 'green' | 'red' | 'amber' | 'blue' | 'navy' | 'gray' | 'gold' | 'purple'
}

const VARIANTS = {
  green:  'bg-green-100 text-green-700',
  red:    'bg-red-100 text-red-700',
  amber:  'bg-amber-100 text-amber-700',
  blue:   'bg-blue-100 text-blue-700',
  navy:   'bg-navy-100 text-navy-700',
  gray:   'bg-stone-100 text-stone-600',
  gold:   'bg-gold-100 text-gold-600',
  purple: 'bg-purple-100 text-purple-700',
}

export default function Badge({ children, variant = 'gray' }: Props) {
  return (
    <span className={`badge ${VARIANTS[variant]}`}>{children}</span>
  )
}
