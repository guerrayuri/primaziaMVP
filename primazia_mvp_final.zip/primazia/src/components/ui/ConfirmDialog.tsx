'use client'

import { AlertTriangle } from 'lucide-react'

interface Props {
  title: string
  message: string
  confirmLabel?: string
  cancelLabel?: string
  variant?: 'danger' | 'warning' | 'info'
  onConfirm: () => void
  onCancel: () => void
}

const COLORS = {
  danger:  { icon: 'text-red-500',    btn: 'btn-danger',   bg: 'bg-red-50' },
  warning: { icon: 'text-amber-500',  btn: 'bg-amber-500 text-white border-amber-500', bg: 'bg-amber-50' },
  info:    { icon: 'text-blue-500',   btn: 'btn-primary',  bg: 'bg-blue-50' },
}

export default function ConfirmDialog({
  title, message, confirmLabel = 'Confirmar', cancelLabel = 'Cancelar',
  variant = 'danger', onConfirm, onCancel,
}: Props) {
  const c = COLORS[variant]
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(27,43,75,0.5)', backdropFilter: 'blur(3px)' }}
    >
      <div className="modal-animate bg-white rounded-2xl p-6 max-w-sm w-full shadow-2xl">
        <div className={`w-12 h-12 rounded-full ${c.bg} flex items-center justify-center mx-auto mb-4`}>
          <AlertTriangle size={24} className={c.icon} />
        </div>
        <h2 className="font-serif text-lg text-navy-700 text-center mb-2">{title}</h2>
        <p className="text-sm text-stone-500 text-center mb-6">{message}</p>
        <div className="flex gap-3">
          <button className="btn flex-1 justify-center" onClick={onCancel}>{cancelLabel}</button>
          <button className={`btn flex-1 justify-center ${c.btn}`} onClick={onConfirm}>{confirmLabel}</button>
        </div>
      </div>
    </div>
  )
}
