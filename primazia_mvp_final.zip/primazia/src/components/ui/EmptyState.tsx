import { LucideIcon } from 'lucide-react'

interface Props {
  icon?: LucideIcon
  title: string
  description?: string
  action?: {
    label: string
    onClick: () => void
  }
}

export default function EmptyState({ icon: Icon, title, description, action }: Props) {
  return (
    <div className="empty-state py-16">
      {Icon && <Icon size={40} className="mx-auto mb-3 text-stone-300" />}
      <p className="text-sm font-medium text-stone-500 mb-1">{title}</p>
      {description && <p className="text-xs text-stone-400 mb-4">{description}</p>}
      {action && (
        <button className="btn btn-gold mt-2" onClick={action.onClick}>
          {action.label}
        </button>
      )}
    </div>
  )
}
