export default function LoadingSpinner({ size = 24 }: { size?: number }) {
  return (
    <div className="flex items-center justify-center py-12">
      <div className="spinner" style={{ width: size, height: size }} />
    </div>
  )
}
