import { LucideIcon } from 'lucide-react'

interface Action {
  label: string
  onClick: () => void
  variant?: 'gold' | 'primary' | 'default'
  icon?: React.ReactNode
}

interface Props {
  title: string
  icon?: LucideIcon
  actions?: Action[]
  subtitle?: string
}

const VARIANT_CLASS = {
  gold:    'btn btn-gold',
  primary: 'btn btn-primary',
  default: 'btn',
}

export default function PageHeader({ title, icon: Icon, actions, subtitle }: Props) {
  return (
    <div className="flex flex-wrap gap-3 items-start justify-between mb-5">
      <div className="flex items-center gap-2">
        {Icon && <Icon size={22} className="text-gold-400 flex-shrink-0" />}
        <div>
          <h1 className="font-serif text-2xl text-navy-700">{title}</h1>
          {subtitle && <p className="text-xs text-stone-500 mt-0.5">{subtitle}</p>}
        </div>
      </div>
      {actions && actions.length > 0 && (
        <div className="flex gap-2 flex-wrap">
          {actions.map((a, i) => (
            <button key={i} className={VARIANT_CLASS[a.variant ?? 'default']} onClick={a.onClick}>
              {a.icon}
              {a.label}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
