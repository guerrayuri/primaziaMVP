export default function PageSkeleton({ rows = 5 }: { rows?: number }) {
  return (
    <div className="space-y-5 animate-pulse">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="h-8 bg-stone-200 rounded-lg w-48" />
        <div className="h-8 bg-stone-200 rounded-lg w-28" />
      </div>
      {/* Metric cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="h-20 bg-stone-200 rounded-xl" />
        ))}
      </div>
      {/* Table / content */}
      <div className="bg-white rounded-xl border border-stone-200 p-4 space-y-3">
        <div className="h-6 bg-stone-200 rounded w-32" />
        {[...Array(rows)].map((_, i) => (
          <div key={i} className="h-10 bg-stone-100 rounded" />
        ))}
      </div>
    </div>
  )
}
