interface Stat {
  label: string
  value: string | number
  sub?: string
  valueColor?: string
}

interface Props {
  stats: Stat[]
  cols?: 2 | 3 | 4
}

const COLS = { 2: 'grid-cols-2', 3: 'grid-cols-3', 4: 'grid-cols-2 md:grid-cols-4' }

export default function StatsGrid({ stats, cols = 4 }: Props) {
  return (
    <div className={`grid ${COLS[cols]} gap-3`}>
      {stats.map((s, i) => (
        <div key={i} className="metric-card">
          <div className="mcl">{s.label}</div>
          <div className={`mcv ${s.valueColor ?? ''}`}>{s.value}</div>
          {s.sub && <div className="mcs">{s.sub}</div>}
        </div>
      ))}
    </div>
  )
}
