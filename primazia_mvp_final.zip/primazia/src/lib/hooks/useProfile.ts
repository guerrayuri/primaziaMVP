'use client'

import { useEffect, useState, useCallback } from 'react'
import { createClient } from '@/lib/supabase/client'
import type { Profile } from '@/lib/types/database'

interface State {
  profile: Profile | null
  loading: boolean
  error: string | null
  refetch: () => void
}

export function useProfile(): State {
  const [profile, setProfile] = useState<Profile | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const supabase = createClient()

  const fetchProfile = useCallback(async () => {
    setLoading(true)
    setError(null)
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) { setLoading(false); return }

    const { data, error: err } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', user.id)
      .single()

    if (err) setError(err.message)
    else setProfile(data)
    setLoading(false)
  }, [supabase])

  useEffect(() => {
    fetchProfile()

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
      if (event === 'SIGNED_OUT') setProfile(null)
      else if (event === 'SIGNED_IN') fetchProfile()
    })

    return () => subscription.unsubscribe()
  }, [fetchProfile, supabase.auth])

  return { profile, loading, error, refetch: fetchProfile }
}
