export type UserRole =
  | 'super_admin'
  | 'admin'
  | 'financial_admin'
  | 'pastor'
  | 'coordinator'
  | 'teacher'
  | 'guardian'
  | 'member'
  | 'student'
  | 'visitor'

export type RequestStatus = 'pending' | 'approved' | 'rejected' | 'cancelled'
export type EventStatus = 'draft' | 'published' | 'full' | 'cancelled' | 'finished'
export type RegistrationStatus = 'registered' | 'confirmed' | 'paid' | 'present' | 'absent' | 'cancelled'
export type CourseStatus = 'draft' | 'published' | 'archived'
export type EnrollmentStatus = 'pending' | 'active' | 'in_progress' | 'completed' | 'blocked' | 'cancelled'
export type TransactionType = 'income' | 'expense'
export type TransactionStatus = 'active' | 'cancelled' | 'archived'
export type AppointmentStatus = 'requested' | 'confirmed' | 'done' | 'rescheduled' | 'cancelled'
export type FeedbackVisibility = 'private' | 'guardians' | 'all_staff'

export interface Profile {
  id: string
  full_name: string
  email: string
  phone: string | null
  avatar_url: string | null
  role: UserRole
  is_active: boolean
  approved_by: string | null
  approved_at: string | null
  created_at: string
  updated_at: string
  last_login_at: string | null
}

export interface RoleRequest {
  id: string
  user_id: string
  current_role: UserRole
  requested_role: UserRole
  justification: string
  status: RequestStatus
  reviewed_by: string | null
  review_note: string | null
  reviewed_at: string | null
  created_at: string
  updated_at: string
  profiles?: Profile
}

export interface Notice {
  id: string
  title: string
  body: string
  type: 'general' | 'urgent' | 'pastoral' | 'event'
  is_active: boolean
  is_public: boolean
  created_by: string
  updated_by: string | null
  created_at: string
  updated_at: string
  expires_at: string | null
  profiles?: Pick<Profile, 'full_name'>
}

export interface Member {
  id: string
  profile_id: string | null
  full_name: string
  email: string | null
  phone: string | null
  birth_date: string | null
  gender: 'M' | 'F' | 'other' | 'not_informed' | null
  ministry: string | null
  status: 'active' | 'inactive' | 'transferred' | 'deceased'
  notes: string | null
  created_by: string | null
  updated_by: string | null
  created_at: string
  updated_at: string
  deleted_at: string | null
}

export interface Visitor {
  id: string
  full_name: string
  visit_date: string
  service_type: string
  gender: 'M' | 'F' | 'other' | 'not_informed' | null
  age: number | null
  age_range: string | null
  neighborhood: string | null
  city: string | null
  phone: string | null
  how_found: string | null
  wants_contact: boolean
  is_recurring: boolean
  first_visit_id: string | null
  pastoral_notes: string | null
  consent_contact: boolean
  status: 'active' | 'archived'
  registered_by: string
  updated_by: string | null
  created_at: string
  updated_at: string
  deleted_at: string | null
  profiles?: Pick<Profile, 'full_name'>
}

export interface Event {
  id: string
  title: string
  description: string | null
  event_date: string
  start_time: string | null
  end_time: string | null
  location: string | null
  max_spots: number
  inscritos: number   // virtual count — may come from joined query
  price: number
  is_free: boolean
  status: EventStatus
  is_public: boolean
  image_url: string | null
  created_by: string
  updated_by: string | null
  created_at: string
  updated_at: string
  deleted_at: string | null
}

export interface EventRegistration {
  id: string
  event_id: string
  user_id: string
  status: RegistrationStatus
  payment_ref: string | null
  checked_in: boolean
  checked_in_at: string | null
  notes: string | null
  created_at: string
  updated_at: string
  profiles?: Pick<Profile, 'full_name' | 'email' | 'phone'>
  events?: Pick<Event, 'title' | 'event_date'>
}

export interface Course {
  id: string
  title: string
  description: string | null
  instructor: string | null
  workload: string | null
  status: CourseStatus
  is_public: boolean
  thumbnail_url: string | null
  created_by: string
  updated_by: string | null
  created_at: string
  updated_at: string
  deleted_at: string | null
}

export interface CourseModule {
  id: string
  course_id: string
  title: string
  description: string | null
  order_num: number
  created_at: string
  course_lessons?: CourseLesson[]
}

export interface CourseLesson {
  id: string
  module_id: string
  course_id: string
  title: string
  description: string | null
  video_url: string | null
  duration: string | null
  order_num: number
  is_free: boolean
  created_at: string
  updated_at: string
}

export interface CourseEnrollment {
  id: string
  course_id: string
  user_id: string
  status: EnrollmentStatus
  payment_ref: string | null
  enrolled_by: string | null
  progress_pct: number
  completed_at: string | null
  created_at: string
  updated_at: string
  profiles?: Pick<Profile, 'full_name' | 'email'>
  courses?: Pick<Course, 'title'>
}

export interface ChildrenClass {
  id: string
  name: string
  age_range: string | null
  teacher_id: string | null
  is_active: boolean
  created_by: string | null
  created_at: string
  updated_at: string
  profiles?: Pick<Profile, 'full_name'>
}

export interface Child {
  id: string
  full_name: string
  birth_date: string | null
  class_id: string | null
  gender: 'M' | 'F' | 'other' | null
  allergies: string | null
  special_needs: string | null
  consent_given: boolean
  consent_date: string | null
  consent_by: string | null
  status: string
  created_by: string
  updated_by: string | null
  created_at: string
  updated_at: string
  deleted_at: string | null
  children_classes?: Pick<ChildrenClass, 'name'>
  children_guardians?: Array<{ profiles: Pick<Profile, 'full_name' | 'email' | 'phone'>; relationship: string; is_primary: boolean }>
}

export interface ChildFeedback {
  id: string
  child_id: string
  report_id: string | null
  behavior: 'excellent' | 'good' | 'regular' | 'needs_attention' | null
  text: string
  private_notes: string | null
  visibility: FeedbackVisibility
  teacher_id: string
  created_at: string
  updated_at: string
  children?: Pick<Child, 'full_name'>
  profiles?: Pick<Profile, 'full_name'>
}

export interface PastoralAvailability {
  id: string
  pastor_id: string
  date: string
  time_slots: string[]
  notes: string | null
  created_at: string
  updated_at: string
  profiles?: Pick<Profile, 'full_name'>
}

export interface PastoralAppointment {
  id: string
  pastor_id: string
  requester_id: string
  date: string
  time_slot: string
  reason: string
  private_notes: string | null
  public_notes: string | null
  status: AppointmentStatus
  reviewed_by: string | null
  reviewed_at: string | null
  created_at: string
  updated_at: string
  pastor?: Pick<Profile, 'full_name'>
  requester?: Pick<Profile, 'full_name' | 'email' | 'phone'>
}

export interface MeetingMinutes {
  id: string
  title: string
  meeting_date: string
  participants: string | null
  agenda: string | null
  content: string | null
  decisions: string | null
  is_confidential: boolean
  file_url: string | null
  created_by: string
  updated_by: string | null
  created_at: string
  updated_at: string
  deleted_at: string | null
  author?: Pick<Profile, 'full_name'>
  meeting_tasks?: MeetingTask[]
}

export interface MeetingTask {
  id: string
  meeting_id: string
  description: string
  assigned_to: string | null
  due_date: string | null
  status: 'pending' | 'in_progress' | 'done' | 'cancelled'
  created_at: string
  updated_at: string
  assignee?: Pick<Profile, 'full_name'>
}

export interface FinancialCategory {
  id: string
  name: string
  type: TransactionType
  description: string | null
  is_active: boolean
  created_by: string | null
  created_at: string
}

export interface FinancialTransaction {
  id: string
  type: TransactionType
  category_id: string | null
  description: string
  amount: number
  transaction_date: string
  payment_method: string | null
  reference_num: string | null
  file_url: string | null
  notes: string | null
  status: TransactionStatus
  created_by: string
  updated_by: string | null
  cancelled_by: string | null
  cancelled_at: string | null
  cancel_reason: string | null
  created_at: string
  updated_at: string
  category?: Pick<FinancialCategory, 'name' | 'type'>
  creator?: Pick<Profile, 'full_name'>
}

export interface AuditLog {
  id: string
  user_id: string | null
  action: string
  module: string
  record_id: string | null
  record_type: string | null
  old_data: Record<string, unknown> | null
  new_data: Record<string, unknown> | null
  ip_address: string | null
  user_agent: string | null
  created_at: string
  profiles?: Pick<Profile, 'full_name' | 'email'>
}

// Church settings value types
export interface ChurchInfo {
  name: string
  address: string
  whatsapp: string
  email: string
  vision: string
  mission: string
  values: string
  logo_url: string
}

export interface ServiceSchedule {
  name: string
  day: string
  time: string
  location: string
}
