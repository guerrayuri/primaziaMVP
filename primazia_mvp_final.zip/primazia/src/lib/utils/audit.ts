import { createClient } from '@/lib/supabase/client'

interface AuditParams {
  action: string
  module: string
  recordId?: string
  recordType?: string
  oldData?: Record<string, unknown>
  newData?: Record<string, unknown>
}

export async function logAudit(params: AuditParams) {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return

  await supabase.from('audit_logs').insert({
    user_id: user.id,
    action: params.action,
    module: params.module,
    record_id: params.recordId ?? null,
    record_type: params.recordType ?? null,
    old_data: params.oldData ?? null,
    new_data: params.newData ?? null,
  })
}

// Server-side audit (in Server Actions / API routes)
export async function logAuditServer(
  supabase: ReturnType<typeof createClient>,
  userId: string,
  params: AuditParams
) {
  await supabase.from('audit_logs').insert({
    user_id: userId,
    action: params.action,
    module: params.module,
    record_id: params.recordId ?? null,
    record_type: params.recordType ?? null,
    old_data: params.oldData ?? null,
    new_data: params.newData ?? null,
  })
}
