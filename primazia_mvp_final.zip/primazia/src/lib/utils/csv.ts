/**
 * Safe CSV generation utilities.
 *
 * Uses papaparse (Papa.unparse) which handles:
 *  - Quoting fields that contain delimiter, newlines, or quotes
 *  - Escaping embedded quotes (RFC 4180)
 *
 * Also sanitises CSV injection: fields starting with =, +, -, @, TAB, CR
 * are prefixed with a single quote so spreadsheet apps don't execute them.
 *
 * References:
 *  - https://owasp.org/www-community/attacks/CSV_Injection
 *  - https://www.papaparse.com/
 */
import Papa from 'papaparse'

const CSV_INJECTION_REGEX = /^[=+\-@\t\r]/

/**
 * Sanitise a single cell value against CSV injection.
 * Prefix dangerous values with a single quote.
 */
function sanitiseCell(value: unknown): string {
  if (value === null || value === undefined) return ''
  const str = String(value)
  if (CSV_INJECTION_REGEX.test(str)) return `'${str}`
  return str
}

/**
 * Sanitise all values in an array of records.
 */
function sanitiseRows(
  rows: Record<string, unknown>[],
): Record<string, string>[] {
  return rows.map(row =>
    Object.fromEntries(
      Object.entries(row).map(([k, v]) => [k, sanitiseCell(v)])
    )
  )
}

/**
 * Generate a safe, BOM-prefixed CSV string from an array of records.
 * Column order follows the first object's key order unless `fields` is provided.
 */
export function generateCSV(
  rows: Record<string, unknown>[],
  fields?: string[],
): string {
  const BOM = '\uFEFF'
  const sanitised = sanitiseRows(rows)

  const csv = Papa.unparse(sanitised, {
    delimiter: ';',
    header: true,
    ...(fields ? { columns: fields } : {}),
    newline: '\r\n', // RFC 4180
  })

  return BOM + csv
}

/**
 * Create a Next.js Response with Content-Type text/csv.
 */
export function csvResponse(csv: string, filename: string): Response {
  return new Response(csv, {
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="${filename}"`,
      'Cache-Control': 'no-store',
    },
  })
}
