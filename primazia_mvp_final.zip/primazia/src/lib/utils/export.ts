/**
 * Client-side export utilities.
 * Uses papaparse for safe CSV generation with CSV injection protection.
 */
import Papa from 'papaparse'

// CSV injection: fields starting with these chars could execute formulas in Excel/Sheets
const CSV_INJECTION_RE = /^[=+\-@\t\r]/

function sanitiseCell(value: unknown): string {
  if (value === null || value === undefined) return ''
  const str = String(value)
  return CSV_INJECTION_RE.test(str) ? `'${str}` : str
}

function sanitiseRows(rows: Record<string, unknown>[]): Record<string, string>[] {
  return rows.map(row =>
    Object.fromEntries(Object.entries(row).map(([k, v]) => [k, sanitiseCell(v)]))
  )
}

// ── CSV Export ────────────────────────────────────────────────────────────────
export function exportToCSV<T extends Record<string, unknown>>(
  data: T[],
  filename: string,
  columns?: { key: keyof T; label: string }[],
) {
  const rows = columns
    ? data.map(row =>
        columns.reduce((acc, col) => {
          acc[col.label] = row[col.key] ?? ''
          return acc
        }, {} as Record<string, unknown>)
      )
    : (data as unknown as Record<string, unknown>[])

  const BOM = '\uFEFF'
  const csv = BOM + Papa.unparse(sanitiseRows(rows), {
    delimiter: ';',
    header: true,
    newline: '\r\n',
  })

  triggerDownload(new Blob([csv], { type: 'text/csv;charset=utf-8;' }), `${filename}.csv`)
}

// ── Trigger browser download ──────────────────────────────────────────────────
function triggerDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  URL.revokeObjectURL(url)
}

// ── Visitor report formatter ──────────────────────────────────────────────────
export function formatVisitorReport(
  visitors: import('@/lib/types/database').Visitor[],
) {
  return visitors.map(v => ({
    Nome: v.full_name,
    'Data da visita': v.visit_date,
    Culto: v.service_type,
    Gênero: v.gender === 'M' ? 'Masculino' : v.gender === 'F' ? 'Feminino' : 'Outro',
    Idade: v.age ?? '',
    'Faixa etária': v.age_range ?? '',
    Bairro: v.neighborhood ?? '',
    Cidade: v.city ?? '',
    Telefone: v.phone ?? '',
    'Como conheceu': v.how_found ?? '',
    'Deseja contato': v.wants_contact ? 'Sim' : 'Não',
    Recorrente: v.is_recurring ? 'Sim' : 'Não',
  }))
}

// ── Financial report formatter ────────────────────────────────────────────────
export function formatFinancialReport(
  transactions: import('@/lib/types/database').FinancialTransaction[],
) {
  return transactions.map(t => ({
    Data: t.transaction_date,
    Tipo: t.type === 'income' ? 'Entrada' : 'Saída',
    Categoria: t.category?.name ?? '',
    Descrição: t.description,
    Valor: `R$ ${Number(t.amount).toFixed(2).replace('.', ',')}`,
    'Forma de pagamento': t.payment_method ?? '',
    'Nº comprovante': t.reference_num ?? '',
    Observações: t.notes ?? '',
    Status: t.status,
    'Cadastrado por': t.creator?.full_name ?? '',
  }))
}

// ── PDF export (meeting minutes) ──────────────────────────────────────────────
export async function exportMeetingMinutesToPDF(
  minute: import('@/lib/types/database').MeetingMinutes,
) {
  const { jsPDF } = await import('jspdf')
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' })

  const margin = 20
  let y = margin

  doc.setFontSize(18)
  doc.setFont('helvetica', 'bold')
  doc.text('PrimazIA — Ata Pastoral', margin, y)
  y += 10

  doc.setFontSize(12)
  doc.setFont('helvetica', 'normal')
  doc.text(`Título: ${minute.title}`, margin, y); y += 7
  doc.text(`Data: ${new Date(minute.meeting_date).toLocaleDateString('pt-BR')}`, margin, y); y += 7
  doc.text(`Participantes: ${minute.participants ?? '—'}`, margin, y); y += 10

  if (minute.agenda) {
    doc.setFont('helvetica', 'bold')
    doc.text('Pauta:', margin, y); y += 6
    doc.setFont('helvetica', 'normal')
    const lines = doc.splitTextToSize(minute.agenda, 170)
    doc.text(lines, margin, y)
    y += (lines as string[]).length * 6 + 4
  }

  if (minute.content) {
    doc.setFont('helvetica', 'bold')
    doc.text('Conteúdo:', margin, y); y += 6
    doc.setFont('helvetica', 'normal')
    const lines = doc.splitTextToSize(minute.content, 170)
    doc.text(lines, margin, y)
    y += (lines as string[]).length * 6 + 4
  }

  if (minute.decisions) {
    doc.setFont('helvetica', 'bold')
    doc.text('Decisões / Encaminhamentos:', margin, y); y += 6
    doc.setFont('helvetica', 'normal')
    const lines = doc.splitTextToSize(minute.decisions, 170)
    doc.text(lines, margin, y)
  }

  doc.save(`ata_${minute.meeting_date}_${minute.id.slice(0, 8)}.pdf`)
}
