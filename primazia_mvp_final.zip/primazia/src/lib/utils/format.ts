/**
 * Format a value as BRL currency
 */
export function formatBRL(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(value)
}

/**
 * Format a date string (YYYY-MM-DD) to Brazilian format
 */
export function formatDate(dateStr: string, opts?: Intl.DateTimeFormatOptions): string {
  if (!dateStr) return '—'
  try {
    return new Date(dateStr + 'T12:00').toLocaleDateString('pt-BR', opts)
  } catch {
    return dateStr
  }
}

/**
 * Format a datetime string to Brazilian format
 */
export function formatDateTime(isoStr: string): string {
  if (!isoStr) return '—'
  try {
    return new Date(isoStr).toLocaleString('pt-BR', {
      day: '2-digit', month: '2-digit', year: 'numeric',
      hour: '2-digit', minute: '2-digit',
    })
  } catch {
    return isoStr
  }
}

/**
 * Get initials from a full name
 */
export function getInitials(name: string, maxChars = 2): string {
  return name
    .split(' ')
    .map(n => n[0])
    .join('')
    .slice(0, maxChars)
    .toUpperCase()
}

/**
 * Truncate a string with ellipsis
 */
export function truncate(str: string, max: number): string {
  if (str.length <= max) return str
  return str.slice(0, max) + '…'
}

/**
 * Calculate age from birthdate string
 */
export function calcAge(birthDate: string): number {
  const birth = new Date(birthDate + 'T12:00')
  const today = new Date()
  let age = today.getFullYear() - birth.getFullYear()
  const m = today.getMonth() - birth.getMonth()
  if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--
  return age
}

/**
 * Get age range label from age
 */
export function getAgeRange(age: number): string {
  if (age < 13) return 'Criança (0–12)'
  if (age < 18) return 'Adolescente (13–17)'
  if (age < 30) return 'Jovem (18–29)'
  if (age < 45) return 'Adulto (30–44)'
  if (age < 60) return 'Adulto (45–59)'
  return 'Terceira idade (60+)'
}
