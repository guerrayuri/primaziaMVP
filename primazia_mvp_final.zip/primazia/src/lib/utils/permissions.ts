import type { UserRole } from '@/lib/types/database'

const HIERARCHY: UserRole[] = [
  'visitor', 'student', 'member', 'guardian',
  'teacher', 'coordinator', 'financial_admin',
  'pastor', 'admin', 'super_admin',
]

export function hasRole(userRole: UserRole, required: UserRole): boolean {
  return HIERARCHY.indexOf(userRole) >= HIERARCHY.indexOf(required)
}

export function canManageFinancial(role: UserRole) {
  return role === 'super_admin' || role === 'financial_admin'
}

export function canManageChildren(role: UserRole) {
  return hasRole(role, 'teacher')
}

export function canViewConfidentialMinutes(role: UserRole) {
  return hasRole(role, 'pastor')
}

export function canManageEvents(role: UserRole) {
  return hasRole(role, 'admin')
}

export function canEditPublicArea(role: UserRole) {
  return hasRole(role, 'admin')
}

export const ROLE_LABELS: Record<UserRole, string> = {
  super_admin: 'Superadministrador',
  admin: 'Administrador',
  financial_admin: 'Adm. Financeiro',
  pastor: 'Pastor',
  coordinator: 'Coordenador',
  teacher: 'Professor',
  guardian: 'Pai / Responsável',
  member: 'Membro',
  student: 'Aluno',
  visitor: 'Visitante',
}

export const ROLE_COLORS: Record<UserRole, string> = {
  super_admin: 'bg-gold-100 text-gold-600',
  admin: 'bg-navy-100 text-navy-700',
  financial_admin: 'bg-red-100 text-red-700',
  pastor: 'bg-blue-100 text-blue-700',
  coordinator: 'bg-purple-100 text-purple-700',
  teacher: 'bg-indigo-100 text-indigo-700',
  guardian: 'bg-green-100 text-green-700',
  member: 'bg-gray-100 text-gray-700',
  student: 'bg-teal-100 text-teal-700',
  visitor: 'bg-orange-100 text-orange-700',
}
