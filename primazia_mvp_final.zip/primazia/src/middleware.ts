import { createServerClient } from '@supabase/ssr'
import type { CookieOptions } from '@supabase/ssr'
import { NextResponse, type NextRequest } from 'next/server'
import type { UserRole } from '@/lib/types/database'

// ── Public route checker ─────────────────────────────────────────────────────
// FIX: was using startsWith("/") which matched everything.
// Now uses exact match or explicit prefix per route.
function isPublicRoute(pathname: string): boolean {
  return (
    pathname === '/' ||
    pathname.startsWith('/auth/login') ||
    pathname.startsWith('/auth/register') ||
    pathname.startsWith('/auth/forgot-password') ||
    pathname.startsWith('/auth/callback') ||
    pathname.startsWith('/auth/error') ||
    pathname.startsWith('/auth/reset-password') ||
    pathname.startsWith('/_next') ||
    pathname.startsWith('/favicon') ||
    pathname.startsWith('/icon') ||
    pathname.startsWith('/api/health')
  )
}

// ── Role hierarchy ────────────────────────────────────────────────────────────
const ROLE_HIERARCHY: UserRole[] = [
  'visitor',
  'student',
  'member',
  'guardian',
  'teacher',
  'coordinator',
  'financial_admin',
  'pastor',
  'admin',
  'super_admin',
]

function hasAccess(userRole: UserRole, requiredRole: UserRole): boolean {
  return ROLE_HIERARCHY.indexOf(userRole) >= ROLE_HIERARCHY.indexOf(requiredRole)
}

// ── Protected route → minimum required role ───────────────────────────────────
const PROTECTED_ROUTES: Array<{ prefix: string; minRole: UserRole }> = [
  { prefix: '/protected/financeiro',   minRole: 'financial_admin' },
  { prefix: '/financeiro',             minRole: 'financial_admin' },
  { prefix: '/protected/admin',        minRole: 'admin' },
  { prefix: '/admin',                  minRole: 'admin' },
  { prefix: '/protected/atas',         minRole: 'pastor' },
  { prefix: '/atas',                   minRole: 'pastor' },
  { prefix: '/protected/membros',      minRole: 'pastor' },
  { prefix: '/membros',                minRole: 'pastor' },
  { prefix: '/protected/visitantes',   minRole: 'pastor' },
  { prefix: '/visitantes',             minRole: 'pastor' },
  { prefix: '/protected/ministerios',  minRole: 'pastor' },
  { prefix: '/ministerios',            minRole: 'pastor' },
  { prefix: '/protected/infantil',     minRole: 'teacher' },
  { prefix: '/infantil',               minRole: 'teacher' },
  { prefix: '/protected/gabinete',     minRole: 'member' },
  { prefix: '/gabinete',               minRole: 'member' },
  { prefix: '/protected/eventos',      minRole: 'member' },
  { prefix: '/eventos',                minRole: 'member' },
  { prefix: '/protected/cursos',       minRole: 'member' },
  { prefix: '/cursos',                 minRole: 'member' },
  { prefix: '/protected/minha-area',   minRole: 'member' },
  { prefix: '/minha-area',             minRole: 'member' },
  { prefix: '/protected/publica',      minRole: 'member' },
  { prefix: '/publica',                minRole: 'member' },
  { prefix: '/protected/dashboard',    minRole: 'member' },
  { prefix: '/dashboard',              minRole: 'member' },
  { prefix: '/protected',              minRole: 'member' }, // catch-all
  { prefix: '/api/admin',              minRole: 'admin' },
  { prefix: '/api/export',             minRole: 'pastor' },
]

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl

  // Allow public routes without any auth check
  if (isPublicRoute(pathname)) {
    return NextResponse.next()
  }

  let response = NextResponse.next({ request })

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll()
        },
        setAll(cookiesToSet: { name: string; value: string; options: CookieOptions }[]) {
          cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value))
          response = NextResponse.next({ request })
          cookiesToSet.forEach(({ name, value, options }) =>
            response.cookies.set(name, value, options)
          )
        },
      },
    }
  )

  const { data: { user } } = await supabase.auth.getUser()

  // Not authenticated → redirect to login
  if (!user) {
    const loginUrl = request.nextUrl.clone()
    loginUrl.pathname = '/auth/login'
    loginUrl.searchParams.set('next', pathname)
    return NextResponse.redirect(loginUrl)
  }

  // Get user profile with role and active status
  const { data: profile } = await supabase
    .from('profiles')
    .select('role, is_active')
    .eq('id', user.id)
    .single()

  // Deactivated or missing profile → sign out and redirect
  if (!profile || !profile.is_active) {
    await supabase.auth.signOut()
    const loginUrl = request.nextUrl.clone()
    loginUrl.pathname = '/auth/login'
    loginUrl.searchParams.set('error', 'account_disabled')
    return NextResponse.redirect(loginUrl)
  }

  // Find the most specific matching protected route
  const matched = PROTECTED_ROUTES.find(r => pathname.startsWith(r.prefix))
  if (matched && !hasAccess(profile.role as UserRole, matched.minRole)) {
    const dashUrl = request.nextUrl.clone()
    dashUrl.pathname = '/protected/dashboard'
    dashUrl.searchParams.set('error', 'unauthorized')
    return NextResponse.redirect(dashUrl)
  }

  return response
}

export const config = {
  matcher: [
    /*
     * Match all paths EXCEPT static files and Next.js internals.
     * The isPublicRoute() function handles further filtering.
     */
    '/((?!_next/static|_next/image|favicon.ico|icon\\..*|.*\\.(?:svg|png|jpg|jpeg|gif|webp|ico)$).*)',
  ],
}
