-- ============================================================
-- PrimazIA — Migration 004: RLS Gaps + Security Fixes
-- Execute no SQL Editor do Supabase após as migrations 001-003
-- ============================================================

-- ============================================================
-- 1. ENABLE RLS on tables that were missing policies
-- ============================================================

ALTER TABLE course_modules        ENABLE ROW LEVEL SECURITY;
ALTER TABLE lesson_progress       ENABLE ROW LEVEL SECURITY;
ALTER TABLE ministries            ENABLE ROW LEVEL SECURITY;
ALTER TABLE ministry_members      ENABLE ROW LEVEL SECURITY;
ALTER TABLE children_lesson_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE meeting_access        ENABLE ROW LEVEL SECURITY;

-- ============================================================
-- 2. COURSE MODULES
-- Visible to anyone who can see the course (enrolled + staff)
-- ============================================================

CREATE POLICY "course_modules_select"
  ON course_modules FOR SELECT
  TO authenticated
  USING (
    -- Admin/pastor see all
    (SELECT role FROM profiles WHERE id = auth.uid()) IN ('super_admin','admin','pastor','coordinator','teacher')
    OR
    -- Enrolled active students see modules of their course
    EXISTS (
      SELECT 1 FROM course_enrollments
      WHERE course_id = course_modules.course_id
        AND user_id = auth.uid()
        AND status IN ('active','in_progress','completed')
    )
  );

CREATE POLICY "course_modules_manage_admin"
  ON course_modules FOR ALL
  TO authenticated
  USING ((SELECT role FROM profiles WHERE id = auth.uid()) IN ('super_admin','admin','pastor'))
  WITH CHECK ((SELECT role FROM profiles WHERE id = auth.uid()) IN ('super_admin','admin','pastor'));

-- ============================================================
-- 3. LESSON PROGRESS
-- Each user manages only their own progress; admins can read all
-- ============================================================

CREATE POLICY "lesson_progress_select_own"
  ON lesson_progress FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid()
    OR (SELECT role FROM profiles WHERE id = auth.uid()) IN ('super_admin','admin','pastor')
  );

CREATE POLICY "lesson_progress_insert_own"
  ON lesson_progress FOR INSERT
  TO authenticated
  WITH CHECK (
    user_id = auth.uid()
    AND EXISTS (
      SELECT 1 FROM course_enrollments ce
      JOIN course_lessons cl ON cl.id = lesson_progress.lesson_id
      WHERE ce.course_id = cl.course_id
        AND ce.user_id = auth.uid()
        AND ce.status IN ('active','in_progress','completed')
    )
  );

CREATE POLICY "lesson_progress_update_own"
  ON lesson_progress FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

-- ============================================================
-- 4. MINISTRIES
-- Visible to all authenticated users; managed by admin+
-- ============================================================

CREATE POLICY "ministries_select_auth"
  ON ministries FOR SELECT
  TO authenticated
  USING (is_active = true);

CREATE POLICY "ministries_manage_admin"
  ON ministries FOR ALL
  TO authenticated
  USING ((SELECT role FROM profiles WHERE id = auth.uid()) IN ('super_admin','admin','pastor'))
  WITH CHECK ((SELECT role FROM profiles WHERE id = auth.uid()) IN ('super_admin','admin','pastor'));

-- ============================================================
-- 5. MINISTRY MEMBERS
-- ============================================================

CREATE POLICY "ministry_members_select_auth"
  ON ministry_members FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "ministry_members_manage_admin"
  ON ministry_members FOR ALL
  TO authenticated
  USING ((SELECT role FROM profiles WHERE id = auth.uid()) IN ('super_admin','admin','pastor'))
  WITH CHECK ((SELECT role FROM profiles WHERE id = auth.uid()) IN ('super_admin','admin','pastor'));

-- ============================================================
-- 6. CHILDREN LESSON REPORTS
-- Teachers of the class + coordinator+ can read/write
-- Parents cannot access directly (use feedbacks with visibility)
-- ============================================================

CREATE POLICY "children_lesson_reports_select"
  ON children_lesson_reports FOR SELECT
  TO authenticated
  USING (
    teacher_id = auth.uid()
    OR (SELECT role FROM profiles WHERE id = auth.uid()) IN ('super_admin','admin','pastor','coordinator')
  );

CREATE POLICY "children_lesson_reports_insert"
  ON children_lesson_reports FOR INSERT
  TO authenticated
  WITH CHECK (
    teacher_id = auth.uid()
    AND (SELECT role FROM profiles WHERE id = auth.uid()) IN ('super_admin','admin','pastor','coordinator','teacher')
    AND EXISTS (
      SELECT 1 FROM children_classes
      WHERE id = children_lesson_reports.class_id
        AND (teacher_id = auth.uid() OR (SELECT role FROM profiles WHERE id = auth.uid()) IN ('super_admin','admin','pastor','coordinator'))
    )
  );

CREATE POLICY "children_lesson_reports_update"
  ON children_lesson_reports FOR UPDATE
  TO authenticated
  USING (
    teacher_id = auth.uid()
    OR (SELECT role FROM profiles WHERE id = auth.uid()) IN ('super_admin','admin','pastor','coordinator')
  )
  WITH CHECK (
    teacher_id = auth.uid()
    OR (SELECT role FROM profiles WHERE id = auth.uid()) IN ('super_admin','admin','pastor','coordinator')
  );

-- ============================================================
-- 7. MEETING ACCESS
-- Explicitly grants access to confidential minutes
-- Only pastors+ can grant/revoke; access holders can read
-- ============================================================

CREATE POLICY "meeting_access_select"
  ON meeting_access FOR SELECT
  TO authenticated
  USING (
    profile_id = auth.uid()
    OR (SELECT role FROM profiles WHERE id = auth.uid()) IN ('super_admin','admin','pastor')
  );

CREATE POLICY "meeting_access_manage_pastor"
  ON meeting_access FOR ALL
  TO authenticated
  USING ((SELECT role FROM profiles WHERE id = auth.uid()) IN ('super_admin','admin','pastor'))
  WITH CHECK ((SELECT role FROM profiles WHERE id = auth.uid()) IN ('super_admin','admin','pastor'));

-- ============================================================
-- 8. SAFER handle_new_user — new users start as INACTIVE MEMBER
-- They must be approved by an admin before accessing the system
-- ============================================================

CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO profiles (id, full_name, email, role, is_active)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
    NEW.email,
    'member',      -- start as member
    false          -- inactive until approved by admin
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================
-- 9. SAFE profile update RPC
-- Users can only update: full_name, phone, avatar_url
-- Cannot touch: role, is_active, approved_by, email, etc.
-- ============================================================

CREATE OR REPLACE FUNCTION update_own_profile(
  p_full_name TEXT,
  p_phone     TEXT DEFAULT NULL,
  p_avatar_url TEXT DEFAULT NULL
)
RETURNS void AS $$
BEGIN
  UPDATE profiles
  SET
    full_name  = COALESCE(p_full_name, full_name),
    phone      = p_phone,
    avatar_url = p_avatar_url,
    updated_at = NOW()
  WHERE id = auth.uid();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================
-- 10. TRANSACTIONAL role request approval RPC
-- Validates permission, updates both tables, and logs audit
-- Replaces the two separate updates in AdminClient.tsx
-- ============================================================

CREATE OR REPLACE FUNCTION approve_role_request(
  p_request_id UUID,
  p_reviewer_id UUID
)
RETURNS void AS $$
DECLARE
  v_reviewer_role user_role;
  v_request       role_requests%ROWTYPE;
BEGIN
  -- Validate reviewer has admin+ role
  SELECT role INTO v_reviewer_role FROM profiles WHERE id = p_reviewer_id;
  IF v_reviewer_role NOT IN ('super_admin','admin') THEN
    RAISE EXCEPTION 'Permission denied: only admin or super_admin can approve role requests';
  END IF;

  -- Fetch the request
  SELECT * INTO v_request FROM role_requests WHERE id = p_request_id AND status = 'pending';
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Role request not found or already processed';
  END IF;

  -- Update request status
  UPDATE role_requests
  SET
    status      = 'approved',
    reviewed_by = p_reviewer_id,
    reviewed_at = NOW(),
    updated_at  = NOW()
  WHERE id = p_request_id;

  -- Update user role
  UPDATE profiles
  SET
    role        = v_request.requested_role,
    is_active   = true,   -- activate if was inactive
    approved_by = p_reviewer_id,
    approved_at = NOW(),
    updated_at  = NOW()
  WHERE id = v_request.user_id;

  -- Audit log
  INSERT INTO audit_logs (user_id, action, module, record_id, record_type, new_data)
  VALUES (
    p_reviewer_id,
    'approve_role_request',
    'admin',
    p_request_id,
    'role_request',
    jsonb_build_object(
      'user_id', v_request.user_id,
      'old_role', v_request.current_role,
      'new_role', v_request.requested_role
    )
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================
-- 11. TRANSACTIONAL event registration RPC
-- Fixes the (ev.max_spots === 0 || true) race condition
-- ============================================================

CREATE OR REPLACE FUNCTION register_for_event(
  p_event_id UUID,
  p_user_id  UUID
)
RETURNS void AS $$
DECLARE
  v_event       events%ROWTYPE;
  v_slot_count  INT;
BEGIN
  -- Lock the event row to prevent race condition
  SELECT * INTO v_event FROM events WHERE id = p_event_id FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Event not found';
  END IF;

  IF v_event.status != 'published' THEN
    RAISE EXCEPTION 'Event is not open for registration';
  END IF;

  -- Check if already registered
  IF EXISTS (
    SELECT 1 FROM event_registrations
    WHERE event_id = p_event_id AND user_id = p_user_id AND status != 'cancelled'
  ) THEN
    RAISE EXCEPTION 'User already registered for this event';
  END IF;

  -- Check capacity (0 = unlimited)
  IF v_event.max_spots > 0 THEN
    SELECT COUNT(*) INTO v_slot_count
    FROM event_registrations
    WHERE event_id = p_event_id AND status NOT IN ('cancelled');

    IF v_slot_count >= v_event.max_spots THEN
      RAISE EXCEPTION 'Event is full';
    END IF;
  END IF;

  -- Register
  INSERT INTO event_registrations (event_id, user_id, status)
  VALUES (p_event_id, p_user_id, 'registered');

  -- Audit
  INSERT INTO audit_logs (user_id, action, module, record_id, record_type)
  VALUES (p_user_id, 'register_event', 'eventos', p_event_id, 'event');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================
-- 12. RLS: profiles self-update is now handled via RPC
-- Tighten the profiles UPDATE policy to block direct field changes
-- ============================================================

-- Drop the existing self-update policy that allowed role changes
DROP POLICY IF EXISTS "profiles_update_self" ON profiles;

-- New policy: users can update only via the safe RPC (SECURITY DEFINER bypasses RLS)
-- Direct updates to own profile are blocked for all non-admin users
CREATE POLICY "profiles_update_self_restricted"
  ON profiles FOR UPDATE
  TO authenticated
  USING (
    -- Admin can update any profile
    (SELECT role FROM profiles WHERE id = auth.uid()) IN ('super_admin','admin')
    -- Users can update own non-sensitive fields (enforced by RPC — direct UPDATE still blocked)
    OR (
      auth.uid() = id
      -- Prevent self-escalation: role must not change
      AND role = (SELECT role FROM profiles p2 WHERE p2.id = auth.uid())
      -- Prevent self-activation
      AND is_active = (SELECT is_active FROM profiles p2 WHERE p2.id = auth.uid())
    )
  )
  WITH CHECK (
    (SELECT role FROM profiles WHERE id = auth.uid()) IN ('super_admin','admin')
    OR (
      auth.uid() = id
      AND role = (SELECT role FROM profiles p2 WHERE p2.id = auth.uid())
      AND is_active = (SELECT is_active FROM profiles p2 WHERE p2.id = auth.uid())
      AND approved_by IS NOT DISTINCT FROM (SELECT approved_by FROM profiles p2 WHERE p2.id = auth.uid())
    )
  );
